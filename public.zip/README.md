# Cloverr

Project Aim :- Stock Market

# Project Description

The project was developed in conjunction with React.ts.
This is Stock Market Website which is basically creating Stock Market Blogs/Theme.
In this User, Analyst, Admin and Super Analyst Post are their for approval User Theme or Profession.

# Built With

React.ts
Miui FrameWork
Axios
Redux Toolkit
React-Router-Dom
Hooks

# 3rd Party Library used

1. react-helemt.
2. react-flags-select.
3. react-otp-input.
4. react-phone-input-2.
5. react-pro-slider.
6. jodit-react-ts.
7. react dropzone.
8. mui/material.
9. axios.
10. redux.
11. react-router-dom.
12. mui/lab.
13. react-player

# Getting Started

# Fork the project and clone it locally.

In the project directory, you can follow the steps below to download the dependencies:

# Install with npm:

npm i

# Install with yarn:

yarn

# Starting Front-End Servers

In the project directory, you can run:

# Run with npm:

npm run

Runs the app in the development mode.
Open http://192.168.71.55:3000 to view it in your browser.

The page will reload when you make changes.
You may also see any lint errors in the console.

# Run with yarn:

yarn start

# License

Distributed under the MSBC Bussiness Solution License. See LICENSE.txt for more information.

# Contact



# Acknowledgments

Material Ui
3rd Party Libraries install by node module package
