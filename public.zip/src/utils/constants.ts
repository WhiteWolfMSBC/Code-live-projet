const BASE_URL = "http://192.168.71.66:5000/";
export const LOGIN_URL = BASE_URL + "login/";
export const REGISTER_URL = BASE_URL + "register/";
export const USERNAME_URL = BASE_URL + "username/";
export const FORGOT_URL = BASE_URL + "forgot_password/";
export const LOGOUT_URL = BASE_URL + "logout/";
export const USER_LIST = BASE_URL + "user_list/";
export const PROFESSION_URL = BASE_URL + "profession_list/";
export const IMAGEUPLOAD_URL = BASE_URL +"idea/";
export const passwordMsg =
  "Should have at least 8 characters and includes one special character, one capital letter  and one number";



