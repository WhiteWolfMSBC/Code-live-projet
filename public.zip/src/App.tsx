import React, { useEffect, useState } from "react";
import "./index.css";
import Login from "./home/login/Login";
import { Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./modules/admin/views/Dashboard";
import { ColorModeContext, useMode } from "./theme";
import { ThemeProvider, CssBaseline } from "@mui/material";
import Sidebar from "./components/global/SideBar";
import TopBar from "./components/global/TopBar";
import Register from "./home/register/Register";
import {
  isLoggedIn,
  role,
  set_IsLoggedIn,
  token,
} from "./store/Reducers/UserSlice";
import { useAppDispatch, useAppSelector } from "./store/store";
import { ForgotPassword } from "./home/forgotPassword/ForgotPassword";
import User from "./modules/admin/views/User/User";
import Analyst from "./modules/admin/views/Analyst/Analyst";
import UnAuthorized from "./home/unAuthorize/unAuthorize";
import Idea from "./modules/analyst/Views/Idea/Idea";

function App() {
  const [theme, colorMode] = useMode();
  const [isCollapsed, setIsCollapsed] = useState(true);
  const dispatch = useAppDispatch();
  const isLoggedInUser = useAppSelector(isLoggedIn);
  const auth_token = useAppSelector(token);
  const roles = useAppSelector(role);
  useEffect(() => {
    if (auth_token === "") {
      setIsCollapsed(true);
    }
  }, [auth_token, isLoggedInUser]);
  useEffect(() => {
    localStorage.getItem("token")
      ? dispatch(set_IsLoggedIn(true))
      : dispatch(set_IsLoggedIn(false));
  }, [dispatch]);
  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {!isLoggedInUser && (
          <Routes>
            <Route path="/" element={<Login />}></Route>
            <Route path="/register" element={<Register />}></Route>
            <Route path="/forgot" element={<ForgotPassword />}></Route>
            <Route path="/unauthorized" element={<UnAuthorized />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        )}
        {isLoggedInUser && (
          <div
            className="app"
            style={{ background: `${theme.palette.primary.mainGradient}` }}
          >
            <Sidebar
              isCollapsed={isCollapsed}
              setIsCollapsed={setIsCollapsed}
              role={roles}
            />
            <main className={"content"}>
              <TopBar />
              {roles === "user" && (
                <Routes>
                  <Route path="/dashboard" element={<Dashboard />}></Route>
                  <Route path="/user" element={<User />} />
                  <Route path="/analyst" element={<Analyst />} />
                  <Route path="/unauthorized" element={<UnAuthorized />} />
                  <Route
                    path="*"
                    element={<Navigate to="/dashboard" replace />}
                  />
                </Routes>
              )}
              {roles === "analyst" && (
                <Routes>
                  <Route path="/dashboard" element={<Dashboard />}></Route>
                  <Route path="/idea" element={<Idea />}></Route>
                  <Route path="/unauthorized" element={<UnAuthorized />} />
                  <Route
                    path="*"
                    element={<Navigate to="/dashboard" replace />}
                  />
                </Routes>
              )}
            </main>
          </div>
        )}
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export default App;
