import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../store";

export interface DataSchema {
  textBox: string;
  text: string;
  imageUrl: string;
  imageCaption: string;
  videoUrl: string;
  videoCaption: string;
  chartUrl: string;
  mediaLink: string;
  bestWayToTrade: {
    subTitle: string;
    fundName: string;
    tradePrice: number;
    tags: string[];
  };
  tags: string[];
}
interface IdeaSchema {
  id: number;
  type: string;
  data: DataSchema;
}
export interface IdeaState {
  imageUpload: boolean;
  mediaLink: boolean;
  chartUpload: boolean;
  videoUpload: boolean;
  wayToTrade: boolean;
  text: boolean;
  textBox: boolean;
  tag: boolean;
  ideaTemplate: IdeaSchema[];
  currentItem: IdeaSchema | null;
}

const initialState: IdeaState = {
  imageUpload: false,
  mediaLink: false,
  chartUpload: false,
  videoUpload: false,
  wayToTrade: false,
  text: false,
  textBox: false,
  tag: false,
  ideaTemplate: [],
  currentItem: null,
};

export const ideaSlice = createSlice({
  name: "idea",
  initialState,
  // The `reducers` field lets us define reducers and generate associated actions
  reducers: {
    set_Editor: (state, action) => {
      console.log(action.payload);
      switch (action.payload.type) {
        case "imageUpload":
          state.imageUpload = true;
          break;
        case "mediaLink":
          state.mediaLink = true;
          break;
        case "chartUpload":
          state.chartUpload = true;
          break;
        case "bestWayToTrade":
          state.wayToTrade = true;
          break;
        case "videoUpload":
          state.videoUpload = true;
          break;
        case "text":
          state.text = true;
          break;
        case "textBox":
          state.textBox = true;
          break;
        case "tag":
          state.tag = true;
          break;
      }
    },
    addItemToIdeaTemplate: (state, action) => {
      console.log(action.payload);
      const newData = {
        id: Math.floor(Math.random() * 100000000),
        ...action.payload,
      };
      state.ideaTemplate = [...state.ideaTemplate, newData];
      state.currentItem = newData;
    },
    emptyCurrentItem: (state) => {
      state.currentItem = null;
    },
    updateOrSaveData: (state, action) => {
      console.log("idea slice", state.currentItem, action.payload);
      if (state.currentItem) {
        const { id, type } = state.currentItem;
        console.log("id and type", id, type);
        if (id !== undefined && id !== null) {
          state.currentItem = { id, type, ...action.payload };
          const index = state.ideaTemplate.findIndex((item) => item.id === id);
          state.ideaTemplate[index] = { id, type, ...action.payload };
        }
      }
    },
    set_CurrentItem: (state, action) => {
      console.log("curr", action.payload);
      state.currentItem = action.payload;
    },
    deleteData: (state, action) => {
      if (state.currentItem) {
        const { id } = state.currentItem;
        if (id === action.payload?.id) {
          state.currentItem = null;
        }
      }
      state.ideaTemplate = state.ideaTemplate.filter(
        (idea) => idea.id !== action.payload.id
      );
    },
  },
});

export const imageUpload = (state: RootState) => state.idea.imageUpload;
export const mediaLink = (state: RootState) => state.idea.mediaLink;
export const chartUpload = (state: RootState) => state.idea.chartUpload;
export const wayToTrade = (state: RootState) => state.idea.wayToTrade;
export const videoUpload = (state: RootState) => state.idea.videoUpload;
export const text = (state: RootState) => state.idea.text;
export const textBox = (state: RootState) => state.idea.textBox;
export const tag = (state: RootState) => state.idea.tag;
export const ideaTemplate = (state: RootState) => state.idea.ideaTemplate;
export const currentItem = (state: RootState) => state.idea.currentItem;

export const {
  set_Editor,
  addItemToIdeaTemplate,
  emptyCurrentItem,
  updateOrSaveData,
  set_CurrentItem,
  deleteData,
} = ideaSlice.actions;

export default ideaSlice.reducer;
