import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../store";

export interface UserState {
  username: string;
  isLoggedIn: boolean;
  token: string;
  firstName: string;
  lastName: string;
  email: string;
  userId: string;
  role: string;
}

const initialState: UserState = {
  username: localStorage.getItem("username") ?? "",
  isLoggedIn: localStorage.getItem("token") ? true : false,
  token: localStorage.getItem("token") ?? "",
  firstName: "",
  lastName: "",
  email: "",
  userId: localStorage.getItem("userid") ?? "",
  role: localStorage.getItem("role") ?? "",
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    set_Username: (state, action) => {
      state.username = action.payload;
      localStorage.setItem("username", action.payload);
    },
    set_FirstName: (state, action) => {
      state.firstName = action.payload;
    },
    set_IsLoggedIn: (state, action) => {
      state.isLoggedIn = action.payload;
    },
    set_Token: (state, action) => {
      state.token = action.payload;
      localStorage.setItem("token", action.payload);
    },
    remove_Token: (state) => {
      state.token = "";
      localStorage.clear();
    },
    set_email: (state, action) => {
      state.email = action.payload;
    },
    set_userid: (state, action) => {
      state.userId = action.payload;
      localStorage.setItem("userid", action.payload);
    },
    set_Role: (state, action) => {
      state.role = action.payload;
      localStorage.setItem("role", action.payload);
    },
  },
});

export const {
  set_Username,
  set_FirstName,
  set_IsLoggedIn,
  set_Token,
  remove_Token,
  set_userid,
  set_Role,
} = userSlice.actions;
export const username = (state: RootState) => state.user.username;
export const firstName = (state: RootState) => state.user.firstName;
export const lastName = (state: RootState) => state.user.lastName;
export const isLoggedIn = (state: RootState) => state.user.isLoggedIn;
export const token = (state: RootState) => state.user.token;
export const userId = (state: RootState) => state.user.userId;
export const role = (state: RootState) => state.user.role;

export default userSlice.reducer;
