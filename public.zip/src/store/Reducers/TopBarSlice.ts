import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../store";

export interface TopBarState {
  title: string;
}

const initialState: TopBarState = {
  title: "Dashboard",
};

export const topBarSlice = createSlice({
  name: "topbar",
  initialState,

  reducers: {
    set_Title: (state, action) => {
      state.title = action.payload;
    },
  },
});

export const { set_Title } = topBarSlice.actions;
export const title = (state: RootState) => state.topbar.title;

export default topBarSlice.reducer;
