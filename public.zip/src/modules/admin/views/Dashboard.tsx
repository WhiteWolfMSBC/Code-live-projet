import { Typography, useTheme } from "@mui/material";
import React, { useEffect } from "react";
import { tokens } from "../../../theme";
import { Helmet } from "react-helmet";
import { useAppDispatch } from "../../../store/store";
import { set_Title } from "../../../store/Reducers/TopBarSlice";

function Dashboard() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(set_Title("Dashboard"));
  }, [dispatch]);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Dashboard</title>
      </Helmet>

      <Typography
        variant="h4"
        marginLeft={2}
        color={colors.grey[900]}
        align="center"
      >
        In Development...
      </Typography>
    </>
  );
}

export default Dashboard;
