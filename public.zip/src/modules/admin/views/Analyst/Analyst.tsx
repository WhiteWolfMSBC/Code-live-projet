/* eslint-disable react-hooks/exhaustive-deps */
import React, { ReactNode, SetStateAction, useEffect, useState } from "react";
import {
  Table,
  TableBody,
  Button,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@mui/material";
import {
  Avatar,
  Box,
  IconButton,
  TableSortLabel,
  Typography,
  useTheme,
} from "@mui/material";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import CloseSharpIcon from "@mui/icons-material/CloseSharp";
import "./Analyst.scss";
import { tokens } from "../../../../theme";
import { makeStyles } from "@material-ui/core/styles";
import MultiSelectSlider from "../../../../components/MultiSelectSlider/MultiSelectSlider";
import { useAppDispatch, useAppSelector } from "../../../../store/store";
import { token } from "../../../../store/Reducers/UserSlice";
import { getComparator, stableSort } from "../../../../utils/tablesort";
import {
  getProfessionListAPI,
  getUserOrAnalystListAPI,
  setUserSaveChangesAPI,
} from "../../../../api/adminApi";
import TaskAltIcon from "@mui/icons-material/TaskAlt";
import { CustomTablePaginationStyle } from "../../../../components/CustomizePagination/CutomizePagination";
import { set_Title } from "../../../../store/Reducers/TopBarSlice";

type resultProps = {
  username: string;
  name: string;
  created_on: string;
  is_active: boolean;
  user_id: number;
};

const useStyles: any = makeStyles((theme: any) => ({
  root: {
    width: "100%",
  },
  paper: {
    width: "100%",
    marginBottom: theme.spacing(2),
  },
  table: {
    minWidth: 750,
  },
  visuallyHidden: {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: 1,
    margin: -1,
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    top: 20,
    width: 1,
  },
}));

//  Table heading

const headCells = [
  {
    id: "name",
    numeric: true,
    disablePadding: false,
    label: "Name",
  },
  {
    id: "username",
    numeric: true,
    disablePadding: false,
    label: "AnalystName",
  },
  { id: "user_id", numeric: true, disablePadding: false, label: "AnalystId" },
  {
    id: "created_on",
    numeric: true,
    disablePadding: false,
    label: "Account Creation Date",
  },
  {
    id: "is_active",
    numeric: true,
    disablePadding: false,
    label: "Status",
  },
  {
    id: "",
    numeric: true,
    disablePadding: false,
    label: "Assign",
  },
];

function EnhancedTableHead(props: {
  classes: any;
  order: any;
  orderBy: any;
  onRequestSort: any;
  rowCount: any;
}) {
  const { classes, order, orderBy, onRequestSort } = props;
  const createSortHandler = (property: string) => (event: any) => {
    onRequestSort(event, property);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            align="left"
            key={headCell.id}
            sortDirection={orderBy === headCell.id ? order : false}
            sx={{
              backgroundColor: `${colors.primary[200]}`,
              padding: "8px !important",
            }}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <span className={classes.visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </span>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

const Analyst = () => {
  const classes = useStyles();
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [order, setOrder] = useState("asc");
  const [orderBy, setOrderBy] = useState("");
  const [open, setOpen] = useState(false);
  const [dialog, setdialog] = useState<any>({});
  const [pagination, setPagination] = useState(0);
  const [rowPagination, setRowPagination] = useState(20);
  const authToken = useAppSelector(token);
  const [analyst, setAnalyst] = useState<resultProps[]>([]);
  const [profession, setProfession] = useState<string[]>([]);
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
  const CustomTablePagination = CustomTablePaginationStyle(theme, colors);
  const [saveMsg, setSaveMsg] = useState("");
  const [btnopen, setBtnopen] = useState(false);
  const dispatch = useAppDispatch();

  const fetchProfession = async () => {
    try {
      const item = await getProfessionListAPI(authToken);
      setProfession(item.data.Data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleItemClick = (item: string) => {
    if (selectedOptions && !selectedOptions.includes(item)) {
      setSelectedOptions([...selectedOptions, item]);
    } else {
      setSelectedOptions(
        selectedOptions && selectedOptions.filter((ele) => ele !== item)
      );
    }
  };

  const handleSaveChanges = async (row: any) => {
    const response = await setUserSaveChangesAPI(
      authToken,
      selectedOptions,
      "Analyst",
      row.user_id
    );
    if (response.data.Status === 200) {
      setSaveMsg(response.data.Message);
      setBtnopen(true);
    }
    await fetchAnalyst();
    setOpen(false);
  };

  const handleAssignSuperAnalyst = async (row: any) => {
    //Imlementation of Super Analyst
  };

  const fetchAnalyst = async () => {
    const response: any = await getUserOrAnalystListAPI(authToken, "Analyst");
    setAnalyst(response.data.Data);
  };
  useEffect(() => {
    fetchProfession();
    fetchAnalyst();
    dispatch(set_Title("Analyst"));
  }, []);

  const handleChangePage = (
    event: any,
    newpage: React.SetStateAction<number>
  ) => {
    setPagination(newpage);
  };

  const handleChangeRowsPerPage = (event: { target: { value: string } }) => {
    setRowPagination(parseInt(event.target.value, 10));
    setPagination(0);
  };

  const handleClickOpen = (row: any) => {
    setdialog(row);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handelBtnSaveClose = () => {
    setBtnopen(false);
  };

  const handleRequestSort = (
    event: any,
    property: React.SetStateAction<string>
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  return (
    <>
      <Box
        marginLeft={2}
        marginRight={2}
        display={"flex"}
        flexDirection="column"
        className="container-Analyst"
      >
        <TableContainer>
          <Table stickyHeader={true} aria-label="User List Table">
            <EnhancedTableHead
              classes={classes}
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
              rowCount={analyst.length}
            />
            <TableBody>
              {stableSort(
                analyst.slice(
                  pagination * rowPagination,
                  pagination * rowPagination + rowPagination
                ),
                getComparator(order, orderBy)
              ).map(
                (
                  row: {
                    profession: SetStateAction<string[]>;
                    username: ReactNode;
                    user_id: ReactNode;
                    created_on: ReactNode;
                    is_active: any;
                    name: ReactNode;
                  },
                  index
                ) => {
                  return (
                    <TableRow hover key={index}>
                      <TableCell className="usertableCell" align="left">
                        {row.name}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.username}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.user_id}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.created_on}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.is_active ? "Active" : "Inactive"}
                      </TableCell>
                      <TableCell
                        className="usertableCell"
                        onClick={() => {
                          handleClickOpen(row);
                          setSelectedOptions(row.profession);
                        }}
                        align="left"
                      >
                        <BorderColorIcon />
                      </TableCell>
                    </TableRow>
                  );
                }
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Box alignSelf={"end"}>
          <CustomTablePagination
            rowsPerPageOptions={[10, 20, 30, { label: "All", value: -1 }]}
            colSpan={3}
            count={analyst.length}
            rowsPerPage={rowPagination}
            page={pagination}
            slotProps={{
              select: {
                "aria-label": "Analyst Pagination",
              },
              actions: {
                showFirstButton: true,
                showLastButton: true,
              } as any,
            }}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Box>
      </Box>

      {/* Dialoge Box (Model Box) */}

      <div>
        <Dialog
          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
          className="backdrop"
          sx={{
            "& .MuiDialog-paper": {
              background: `${colors.grey[800]} !important`,
            },
          }}
        >
          <DialogTitle>
            <Box display="flex" justifyContent="space-between">
              <Box></Box>
              <span onClick={handleClose}>
                <CloseSharpIcon sx={{ cursor: "pointer" }} />
              </span>
            </Box>
          </DialogTitle>

          <DialogContent>
            <DialogContentText align="left" id="alert-dialog-description">
              <div className="row">
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-xs-12 text-start">
                  <IconButton sx={{ p: 0 }}>
                    <Avatar
                      alt="Remy Sharp"
                      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmgW2DLEFPd8ci8mvSHV9iU6i2DJhxob9Pvg&usqp=CAU"
                    />
                  </IconButton>
                </div>

                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 text-start">
                  <Typography className="mt-2">
                    <span className="textFiled">User Name :-</span>
                    <span className="textFiled1 ms-1">{dialog.username}</span>
                  </Typography>
                </div>

                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12 text-end">
                  <Typography className="mt-2">
                    <span className="textFiled">User ID :-</span>
                    <span className="textFiled1 ms-1">{dialog.user_id}</span>
                  </Typography>
                </div>
              </div>

              <Box
                display="flex"
                justifyContent="space-between"
                className="mt-4"
              >
                <Typography className="textFiled">
                  Specialization Assignment
                </Typography>
              </Box>

              {/* Tag Slider */}
              <MultiSelectSlider
                options={profession}
                selectedOptions={selectedOptions}
                handleItemClick={handleItemClick}
              />
              <Box className="text-center mt-3">
                <div className="row">
                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography
                      align="center"
                      variant="h5"
                      sx={{ color: `${colors.grey[900]}` }}
                    >
                      Ideas of The Day
                    </Typography>

                    <Typography
                      align="center"
                      variant="h1"
                      sx={{ color: `${colors.greenAccent[500]}` }}
                    >
                      0
                    </Typography>
                  </div>

                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography
                      align="center"
                      variant="h5"
                      sx={{ color: `${colors.grey[900]}` }}
                    >
                      ThematicBaskets
                    </Typography>

                    <Typography
                      align="center"
                      variant="h1"
                      sx={{ color: `${colors.greenAccent[500]}` }}
                    >
                      0
                    </Typography>
                  </div>

                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography
                      align="center"
                      variant="h5"
                      sx={{ color: `${colors.grey[900]}` }}
                    >
                      PeerGroup
                    </Typography>

                    <Typography
                      align="center"
                      variant="h1"
                      sx={{ color: `${colors.greenAccent[500]}` }}
                    >
                      0
                    </Typography>
                  </div>

                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography
                      align="center"
                      variant="h5"
                      sx={{ color: `${colors.grey[900]}` }}
                    >
                      TradeExecutionIdea
                    </Typography>

                    <Typography
                      align="center"
                      variant="h1"
                      sx={{ color: `${colors.greenAccent[500]}` }}
                    >
                      0
                    </Typography>
                  </div>
                </div>
              </Box>
              <Box className="text-center mt-3">
                <Button
                  sx={{
                    border: `1px solid ${colors.greenAccent[500]}`,
                    borderRadius: "24px",
                    color: `${colors.grey[900]}`,
                    "&.MuiButton-root:hover": {
                      WebkitTextDecorationStyle: "none",
                      backgroundColor: `${colors.greenAccent[600]}`,
                    },
                  }}
                  className="outlinebtn"
                  variant="outlined"
                  color="success"
                  onClick={() => handleAssignSuperAnalyst(dialog)}
                >
                  Assign as Super Analyst
                </Button>
                <Button
                  sx={{
                    background: `${colors.greenAccent[500]}`,
                    borderRadius: "24px",
                    color: `${colors.grey[900]}`,
                    "&.MuiButton-root:hover": {
                      WebkitTextDecorationStyle: "none",
                      backgroundColor: `${colors.greenAccent[600]} !important`,
                    },
                  }}
                  variant="contained"
                  className="outlinebtn ms-3"
                  onClick={() => handleSaveChanges(dialog)}
                >
                  Save Changes
                </Button>
              </Box>
            </DialogContentText>
          </DialogContent>
        </Dialog>
        <Dialog
          open={btnopen}
          onClose={handelBtnSaveClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
          className="backdrop"
          sx={{
            "& .MuiDialog-paper": {
              background: `${colors.grey[800]} !important`,
            },
          }}
        >
          <DialogTitle>
            <Box display="flex" justifyContent="center">
              <TaskAltIcon
                fontSize="large"
                sx={{ color: `${colors.greenAccent[500]}`, fontSize: "60px" }}
              />
            </Box>
          </DialogTitle>
          <DialogContent>
            <DialogContentText
              display="flex"
              justifyContent="center"
              flexDirection="column"
              id="alert-dialog-description"
            >
              <Typography
                sx={{ color: `${colors.grey[900]}`, margin: "20px 0" }}
              >
                {saveMsg}
              </Typography>
              <Box alignSelf="center">
                <Button
                  sx={{
                    color: `${colors.grey[900]}`,
                    "&.MuiButton-root:hover": {
                      WebkitTextDecorationStyle: "none",
                      backgroundColor: `${colors.greenAccent[600]} !important`,
                    },
                  }}
                  variant="contained"
                  className="FilledBtn"
                  onClick={handelBtnSaveClose}
                >
                  Close
                </Button>
              </Box>
            </DialogContentText>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};
export default Analyst;
