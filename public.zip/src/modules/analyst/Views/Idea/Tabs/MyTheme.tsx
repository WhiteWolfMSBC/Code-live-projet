import { Box, Button, IconButton, Typography, useTheme } from "@mui/material";
import React, { useState } from "react";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import "./IdeaGeneratorTabs.scss";
import { tokens } from "../../../../../theme";
import CreateTemplate from "./CreateTemplate";

function MyTheams() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [createTemplate, setCreateTemplate] = useState(false);
  return (
    <>
      {!createTemplate && (
        <Box className="ideaGenaratorTabs_createTemplate">
          <Box display="flex" justifyContent={"space-between"}>
            <Box display={"flex"}>
              <Typography
                variant="h4"
                color={colors.greenAccent[500]}
                className="Typography"
              >
                My Template
              </Typography>
            </Box>

            <Box display={"flex"}>
              <IconButton size="large" color="inherit">
                <KeyboardArrowLeftIcon />
              </IconButton>

              <IconButton size="large" color="inherit">
                <KeyboardArrowRightIcon />
              </IconButton>

              <IconButton size="large" color="inherit">
                <CloseIcon />
              </IconButton>
            </Box>
          </Box>
          <Box
            display={"flex"}
            flexDirection={"column"}
            margin={"auto"}
            marginTop={29}
          >
            <Box alignSelf={"center"}>
              <Typography
                variant="h6"
                color={colors.grey[900]}
                className="Typographytxt"
                align="center"
              >
                There is no theme you created before please use the button to
                create a theme.
              </Typography>
            </Box>

            <Box alignSelf={"center"} marginTop={2}>
              <Button
                className="CreateIdea_btn"
                sx={{
                  backgroundColor: `${colors.greenAccent[500]}`,
                  color: `${colors.grey[900]}`,
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
                variant="contained"
                color="success"
                onClick={() => {
                  setCreateTemplate(true);
                }}
              >
                Create Template
              </Button>
            </Box>
          </Box>
        </Box>
      )}
      {createTemplate && <CreateTemplate />}
    </>
  );
}
export default MyTheams;
