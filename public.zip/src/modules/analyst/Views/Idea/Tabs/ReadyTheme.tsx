import { Box, IconButton, Typography, useTheme } from "@mui/material";
import React from "react";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import "./IdeaGeneratorTabs.scss";
import { tokens } from "../../../../../theme";

function ReadyTheme() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <div>
      <Box display="flex" justifyContent={"space-between"}>
        <Box display={"flex"}>
          <Typography
            variant="h4"
            color={colors.greenAccent[500]}
            className="Typography"
          >
            Ready Template
          </Typography>
        </Box>

        <Box display={"flex"}>
          <IconButton size="large" color="inherit">
            <KeyboardArrowLeftIcon />
          </IconButton>

          <IconButton size="large" color="inherit">
            <KeyboardArrowRightIcon />
          </IconButton>

          <IconButton size="large" color="inherit">
            <CloseIcon />
          </IconButton>
        </Box>
      </Box>

      <Box marginBottom={5}>
        <Typography
          variant="h6"
          color={colors.grey[900]}
          className="Typographytxt"
        >
          Select a starting point for your templete.
        </Typography>
      </Box>
    </div>
  );
}

export default ReadyTheme;
