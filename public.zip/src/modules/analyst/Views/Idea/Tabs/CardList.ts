import PhotoIcon from "@mui/icons-material/Photo";
import TextFieldsIcon from "@mui/icons-material/TextFields";
import FormatAlignLeftIcon from "@mui/icons-material/FormatAlignLeft";
import AnalyticsIcon from "@mui/icons-material/Analytics";
import LinkIcon from "@mui/icons-material/Link";
import AutoFixHighIcon from "@mui/icons-material/AutoFixHigh";
import AttachmentIcon from "@mui/icons-material/Attachment";
import PlayCircleFilledIcon from "@mui/icons-material/PlayCircleFilled";

export interface CardSchema {
  id: number;
  type: string;
  text: string;
  icon: any;
  required: boolean;
}

export const cardList: CardSchema[] = [
  {
    id: 1,
    type: "imageUpload",
    text: "Image Upload",
    icon: PhotoIcon,
    required: true,
  },
  {
    id: 2,
    type: "text",
    text: "Text",
    icon: TextFieldsIcon,
    required: true,
  },
  {
    id: 3,
    type: "textBox",
    text: "Text Box",
    icon: FormatAlignLeftIcon,
    required: true,
  },
  {
    id: 4,
    type: "chartUpload",
    text: "Chart Upload",
    icon: AnalyticsIcon,
    required: true,
  },
  {
    id: 5,
    type: "bestWayToTrade",
    text: "Best Way to Trade",
    icon: AutoFixHighIcon,
    required: true,
  },
  {
    id: 6,
    type: "mediaLink",
    text: "Media Link",
    icon: LinkIcon,
    required: true,
  },
  {
    id: 7,
    type: "videoUpload",
    text: "Video Upload",
    icon: PlayCircleFilledIcon,
    required: true,
  },
  {
    id: 8,
    type: "tag",
    text: "Tags",
    icon: AttachmentIcon,
    required: true,
  },
];
