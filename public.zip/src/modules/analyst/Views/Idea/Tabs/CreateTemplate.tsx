import { Box, Card, IconButton, Typography, useTheme } from "@mui/material";
import React, { useState } from "react";
import "./IdeaGeneratorTabs.scss";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import { tokens } from "../../../../../theme";
import { useAppDispatch, useAppSelector } from "../../../../../store/store";
import {
  addItemToIdeaTemplate,
  currentItem,
  set_Editor,
  updateOrSaveData,
} from "../../../../../store/Reducers/IdeaSlice";
import ImageUpload from "../../../../../components/CreateTemplateItems/ImageUpload";
import TextBox from "../../../../../components/CreateTemplateItems/TextBox";
import MediaLink from "../../../../../components/CreateTemplateItems/MediaLink";
import BestWayToTrade from "../../../../../components/CreateTemplateItems/BestWayToTrade";
import Text from "../../../../../components/CreateTemplateItems/Text";
import VideoUpload from "../../../../../components/CreateTemplateItems/VideoUpload";
import { cardList, CardSchema } from "./CardList";

function CreateTemplate() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const currItem = useAppSelector(currentItem);
  const dispatch = useAppDispatch();
  const [isDragging, setIsDragging] = useState(false);

  const handleClick = ({ type, data }: any) => {
    const item = {
      type: `${type}`,
      data: data,
    };
    dispatch(addItemToIdeaTemplate(item));
  };
  const handelDragStart = (
    e: React.DragEvent<HTMLDivElement>,
    type: string
  ) => {
    setIsDragging(true);
    e.dataTransfer.setData("text/plain", type);
  };

  function handleDragEnd(e: React.DragEvent<HTMLDivElement>) {
    setIsDragging(false);
    e.dataTransfer.clearData();
  }
  const saveAndClose = (data: any) => {
    console.log("saveAndClose", data);
    dispatch(updateOrSaveData(data));
  };

  const getCurrentData = (item: any): any => {
    switch (item.type) {
      case "imageUpload":
        return <ImageUpload saveAndClose={saveAndClose} data={item.data} />;
      case "text":
        return <Text saveAndClose={saveAndClose} data={item.data} />;
      case "textBox":
        return <TextBox saveAndClose={saveAndClose} data={item.data} />;
      case "mediaLink":
        return <MediaLink saveAndClose={saveAndClose} data={item.data} />;
      case "bestWayToTrade":
        return <BestWayToTrade saveAndClose={saveAndClose} data={item.data} />;
      case "videoUpload":
        return <VideoUpload saveAndClose={saveAndClose} data={item.data} />;
    }
  };

  return (
    <Box className="ideaGenaratorTabs_createTemplate">
      <Box display="flex" justifyContent={"space-between"}>
        <Box display={"flex"}>
          <Typography
            variant="h4"
            color={colors.greenAccent[500]}
            className="Typography"
          >
            Create Your Template
          </Typography>
        </Box>

        <Box display={"flex"}>
          <IconButton size="large" color="inherit">
            <KeyboardArrowLeftIcon  />
          </IconButton>

          <IconButton size="large" color="inherit">
            <KeyboardArrowRightIcon  />
          </IconButton>

          <IconButton size="large" color="inherit">
            <CloseIcon  />
          </IconButton>
        </Box>
      </Box>

      <Box marginBottom={5}>
        <Typography
          variant="h6"
          color={colors.grey[900]}
        >
          Drag any of blocks below into the idea preview on the right. You can
          create your own thesis step by step. You can use up 10 text boxes and
          graphics. Make sure your content is short and sharp.
        </Typography>
      </Box>

      {!currItem && (
        <Box justifyContent={"center"} marginTop={5}>
          <Box className="row">
            {cardList.map((item: CardSchema) => {
              return (
                <Box marginTop={2} className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
                  <Card
                    className="ideaGenarator_card"
                    draggable
                    onDragEnd={(e) => handleDragEnd(e)}
                    onDragStart={(e) => handelDragStart(e, `${item.type}`)}
                    sx={{
                      backgroundColor: `${colors.primary[400]}`,
                    }}
                    onClick={() => {
                      handleClick({ type: `${item.type}`, data: {} });
                      dispatch(set_Editor({ type: `${item.type}` }));
                    }}
                  >
                    <Typography
                      variant="h2"
                      color={colors.greenAccent[500]}
                      align="right"
                    >
                      {item.required ? "*" : ""}
                    </Typography>

                    <item.icon
                    className="Ideagenerator_item-Icon"
                    />
                    <Typography
                      variant="h5"
                      color={colors.grey[900]}
                      alignSelf="center"
                    >
                      {item.text}
                    </Typography>
                  </Card>
                </Box>
              );
            })}
          </Box>
        </Box>
      )}
      {currItem && getCurrentData(currItem)}
    </Box>
  );
}

export default CreateTemplate;
