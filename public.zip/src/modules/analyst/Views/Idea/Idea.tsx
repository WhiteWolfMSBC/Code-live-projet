import React, { useEffect, useState } from "react";
import "./Idea.scss";
import Box from "@mui/material/Box";
import { Button, TableContainer, Typography, useTheme } from "@mui/material";
import { Helmet } from "react-helmet";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import Tab from "@mui/material/Tab";
import CreateTemplate from "./Tabs/CreateTemplate";
import MyTheme from "./Tabs/MyTheme";
import ReadyTheme from "./Tabs/ReadyTheme";
import {
  set_Editor,
  ideaTemplate,
  set_CurrentItem,
  deleteData,
} from "../../../../store/Reducers/IdeaSlice";
import { tokens } from "../../../../theme";
import { useAppDispatch, useAppSelector } from "../../../../store/store";
import { set_Title } from "../../../../store/Reducers/TopBarSlice";
import PlusSvgIcon from "./SvgIcon";
import ImageUploadRight from "../../../../components/RightSideCreateTemplate/ImageUploadRight";
import TextRight from "../../../../components/RightSideCreateTemplate/TextRight";
import TextBoxRight from "../../../../components/RightSideCreateTemplate/TextBoxRight";
import MediaLinkRight from "../../../../components/RightSideCreateTemplate/MediaLinkRight";
import VideoUploadRight from "../../../../components/RightSideCreateTemplate/VideoUploadRight";
import BestWayToTradeRight from "../../../../components/RightSideCreateTemplate/BestWayToTradeRight";

function Idea() {
  const [value, setValue] = React.useState("1");
  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  // Right

  const ideas = useAppSelector(ideaTemplate);
  const dispatch = useAppDispatch();

  const [isOver, setIsOver] = useState(false);

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    const dataJSON: any = e.dataTransfer.getData("text/plain");
    console.log(dataJSON);
    dispatch(set_Editor({ type: dataJSON }));
    console.log(dataJSON);
  };

  function handleDragLeave() {
    setIsOver(false);
  }

  function handleDragOver(e: React.DragEvent<HTMLDivElement>) {
    if (e.dataTransfer.types[0] === "text/plain") {
      setIsOver(true);
      e.preventDefault();
    }
  }

  const handleEdit = (data: any) => {
    console.log("On Edit", data);
    dispatch(set_CurrentItem(data));
  };
  const handleDelete = (data: any) => {
    console.log("delete item", data);
    dispatch(deleteData(data));
  };

  useEffect(() => {
    console.log("idea", ideas);
  }, [ideas]);
  useEffect(() => {
    dispatch(set_Title("Idea"));
  }, [dispatch]);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Analyst | Idea Generator</title>
      </Helmet>
      {/* Create Idea */}

      <Box marginLeft={2} marginRight={2} className="container-CreateIdea">
        <Box
          className="CreateIdea-Box"
          sx={{ backgroundColor: `${colors.primary[400]}` }}
          display="flex"
          justifyContent={"space-between"}
        >
          <Box display={"flex"}>
            <Typography
              variant="h3"
              className="CreateIdea_txt"
              sx={{
                color: `${colors.grey[900]}`,
              }}
            >
              Create an Idea for "One Idea Per Day"
            </Typography>
          </Box>

          <Box display={"flex"}>
            <Button
              className="CreateIdea_btn"
              sx={{
                color: `${colors.grey[900]}`,
                border: `1px solid ${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
              variant="outlined"
              color="success"
            >
              <RemoveRedEyeIcon
                fontSize="small"
                className="me-3"
                sx={{
                  color: `${colors.grey[900]}`,
                }}
              />
              Preview
            </Button>

            <Button
              className="CreateIdea_btn ms-3"
              sx={{
                color: `${colors.grey[800]}`,
                background: `${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
              variant="contained"
              color="success"
            >
              Submit For Approval
            </Button>
          </Box>
        </Box>

        {/* Tabs (Body) */}

        <Box className="CreateIdea-Box1" marginTop={5}>
          <Box className="row">
            <Box className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <Box>
                <TabContext value={value}>
                  <TabList onChange={handleChange} className="tablist" sx={{}}>
                    <Tab
                      id="applicationTabletabs"
                      sx={{
                        color: `${colors.grey[900]}`,
                        backgroundColor: `${colors.primary[400]}`,
                      }}
                      className="applicationtab"
                      label="Create Template"
                      value="1"
                    />
                    <Tab
                      sx={{
                        color: `${colors.grey[900]}`,
                        backgroundColor: `${colors.primary[400]}`,
                      }}
                      className="applicationtab"
                      label="Ready Template"
                      value="2"
                    />
                    <Tab
                      sx={{
                        color: `${colors.grey[900]}`,
                        backgroundColor: `${colors.primary[400]}`,
                      }}
                      className="applicationtab"
                      label="My Template"
                      value="3"
                    />
                  </TabList>

                  <TableContainer
                    className="tableContainer"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                  >
                    <TabPanel value="1">
                      <CreateTemplate />
                    </TabPanel>
                    <TabPanel value="2">
                      <ReadyTheme />
                    </TabPanel>
                    <TabPanel value="3">
                      <MyTheme />
                    </TabPanel>
                  </TableContainer>
                </TabContext>
              </Box>
            </Box>

            <Box className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <Box
                className="Body_DargObjectBox"
                display={"flex"}
                flexDirection={"column"}
                onDrop={handleDrop}
                onDragOver={(e) => handleDragOver(e)}
                onDragLeave={handleDragLeave}
                sx={{
                  maxHeight: "400px",
                  backgroundColor: `${colors.primary[400]}`,
                  padding: "12px 16px 12px 16px",
                }}
              >
                {ideas.length === 0 && (
                  <>
                    <Box alignSelf={"center"} margin="auto">
                      <Box alignSelf={"center"}>
                        <PlusSvgIcon />

                        <Typography
                          variant="h5"
                          color={colors.grey[900]}
                          align="center"
                        >
                          Drag Objects to Create
                        </Typography>
                      </Box>
                    </Box>
                  </>
                )}
                {ideas.map((item: any) => {
                  switch (item.type) {
                    case "imageUpload":
                      return (
                        <ImageUploadRight
                          data={item?.data ?? {}}
                          handleEdit={() => handleEdit(item)}
                          handleDelete={() => handleDelete(item)}
                        />
                      );
                    case "text":
                      return (
                        <TextRight
                          data={item?.data ?? {}}
                          handleEdit={() => handleEdit(item)}
                          handleDelete={() => handleDelete(item)}
                        />
                      );
                    case "textBox":
                      return (
                        <TextBoxRight
                          data={item?.data ?? {}}
                          handleEdit={() => handleEdit(item)}
                          handleDelete={() => handleDelete(item)}
                        />
                      );
                    case "mediaLink":
                      return (
                        <MediaLinkRight
                          data={item?.data ?? {}}
                          handleEdit={() => handleEdit(item)}
                          handleDelete={() => handleDelete(item)}
                        />
                      );
                    case "bestWayToTrade":
                      return (
                        <BestWayToTradeRight
                          data={item?.data ?? {}}
                          handleEdit={() => handleEdit(item)}
                          handleDelete={() => handleDelete(item)}
                        />
                      );
                    case "videoUpload":
                      return (
                        <VideoUploadRight
                          data={item?.data ?? {}}
                          handleEdit={() => handleEdit(item)}
                          handleDelete={() => handleDelete(item)}
                        />
                      );
                  }
                  return null;
                })}
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
}

export default Idea;
