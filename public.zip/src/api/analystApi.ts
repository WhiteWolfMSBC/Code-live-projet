import axios from "axios";
import { IMAGEUPLOAD_URL } from "../utils/constants";

export const upalodImageAPI = async (files: any, token: string) => {
  console.log("files", files);
  return await axios.post(IMAGEUPLOAD_URL, files, {
    headers: {
      Authorization: `token ${token}`,
    },
  });
};
