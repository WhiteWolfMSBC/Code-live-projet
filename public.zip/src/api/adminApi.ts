import axios from "axios";
import { PROFESSION_URL, USER_LIST } from "../utils/constants";

export const getUserOrAnalystListAPI = async (token: string, type: string) => {
  return await axios.get(USER_LIST, {
    params: {
      type: `${type}`,
    },
    headers: {
      Authorization: `token ${token}`,
    },
  });
};

export const getProfessionListAPI = async (token: string) => {
  return await axios.get(PROFESSION_URL, {
    headers: {
      Authorization: `token ${token}`,
    },
  });
};

export const setUserSaveChangesAPI = async (
  token: string,
  options: string[],
  type: string,
  userid: string
) => {
  return await axios.post(
    USER_LIST,
    {
      userid: `${userid}`,
      type: `${type}`,
      profession: `${options}`,
    },
    {
      headers: {
        Authorization: `token ${token}`,
      },
    }
  );
};
