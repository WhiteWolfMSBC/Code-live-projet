import axios from "axios";
import { FORGOT_URL, LOGIN_URL, REGISTER_URL } from "../utils/constants";

export const loginAPI = async (
  username: string | null,
  password: string | null
) => {
  return await axios.post(LOGIN_URL, {
    username: username,
    password: password,
  });
};

export const registerAPI = async (
  username: string | null,
  password: string | null,
  firstName: string | null,
  lastName: string | null,
  emailId: string | null,
  phone: string | null
) => {
  return await axios.post(REGISTER_URL, {
    username: `${username && username.toLocaleLowerCase()}`,
    password: `${password}`,
    first_name: `${firstName}`,
    last_name: `${lastName}`,
    email: `${emailId}`,
    contact_number: `${phone}`,
  });
};

export const forgotEmailAPI = async (emilId: string, type: string) => {
  return await axios.post(FORGOT_URL, {
    email: emilId,
    type: "otp_send",
  });
};

export const otpValidationAPI = async (emailId: string, OTP: string) => {
  return await axios.post(FORGOT_URL, {
    email: emailId,
    otp: parseInt(OTP),
    type: "otp_verify",
  });
};

export const resetPasswordAPI = async (
  emailId: string,
  password: string,
) => {
  return await axios.post(FORGOT_URL, {
    email: emailId,
    password: password,
    type: "change_password",
  });
};
