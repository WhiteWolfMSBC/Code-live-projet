import React from "react";
import { Helmet } from "react-helmet";
import { Box, IconButton, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";
import "./CreateTemplateRightSide.scss";

const TextRight = (props: any) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Text</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="createTemplate-Container_RightSide">
        <Box className="textEditor_Box" marginTop={2}>
          <Box>
            {/* Main Buttons */}
            <Box
              display="flex"
              justifyContent={"space-between"}
              className="container_IconBtn"
              sx={{
                background: `${colors.primary[600]}`,
              }}
            >
              <Box display={"flex"}>
                <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                  <ControlCameraIcon />
                </IconButton>
              </Box>

              <Box display={"flex"}>
                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                  onClick={() => props.handleEdit()}
                >
                  <BorderColorIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <AddBoxIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                  onClick={() => props.handleDelete()}
                >
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Box>
          </Box>
          <Box
            display="flex"
            flexDirection="column"
            className="tagsBtn_Container"
          >
            <Box
              alignSelf={"left"}
              marginTop={2}
              marginRight={4}
              marginLeft={4}
            >
              <Typography variant="h5" marginBottom={2}>
                {props?.data?.text ?? ""}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};
export default TextRight;
