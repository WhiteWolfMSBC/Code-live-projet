import {
  Box,
  Card,
  FormControl,
  IconButton,
  Typography,
  useTheme,
} from "@mui/material";
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { tokens } from "../../theme";
import ArrowCircleUpIcon from "@mui/icons-material/ArrowCircleUp";
import { useDropzone } from "react-dropzone";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";
import "./CreateTemplateRightSide.scss";
import { useAppSelector } from "../../store/store";
import { token } from "../../store/Reducers/UserSlice";
import { upalodImageAPI } from "../../api/analystApi";

const ImageUploadRight = (props: any) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [files, setFiles] = useState<any[]>([]);
  const authToken = useAppSelector(token);

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      "image/jpeg": [],
      "image/png": [],
      "image/jpg": [],
    },
    onDrop: (acceptedFiles: any) => {
      setFiles(
        acceptedFiles.map((file: any) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      );
      console.log("acceptedFiles", acceptedFiles);
      let formData = new FormData();
      formData.append("image", acceptedFiles[0]);
      const response = upalodImageAPI(formData, authToken);
      console.log("response", response);
      console.log("formdata", formData);
    },
  });

  const thumbs = files.map((file: any) => (
    <Box>
      <Box>
        <img
          className="ImageUpload_Image"
          height={"100%"}
          width={"100%"}
          src={file.preview}
          alt={file.name}
        />
      </Box>
    </Box>
  ));

  console.log({ thumbs });

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ImageUpload</title>
      </Helmet>

      <Box className="createTemplate-Container_RightSide">
        <Box className="textEditor_Box" marginTop={2}>
          <Box>
            {/* Main Buttons */}
            <Box
              display="flex"
              className="container_IconBtn"
              justifyContent={"space-between"}
              sx={{
                background: `${colors.primary[600]}`,
              }}
            >
              <Box display={"flex"}>
                <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                  <ControlCameraIcon />
                </IconButton>
              </Box>

              <Box display={"flex"}>
                <IconButton
                  onClick={() => props.handleEdit()}
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <BorderColorIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <AddBoxIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                  onClick={() => props.handleDelete()}
                >
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Box>
          </Box>
          <Box
            display="flex"
            className="tagsBtn_Container"
            flexDirection="column"
          >
            {files.length === 0 ? (
              <Box
                marginTop={2}
                marginRight={4}
                marginLeft={4}
                display="flex"
                justifyContent={"space-between"}
              >
                <Box display={"flex"}>
                  <Card
                    className="createTemplate_card "
                    sx={{
                      backgroundColor: `${colors.primary[400]}`,
                    }}
                  >
                    <Box
                      alignSelf={"center"}
                      {...getRootProps({ className: "dropzone" })}
                    >
                      <input {...getInputProps()} />

                      <ArrowCircleUpIcon
                        className="createTemplate_ArrowCircleUpIcon"
                        sx={{
                          color: `${colors.greenAccent[500]}`,
                        }}
                      />
                    </Box>

                    <Box alignSelf={"center"}>
                      <Typography
                        className="text-center"
                        draggable="true"
                        variant="h5"
                        marginTop={5}
                      >
                        Drag and drop files to upload
                      </Typography>
                    </Box>
                  </Card>
                </Box>

                <Box display={"flex"}>
                  <Box alignSelf={"center"}>
                    <Typography variant="h5">or</Typography>
                  </Box>
                </Box>

                <Box display={"flex"}>
                  <Box
                    alignSelf={"center"}
                    {...getRootProps({ className: "dropzone" })}
                  >
                    <input {...getInputProps()} />
                    <Typography variant="h5">Choose Your File</Typography>
                  </Box>
                </Box>
              </Box>
            ) : (
              <Box>
                <aside>{thumbs}</aside>
              </Box>
            )}
          </Box>
        </Box>

        <Box className="textEditor_Box" marginTop={2}>
          <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <Typography
                variant="h5"
                sx={{ color: `${colors.grey[900]}` }}
                marginBottom={2}
              >
                {props?.data?.imageCaption ?? ""}
              </Typography>
            </FormControl>
          </Box>
        </Box>
      </Box>
    </>
  );
};
export default ImageUploadRight;
