import {
  Box,
  Card,
  FormControl,
  IconButton,
  Typography,
  useTheme,
} from "@mui/material";
import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { tokens } from "../../theme";
import { useDropzone } from "react-dropzone";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";
import "./CreateTemplateRightSide.scss";
import ReactPlayer from "react-player";

const VideoUploadRight = (props: any) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [play, setPlay] = useState(false);
  const videoLink = props?.data?.videoUrl ?? "";

  console.log(videoLink);

  const handleMouseEnter = () => {
    setPlay(true);
  };
  const handleMouseLeave = () => {
    setPlay(false);
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | VideoUpload</title>
      </Helmet>

      <Box className="createTemplate-Container_RightSide">
        <Box className="textEditor_Box" marginTop={2}>
          <Box>
            {/* Main Buttons */}
            <Box
              display="flex"
              justifyContent={"space-between"}
              className="container_IconBtn"
              sx={{
                background: `${colors.primary[600]}`,
              }}
            >
              <Box display={"flex"}>
                <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                  <ControlCameraIcon />
                </IconButton>
              </Box>

              <Box display={"flex"}>
                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                  onClick={() => props.handleEdit()}
                >
                  <BorderColorIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <AddBoxIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                  onClick={() => props.handleDelete()}
                >
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Box>
          </Box>

          {videoLink.length > 0 ? (
            <Box
              display="flex"
              flexDirection="column"
              className="tagsBtn_Container"
            >
              <Box margin={2}>
                <Card
                  className="createTemplate_card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                    color: `${colors.greenAccent[500]}`,
                    width: "100%",
                    height: "100%",
                  }}
                >
                  {/* Video */}

                  <Box
                    onMouseEnter={handleMouseEnter}
                    onMouseLeave={handleMouseLeave}
                  >
                    <ReactPlayer
                      width={"100%"}
                      maxHeight={"100%"}
                      playing={play}
                      pip
                      controls={true}
                      config={{ file: { forceHLS: true } }}
                      url={videoLink}
                    />
                  </Box>
                </Card>
              </Box>
            </Box>
          ) : null}
        </Box>

        <Box className="textEditor_Box" marginTop={2}>
          <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <Typography
                variant="h5"
                sx={{ color: `${colors.grey[900]}` }}
                marginBottom={2}
              >
                {props?.data?.videoCaption ?? ""}
              </Typography>
            </FormControl>
          </Box>
        </Box>
      </Box>
    </>
  );
};
export default VideoUploadRight;
