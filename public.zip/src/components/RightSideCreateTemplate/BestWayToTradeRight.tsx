import React, { useEffect } from "react";
import "./CreateTemplateRightSide.scss";
import { Helmet } from "react-helmet";
import {
  Box,
  Button,
  FormControl,
  IconButton,
  Typography,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";
import "./CreateTemplateRightSide.scss";

const BestWayToTradeRight = (props: any) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const tags = ["#bullish", "#bearish", "#options"];
  useEffect(() => {
    console.log("data", props.data);
    console.log(props?.data?.bestWayToTrade?.subTitle);
  }, [props.data]);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | BestWayToTrade</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="createTemplate-Container_RightSide">
        <Box className="textEditor_Box" marginTop={2}>
          <Box>
            {/* Main Buttons */}
            <Box
              className="container_IconBtn"
              display="flex"
              justifyContent={"space-between"}
              sx={{
                background: `${colors.primary[600]}`,
              }}
            >
              <Box display={"flex"}>
                <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                  <ControlCameraIcon />
                </IconButton>
              </Box>

              <Box display={"flex"}>
                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                  onClick={() => props.handleEdit()}
                >
                  <BorderColorIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <AddBoxIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                  onClick={() => props.handleDelete()}
                >
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Box>
          </Box>

          <Box
            display="flex"
            flexDirection="column"
            className="tagsBtn_Container"
          >
            <Box
              alignSelf={"center"}
              marginTop={2}
              marginRight={4}
              marginLeft={8}
            >
              {/* Perform mapping in Buttons */}
              {tags.map((item: any) => {
                return (
                  <Button
                    className="me-3 tagBtn_Button"
                    sx={{
                      color: `${colors.grey[900]}`,
                      "&.MuiButton-root:hover": {
                        WebkitTextDecorationStyle: "none",
                        backgroundColor: `${colors.greenAccent[600]} !important`,
                      },
                    }}
                  >
                    {item}
                  </Button>
                );
              })}
            </Box>

            <Box
              alignSelf={"center"}
              marginTop={2}
              marginRight={4}
              marginLeft={13}
            >
              <Typography
                variant="h1"
                sx={{ color: `${colors.grey[900]}`, fontWeight: 700 }}
              >
                {props?.data?.bestWayToTrade?.subTitle ?? ""}
              </Typography>

              <Typography marginTop={2} variant="h5">
                The lowest price of{" "}
                {props?.data?.bestWayToTrade?.fundName ?? ""} in this idea{" "}
                <br /> {props?.data?.bestWayToTrade?.tradePrice ?? ""}
              </Typography>
            </Box>
          </Box>

          {/* Buttons */}

          <Box
            display="flex"
            flexDirection="row"
            alignSelf="center"
            marginTop={2}
            marginLeft={40}
          >
            <FormControl>
              <Button
                className="ViewInvestmentChannels-Button"
                sx={{
                  background: `${colors.greenAccent[500]}`,
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
              >
                <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                  View Investment Channels
                </Typography>
              </Button>
            </FormControl>
          </Box>
        </Box>
      </Box>
    </>
  );
};
export default BestWayToTradeRight;
