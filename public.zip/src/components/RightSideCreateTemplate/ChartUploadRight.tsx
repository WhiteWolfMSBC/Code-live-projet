import { Box, Card, IconButton, Typography, useTheme } from "@mui/material";
import React from "react";
import { Helmet } from "react-helmet";
import { tokens } from "../../theme";
import ArrowCircleUpIcon from "@mui/icons-material/ArrowCircleUp";
import { useDropzone } from "react-dropzone";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";
import "./CreateTemplateRightSide.scss";

const ChartUploadRight = (props: any) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const { acceptedFiles, getRootProps, getInputProps } = useDropzone({
    accept: {
      "image/jpeg": [],
      "image/png": [],
      "image/jpg": [],
    },
  });

  const acceptedFileItems = acceptedFiles.map((file: any) => (
    <li key={file.path}>
      {file.path} - {file.size} bytes
    </li>
  ));

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ChartUpload</title>
      </Helmet>

      <Box className="createTemplate-Container_RightSide">
        <Box className="textEditor_Box" marginTop={2}>
          <Box>
            {/* Main Buttons */}
            <Box
              display="flex"
              className="container_IconBtn"
              justifyContent={"space-between"}
              sx={{
                background: `${colors.primary[600]}`,
              }}
            >
              <Box display={"flex"}>
                <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                  <ControlCameraIcon />
                </IconButton>
              </Box>

              <Box display={"flex"}>
                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <BorderColorIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <AddBoxIcon />
                </IconButton>

                <IconButton
                  size="large"
                  color="inherit"
                  sx={{ color: `${colors.grey[900]}` }}
                >
                  <DeleteIcon />
                </IconButton>
              </Box>
            </Box>
          </Box>
          <Box
            display="flex"
            flexDirection="column"
            sx={{ padding: "20px 30px 20px 30px" }}
          >
            <Box
              marginTop={2}
              marginRight={4}
              marginLeft={4}
              display="flex"
              justifyContent={"space-between"}
            >
              <Box display={"flex"}>
                <Card
                  className="createTemplate_card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <Box
                    alignSelf={"center"}
                    {...getRootProps({ className: "dropzone" })}
                  >
                    <input {...getInputProps()} />

                    <ArrowCircleUpIcon
                    className="createTemplate_ArrowCircleUpIcon"
                      sx={{
                        color: `${colors.greenAccent[500]}`,
                      }}
                    />
                  </Box>

                  <Box alignSelf={"center"}>
                    <Typography
                      className="text-center"
                      draggable="true"
                      variant="h5"
                      marginTop={5}
                    >
                      Drag and drop files to upload
                    </Typography>
                  </Box>
                </Card>
              </Box>

              <Box display={"flex"}>
                <Box alignSelf={"center"}>
                  <Typography variant="h5">or</Typography>
                </Box>
              </Box>

              <Box display={"flex"}>
                <Box
                  alignSelf={"center"}
                  {...getRootProps({ className: "dropzone" })}
                >
                  <input {...getInputProps()} />
                  <Typography variant="h5">Choose Your File</Typography>
                </Box>
              </Box>
            </Box>
            <Box marginTop={2} marginRight={4} marginLeft={32}>
              <Card
                className="createTemplate_card"
                sx={{
                  backgroundColor: `${colors.primary[400]}`,
                  color: `${colors.greenAccent[500]}`,
                }}
              >
                <Typography>{acceptedFileItems}</Typography>
              </Card>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};
export default ChartUploadRight;
