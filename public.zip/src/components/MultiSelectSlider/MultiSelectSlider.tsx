import LeftArrowDark from "../../assets/left-arrow.png";
import RightArrowDark from "../../assets/right-arrow.png";
import LeftArrowLight from "../../assets/left-arrow-white.png";
import RightArrowLight from "../../assets/right-arrow-white.png";
import "./MultiSelectSlider.scss";
import React, { useRef } from "react";
import { Box, useTheme } from "@mui/material";
import { tokens } from "../../theme";

export interface MultiSelectSliderSchema {
  options: string[];
  selectedOptions: string[];
  handleItemClick: any;
}
function MultiSelectSlider(props: MultiSelectSliderSchema) {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const ref = useRef(document.createElement("div"));
  const scrollHandler = (scrollOffset: any) => {
    if (ref) {
      ref.current.scrollLeft += scrollOffset;
    }
  };

  return (
    <>
      <Box className="container_tag-container">
        <Box className="left-arrow" onClick={() => scrollHandler(-100)}>
          {theme.palette.mode === "dark" ? (
            <img src={LeftArrowDark} alt="left-arrow"></img>
          ) : (
            <img src={LeftArrowLight} alt="left-arrow"></img>
          )}
        </Box>

        <Box ref={ref} className="item-container">
          {props.options.map((item: string, index) => {
            return (
              <Box
                key={index}
                className="item"
                style={{
                  backgroundColor: `${
                    props.selectedOptions.includes(item)
                      ? "#4E33FF"
                      : "transparent"
                  }`,
                  border: `1px solid ${colors.grey[900]}`,
                  color: `${
                    props.selectedOptions.includes(item)
                      ? "white"
                      : `${colors.grey[900]}`
                  }`,
                }}
                onClick={() => props.handleItemClick(item)}
              >
                {item}
              </Box>
            );
          })}
        </Box>
        <Box className="right-arrow" onClick={() => scrollHandler(100)}>
          {theme.palette.mode === "dark" ? (
            <img src={RightArrowDark} alt="right-arrow"></img>
          ) : (
            <img src={RightArrowLight} alt="right-arrow"></img>
          )}
        </Box>
      </Box>
    </>
  );
}

export default MultiSelectSlider;
