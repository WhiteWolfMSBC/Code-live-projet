import React from "react";
import "./CreateTemplateItems.css";
import { Helmet } from "react-helmet";
import { Box, Button, FormControl, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function Tags() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Tags</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="textEditor_Box">
        <Box display="flex" flexDirection="column">
          <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
            <Typography marginBottom={2}>Tags Edit</Typography>

            {/* Perform mapping in Buttons */}

            <Button
              className="me-3"
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              #bullish
            </Button>
            <Button
              className="me-3"
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              #bearish
            </Button>
            <Button
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              #options
            </Button>
          </Box>
        </Box>

        {/* Buttons */}

        <Box
          display="flex"
          flexDirection="row"
          alignSelf="left"
          marginTop={30}
          marginLeft={4}
        >
          <FormControl>
            <Button
              sx={{
                background: `${colors.greenAccent[500]}`,
                margin: "12px 0 12px 0",
                height: "40px",
                borderRadius: "24px !important",
                fontWeight: "700",
                padding: "20px 60px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                Save & Close
              </Typography>
            </Button>
          </FormControl>

          <FormControl>
            <Typography
              variant="h6"
              sx={{
                color: `${colors.grey[100]}`,
                fontWeight: "700",
                padding: "21px 20px",
              }}
            >
              We'll autosave every 20 seconds
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
