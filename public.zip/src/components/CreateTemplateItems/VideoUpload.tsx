import React, { useEffect, useState } from "react";
import JoditReact from "jodit-react-ts";
import "jodit/build/jodit.min.css";
import "./TextEditor.scss";
import { Helmet } from "react-helmet";
import { Box, Button, FormControl, TextField, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function VideoUpload({ saveAndClose, data }: any) {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [value, setValue] = useState<string>(
    data && data?.videoCaption ? data.videoCaption : ""
  );
  const [videoLink, setVideoLink] = useState(data && data?.videoUrl ? data.videoUrl : "");
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setVideoLink(e.target.value);
  };
  useEffect(() => {
    setVideoLink(data && data?.videoUrl ? data.videoUrl : "");
    setValue(data && data?.videoCaption ? data.videoCaption : "");
  }, [data]);


  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | VideoUpload</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="container-CreateTemplate_TxtEditor">
        <Box className="textEditor_Box">
          <Box display="flex" flexDirection="column">
            <Box
              alignSelf={"left"}
              marginTop={2}
              marginRight={4}
              marginLeft={4}
              marginBottom={2}
            >
              <FormControl
                variant="filled"
                size="small"
                className="field-container"
              >
                <TextField
                  className="Createtemplate-VideoUpload_TxtField"
                  required
                  id="emailId"
                  variant="filled"
                  label="Add Video URL in editor, drop a previw image here"
                  onChange={handleChange}
                  value={videoLink}
                  placeholder="&#x2709;"
                  type="text"
                  size="small"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                    "& .MuiInputBase-root": {
                      color: `${colors.grey[900]}`,
                    },
                    "& .MuiFilledInput-input": {
                      color: `${colors.grey[400]} !important`,
                    },
                  }}
                />
              </FormControl>
            </Box>


            {/* TextEditor */}

            <Box
              alignSelf={"left"}
              marginTop={2}
              marginRight={4}
              marginLeft={4}
              sx={{
                "& .jodit-container:not(.jodit_inline)": {
                  backgroundColor: `${colors.primary[400]}`,
                },
                "& .jodit,.jodit *,.jodit-container,.jodit-container *": {
                  border: "none",
                  backgroundColor: `${colors.primary[400]}`,
                  color: `${colors.grey[400]}`,
                },
              }}
            >
              <JoditReact
                onChange={(content: any) => setValue(content)}
                defaultValue={value}
              />
            </Box>
          </Box>

          {/* Buttons */}

          <Box
            display="flex"
            flexDirection="row"
            alignSelf="left"
            marginRight={4}
            marginLeft={4}
          >
            <FormControl>
              <Button
                className="wayToTrade_saveAndClosebtn"
                sx={{
                  background: `${colors.greenAccent[500]}`,
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
                onClick={() =>
                  saveAndClose({
                    data: { videoCaption: value, videoUrl: videoLink },
                  })
                }
              >
                Save & Close
              </Button>
            </FormControl>

            <FormControl>
              <Typography
                className="wayToTrade_Autosave"
                variant="h6"
                sx={{
                  color: `${colors.grey[100]}`,
                }}
              >
                We'll autosave every 20 seconds
              </Typography>
            </FormControl>
          </Box>
        </Box>
      </Box>
    </>
  );
}
