import React from "react";
import "./ChartUpload.scss";
import { Helmet } from "react-helmet";
import { Box, Button, Card, FormControl, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function ChartUpload() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ChartUpload</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="container-Chartupload">
        {/* Cards */}

        <Box justifyContent={"center"} marginTop={5}>
          {/* 1st Row */}

          <Box>
            <div className="row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <img
                    className="Card-img"
                    src={
                      "https://www.tibco.com/sites/tibco/files/media_entity/2022-01/PieChart-01.svg"
                    }
                    alt=""
                  />
                </Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <img
                    className="Card-img"
                    src={
                      "https://www.ft.com/__origami/service/image/v2/images/raw/ftcms%3A347ece48-0f69-11e9-a3aa-118c761d2745?source=ig"
                    }
                    alt=""
                  />
                </Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <img
                    className="Card-img"
                    src={
                      "https://docs.moodle.org/dev/images_dev/c/c5/bar_chart.png"
                    }
                    alt=""
                  />
                </Card>
              </div>
            </div>
          </Box>

          {/* 2nd Row */}

          <Box marginTop={2}>
            <div className="row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                ></Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                ></Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                ></Card>
              </div>
            </div>
          </Box>
        </Box>

        {/* Buttons */}

        <Box display="flex" flexDirection="row" alignSelf="left">
          <FormControl>
            <Button
              className="wayToTrade_saveAndClosebtn"
              sx={{
                background: `${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              Save & Close
            </Button>
          </FormControl>

          <FormControl>
            <Typography
              className="wayToTrade_Autosave"
              variant="h6"
              sx={{
                color: `${colors.grey[100]}`,
              }}
            >
              We'll autosave every 20 seconds
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
