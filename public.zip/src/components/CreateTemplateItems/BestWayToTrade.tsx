import React, { useEffect, useState } from "react";
import "./TextField.scss";
import { Helmet } from "react-helmet";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function BestWayToTrade({ saveAndClose, data }: any) {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [subTitle, setSubTitle] = useState(
    data && data?.bestWayToTrade && data?.bestWayToTrade?.subTitle
      ? data.bestWayToTrade?.subTitle
      : ""
  );
  const [link, setLink] = useState(
    data && data?.bestWayToTrade && data.bestWayToTrade?.fundName
      ? data.bestWayToTrade?.fundName
      : ""
  );
  const tags = ["#bullish", "#bearish", "#options"];
  const [price, setPrice] = useState(
    data && data?.bestWayToTrade && data.bestWayToTrade?.price
      ? data.bestWayToTrade?.price
      : ""
  );

  const handleChange = (event: SelectChangeEvent) => {
    setLink(event.target.value as string);
  };
  const handleTitleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setSubTitle(e.target.value);
  };

  const handlePriceChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setPrice(e.target.value);
  };

  useEffect(() => {
    setSubTitle(
      data && data?.bestWayToTrade && data?.bestWayToTrade?.subTitle
        ? data.bestWayToTrade?.subTitle
        : ""
    );
    setPrice(
      data && data?.bestWayToTrade && data.bestWayToTrade?.price
        ? data.bestWayToTrade?.price
        : ""
    );
    setLink(
      data && data?.bestWayToTrade && data.bestWayToTrade?.fundName
        ? data.bestWayToTrade?.fundName
        : ""
    );
  }, [data]);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | BestWayToTrade</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="container-CreateTemplate_TxtField">
        <Box className="textEditor_Box">
          <Box display="flex" flexDirection="column">
            <Box
              alignSelf={"center"}
              marginTop={4}
              marginRight={4}
              marginLeft={4}
            >
              {/* 1 textfield */}
              <Typography marginBottom={1}>Subtitle Edit</Typography>

              <FormControl
                variant="filled"
                size="small"
                className="field-container"
              >
                <TextField
                  className="wayToTrade_TxtField"
                  required
                  id="emailId"
                  variant="filled"
                  value={subTitle}
                  placeholder="&#x2709;"
                  onChange={handleTitleChange}
                  type="text"
                  size="small"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                    "& .MuiInputBase-root": {
                      color: `${colors.grey[900]}`,
                    },
                    "& .MuiFilledInput-input": {
                      color: `${colors.grey[400]} !important`,
                    },
                  }}
                />
              </FormControl>
            </Box>

            <Box
              alignSelf={"center"}
              marginTop={4}
              marginRight={4}
              marginLeft={4}
            >
              {/* 2 & 3 textfield  (Select, textfiled)*/}
              <Box className="row" alignSelf={"center"}>
                <Box
                  className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6"
                  alignSelf={"center"}
                >
                  <Typography marginBottom={1}>Fund Choose</Typography>

                  <FormControl
                    variant="filled"
                    size="small"
                    className="field-container"
                  >
                    <InputLabel id="mediaLink">Funds name</InputLabel>
                    <Select
                      className="createTemplate-WayToTrade_Select"
                      labelId="mediaLink"
                      required
                      id="mediaLink"
                      size="small"
                      value={link}
                      label="Age"
                      variant="filled"
                      onChange={handleChange}
                      sx={{
                        "& .MuiInputBase-root": {
                          color: `${colors.grey[900]}`,
                        },
                        "& .MuiFilledInput-input": {
                          color: `${colors.grey[400]} !important`,
                        },
                      }}
                    >
                      <MenuItem value={"IBM Fund"}>IBM Fund</MenuItem>
                      <MenuItem value={"TCS Fund"}>TCS Fund</MenuItem>
                      <MenuItem value={"Wipro Fund"}>Wipro Fund</MenuItem>
                    </Select>
                  </FormControl>
                </Box>

                <Box
                  className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6"
                  alignSelf={"center"}
                >
                  <Typography marginBottom={1}>Trade Price</Typography>

                  <FormControl
                    variant="filled"
                    size="small"
                    className="field-container"
                  >
                    <TextField
                      className="createTemplate-WayToTrade_Select"
                      required
                      id="emailId"
                      variant="filled"
                      label="Price"
                      placeholder="&#x2709;"
                      type="text"
                      size="small"
                      value={price}
                      onChange={handlePriceChange}
                      sx={{
                        backgroundColor: `${colors.primary[400]}`,
                        color: `${colors.grey[900]}`,
                        "& .MuiInputBase-root": {
                          color: `${colors.grey[900]}`,
                        },
                        "& .MuiFilledInput-input": {
                          color: `${colors.grey[400]} !important`,
                        },
                      }}
                    />
                  </FormControl>
                </Box>
              </Box>
            </Box>

            <Box
              alignSelf={"left"}
              marginTop={2}
              marginRight={4}
              marginLeft={7}
            >
              <Typography marginBottom={3}>Tags Edit</Typography>

              {/* Perform mapping in Buttons */}
              {tags.map((item) => {
                return (
                  <Button
                    className="me-3 wayToTrade_tagMapBtn"
                    sx={{
                      color: `${colors.grey[900]}`,
                      "&.MuiButton-root:hover": {
                        WebkitTextDecorationStyle: "none",
                        backgroundColor: `${colors.greenAccent[600]} !important`,
                      },
                    }}
                  >
                    {item}
                  </Button>
                );
              })}
            </Box>
          </Box>

          {/* Buttons */}

          <Box
            display="flex"
            flexDirection="row"
            alignSelf="left"
            marginTop={4}
            marginLeft={7}
          >
            <FormControl>
              <Button
                className="wayToTrade_saveAndClosebtn"
                sx={{
                  background: `${colors.greenAccent[500]}`,
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
                onClick={() =>
                  saveAndClose({
                    data: {
                      bestWayToTrade: {
                        subTitle: subTitle,
                        tags: tags,
                        tradePrice: price,
                        fundName: link,
                      },
                    },
                  })
                }
              >
                Save & Close
              </Button>
            </FormControl>

            <FormControl>
              <Typography
                className="wayToTrade_Autosave"
                variant="h6"
                sx={{
                  color: `${colors.grey[100]}`,
                }}
              >
                We'll autosave every 20 seconds
              </Typography>
            </FormControl>
          </Box>
        </Box>
      </Box>
    </>
  );
}
