import React, { useEffect, useState } from "react";
import "./TextField.scss";
import { Helmet } from "react-helmet";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function MediaLink({ saveAndClose, data }: any) {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [link, setLink] = useState(
    data && data?.mediaLink ? data.mediaLink : ""
  );

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setLink(e.target.value as string);
  };
  useEffect(() => {
    setLink(data && data?.mediaLink ? data.mediaLink : "");
  }, [data]);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | MediaLink</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="container-CreateTemplate_TxtField">
        <Box className="textEditor_Box">
          <Box display="flex" flexDirection="column">
            <Box
              alignSelf={"center"}
              marginTop={6}
              marginRight={4}
              marginLeft={4}
            >
              {/* Link Url 1 textfield */}
              <Typography marginBottom={1}>Link URL is here</Typography>

              <FormControl
                variant="filled"
                size="small"
                className="field-container"
              >
                <TextField
                  className="wayToTrade_TxtField"
                  required
                  id="emailId"
                  variant="filled"
                  label="Url"
                  placeholder="&#x2709;"
                  type="text"
                  size="small"
                  value={link}
                  onChange={handleChange}
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                    "& .MuiInputBase-root": {
                      color: `${colors.grey[900]}`,
                    },
                    "& .MuiFilledInput-input": {
                      color: `${colors.grey[400]} !important`,
                    },
                  }}
                />
              </FormControl>
            </Box>

            <Box
              alignSelf={"center"}
              marginTop={6}
              marginRight={4}
              marginLeft={4}
            >
              {/* Link Url 2 textfield  (Select)*/}
              <Typography marginBottom={1}>Links that used before</Typography>

              <FormControl
                variant="filled"
                size="small"
                className="field-container"
              >
                <InputLabel id="mediaLink">Url</InputLabel>
                <Select
                  className="wayToTrade_Select"
                  labelId="mediaLink"
                  required
                  id="mediaLink"
                  size="small"
                  label="Age"
                  variant="filled"
                  sx={{
                    "& .MuiInputBase-root": {
                      color: `${colors.grey[900]}`,
                    },
                    "& .MuiFilledInput-input": {
                      color: `${colors.grey[400]} !important`,
                    },
                  }}
                >
                  <MenuItem value={1}>
                    https://www.youtube.com/watch?v=MjRRQdnOR-A&ab_channel=shakiraVEVO
                  </MenuItem>
                  <MenuItem value={2}>
                    https://www.youtube.com/watch?v=QzakjlbO2Lc&ab_channel=KygoOfficialVEVO
                  </MenuItem>
                  <MenuItem value={3}>
                    https://www.youtube.com/watch?app=desktop&v=RP2teAKjYFA&ab_channel=Lauv
                  </MenuItem>
                </Select>
              </FormControl>
            </Box>
          </Box>

          {/* Buttons */}

          <Box
            display="flex"
            flexDirection="row"
            alignSelf="left"
            marginTop={8}
            marginLeft={4}
          >
            <FormControl>
              <Button
                className="wayToTrade_saveAndClosebtn"
                sx={{
                  background: `${colors.greenAccent[500]}`,
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
                onClick={() => saveAndClose({ data: { mediaLink: link } })}
              >
                <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                  Save & Close
                </Typography>
              </Button>
            </FormControl>

            <FormControl>
              <Typography
                className="wayToTrade_Autosave"
                variant="h6"
                sx={{
                  color: `${colors.grey[100]}`,
                }}
              >
                We'll autosave every 20 seconds
              </Typography>
            </FormControl>
          </Box>
        </Box>
      </Box>
    </>
  );
}
