import React, { useContext } from "react";
import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Box, IconButton, Typography, useTheme } from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import "react-pro-sidebar/dist/css/styles.css";
import { ColorModeContext, tokens } from "../../theme";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import ArrowCircleRightRoundedIcon from "@mui/icons-material/ArrowCircleRightRounded";
import ArrowCircleLeftRoundedIcon from "@mui/icons-material/ArrowCircleLeftRounded";
import EmojiObjectsOutlinedIcon from "@mui/icons-material/EmojiObjectsOutlined";
import AnalyticsOutlinedIcon from "@mui/icons-material/AnalyticsOutlined";
import SearchIcon from "@mui/icons-material/Search";
import InputBase from "@mui/material/InputBase";
import FavoriteBorderOutlinedIcon from "@mui/icons-material/FavoriteBorderOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import LoginOutlinedIcon from "@mui/icons-material/LoginOutlined";
import AssignmentIndOutlinedIcon from "@mui/icons-material/AssignmentIndOutlined";
import "./Global.scss";
import {
  remove_Token,
  set_IsLoggedIn,
  set_Username,
  token,
  username,
} from "../../store/Reducers/UserSlice";
import { useAppDispatch, useAppSelector } from "../../store/store";
import { set_Title, title } from "../../store/Reducers/TopBarSlice";
import axios from "axios";
import { LOGOUT_URL } from "../../utils/constants";

// interface
interface MenuSchema {
  title: string;
  to: string;
  icon: any;
  selected: string;
  active: boolean;
}

const Item = ({ title, to, icon, active }: MenuSchema): any => {
  const dispatch = useAppDispatch();
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <MenuItem
      active={active}
      style={{
        color: colors.grey[100],
      }}
      onClick={async () => {
        dispatch(set_Title(title));
      }}
      icon={icon}
    >
      <Typography>{title}</Typography>
      <Link to={to} />
    </MenuItem>
  );
};

const Sidebar = (props: any) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const colorMode = useContext(ColorModeContext);
  const selected = useAppSelector(title);
  const dispatch = useAppDispatch();
  const user = useAppSelector(username);
  const navigate = useNavigate();
  const authToken = useAppSelector(token);

  const handleClick = () => {
    props.setIsCollapsed(!props.isCollapsed);
  };

  const setLogout = async () => {
    try {
      const response = axios.post(
        LOGOUT_URL,
        {
          user: `${user}`,
        },
        {
          headers: {
            Authorization: `token ${authToken}`,
          },
        }
      );
      if ((await response).data.Status === 200) {
        await dispatch(set_IsLoggedIn(false));
        await dispatch(remove_Token());
        await dispatch(set_Username(""));
        await dispatch(set_Title("Dashboard"));
        if (theme.palette.mode === "light") {
          colorMode.toggleColorMode();
        }
        navigate("/");
      }
    } catch {
      console.log("Some Error");
    }
  };
  return (
    <Box
      className="global-Container_Bars"
      sx={{
        "& .pro-sidebar-inner": {
          background: `${colors.primary[400]} !important`,
        },
        "& .pro-icon-wrapper": {
          backgroundColor: "transparent !important",
        },
        "& .pro-inner-item": {
          padding: "4px 30px 4px 24px !important",
        },
        "& .pro-inner-item:hover": {
          color: `${colors.greenAccent[500]} !important`,
        },
        "& .pro-menu-item.active": {
          color: `${colors.greenAccent[500]} !important`,
        },
      }}
    >
      <ProSidebar collapsed={props.isCollapsed}>
        <Menu iconShape="square">
          <MenuItem
            className="sideBar_MenuItem"
            onClick={() => props.setIsCollapsed(!props.isCollapsed)}
            style={{
              color: `${colors.grey[100]}`,
            }}
            icon={
              props.isCollapsed ? <ArrowCircleRightRoundedIcon /> : undefined
            }
          >
            {!props.isCollapsed && (
              <Box display="flex" justifyContent="space-between">
                <Typography
                  variant="h3"
                  align="center"
                  color={colors.greenAccent[500]}
                  fontSize="700"
                >
                  {props.isCollapsed ? (
                    <img src=".\" alt="logo"></img>
                  ) : (
                    "IdeaVenu"
                  )}
                </Typography>
                <IconButton
                  onClick={() => props.setIsCollapsed(!props.isCollapsed)}
                >
                  {props.isCollapsed ? (
                    <ArrowCircleLeftRoundedIcon />
                  ) : (
                    <ArrowCircleLeftRoundedIcon />
                  )}
                </IconButton>
              </Box>
            )}
          </MenuItem>
          {!props.isCollapsed && !props.isCollapsed ? (
            <Box mb="12px" mt="12px">
              <Box
                className="sideBar_SerchIcon"
                sx={{
                  backgroundColor: `${colors.primary[400]} !important`,
                  border: `1px solid ${colors.grey[900]}`,
                }}
              >
                <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" />
                <IconButton type="button" sx={{ p: 1 }}>
                  <SearchIcon />
                </IconButton>
              </Box>
            </Box>
          ) : (
            <Box
              display="flex"
              justifyContent="center"
              mb="12px"
              mt="12px"
              style={{
                color: `${colors.primary[400]}`,
              }}
            >
              <IconButton type="button" sx={{ p: 1 }} onClick={handleClick}>
                <SearchIcon />
              </IconButton>
            </Box>
          )}
          {props.role === "user" && (
            <Box>
              <Box>
                <Item
                  title="Dashboard"
                  to="/dashboard"
                  icon={<HomeOutlinedIcon />}
                  selected={selected}
                  active={selected === "Dashboard"}
                />
                <Item
                  title="User"
                  to="/user"
                  icon={<AssignmentIndOutlinedIcon />}
                  selected={selected}
                  active={selected === "User"}
                />
                <Item
                  title="Analyst"
                  to="/analyst"
                  icon={<AnalyticsOutlinedIcon />}
                  selected={selected}
                  active={selected === "Analyst"}
                />
              </Box>
            </Box>
          )}
          {props.role === "analyst" && (
            <Box>
              <Box>
                <Item
                  title="Dashboard"
                  to="/dashboard"
                  icon={<HomeOutlinedIcon />}
                  selected={selected}
                  active={selected === "Dashboard"}
                />
                <Item
                  title="Idea"
                  to="/idea"
                  icon={<EmojiObjectsOutlinedIcon />}
                  selected={selected}
                  active={selected === "Idea"}
                />
              </Box>
            </Box>
          )}

          <Box mt="40px">
            <Item
              title="Favorites"
              to="/favorites"
              icon={<FavoriteBorderOutlinedIcon />}
              selected={selected}
              active={selected === "Favorites"}
            />
            <Item
              title="Settings"
              to="/settings"
              icon={<SettingsOutlinedIcon />}
              selected={selected}
              active={selected === "Settings"}
            />
            <Item
              title="Support"
              to="/support"
              icon={<PeopleAltOutlinedIcon />}
              selected={selected}
              active={selected === "Support"}
            />
            <MenuItem
              style={{
                color: `${colors.grey[100]}`,
              }}
              onClick={() => setLogout()}
              icon={<LoginOutlinedIcon />}
            >
              <Typography>Log out</Typography>
            </MenuItem>
          </Box>
        </Menu>
      </ProSidebar>
    </Box>
  );
};

export default Sidebar;
