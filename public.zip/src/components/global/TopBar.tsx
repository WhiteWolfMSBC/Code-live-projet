import { Box, IconButton, Typography, useTheme } from "@mui/material";
import React, { useState } from "react";
import { useContext } from "react";
import { ColorModeContext, tokens } from "../../theme";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import Popover from "@mui/material/Popover";
import { username, userId } from "../../store/Reducers/UserSlice";
import { useAppSelector } from "../../store/store";
import { title } from "../../store/Reducers/TopBarSlice";
import "./Global.scss";


const TopBar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const colorMode = useContext(ColorModeContext);
  const [anchorNotify, setAnchorNotify] = useState<HTMLButtonElement | null>(
    null
  );
  const topTitle = useAppSelector(title);
  const user = useAppSelector(username);
  const userid = useAppSelector(userId);
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorNotify(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorNotify(null);
  };

  const open = Boolean(anchorNotify);
  const id_notify = open ? "simple-popover" : "";
  return (
    <Box
      className="global-Container_Bars"
      display="flex"
      justifyContent={"space-between"}
      sx={{ m: "8px" }}
    >
      <Box display="inline-block" padding={"20px 8px 20px 8px"}>
        <Typography variant="h3" color={`${colors.greenAccent[500]}`}>
          {topTitle}
        </Typography>
      </Box>
      <Box display={"flex"} className="Container_Bar_Icons">
        <Box display="flex" p={1.5}>
          <IconButton
            className="ContainerBars_IconButton"
            onClick={colorMode.toggleColorMode}
          >
            {theme.palette.mode === "dark" ? (
              <DarkModeOutlinedIcon sx={{ color: `${colors.grey[900]}` }} />
            ) : (
              <LightModeOutlinedIcon sx={{ color: `${colors.grey[900]}` }} />
            )}
          </IconButton>
          <IconButton className="ContainerBars_IconButton">
            <a href="mailto:info@cloverr.com">
              <EmailOutlinedIcon sx={{ color: `${colors.grey[900]}` }} />
            </a>
          </IconButton>
          <Popover
            id={id_notify}
            open={open}
            anchorEl={anchorNotify}
            onClose={handleClose}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
          >
            <Typography sx={{ p: 2 }}>This is popover for Mail</Typography>
          </Popover>
          <IconButton
            className="ContainerBars_IconButton"
            aria-describedby={id_notify}
            onClick={handleClick}
          >
            <NotificationsOutlinedIcon sx={{ color: `${colors.grey[900]}` }} />
          </IconButton>
          <Popover
            id={id_notify}
            open={open}
            anchorEl={anchorNotify}
            onClose={handleClose}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
          >
            <Typography sx={{ p: 2, cursor: "pointer" }}>
              This is popover for notification
            </Typography>
          </Popover>
        </Box>
        <Box display="flex" textAlign="center" p={1}>
          <Box>
            <Typography
              className="ContainerBars_Typography"
              variant="h6"
              color={colors.grey[100]}
              fontWeight="bold"
              sx={{ textTransform: "capitalize" }}
            >
              {user}
            </Typography>
            <Typography variant="h6" color={colors.grey[500]}>
              User ID: {userid}
            </Typography>
          </Box>
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            marginLeft={1}
          >
            <img
              alt="user"
              width="40px"
              height="40px"
              src={`https://th.bing.com/th/id/OIP.puMo9ITfruXP8iQx9cYcqwHaGJ?pid=ImgDet&rs=1`}
              style={{ cursor: "pointer", borderRadius: "50%" }}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default TopBar;
