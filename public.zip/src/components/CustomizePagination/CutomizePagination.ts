import TablePaginationUnstyled, {
  tablePaginationUnstyledClasses as classes,
} from "@mui/base/TablePaginationUnstyled";
import { styled } from "@mui/system";

export const CustomTablePaginationStyle = (theme: any, colors: any): any => {
  return styled(TablePaginationUnstyled)(
    () => `
  & .${classes.spacer} {
    display: none;
  }

  & .${classes.toolbar}  {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;

    @media (min-width: 768px) {
      flex-direction: row;
      align-items: center;
    }
  }

  & .${classes.selectLabel} {
    margin: 0;
  }

  & .${classes.select}{
    padding: 2px;
    border: 1px solid ${colors.grey[400]};
    border-radius: 50px;
    background-color: transparent;
    color: ${colors.grey[300]};

    &:hover {
      background-color: ${colors.grey[700]};
    }

    &:focus {
      outline: 1px solid ${colors.primary[500]};
    }
  }

  & .${classes.displayedRows} {
    margin: 0;

    @media (min-width: 768px) {
      margin-left: auto;
    }
  }

  & .${classes.actions} {
    padding: 2px;
    border: 1px solid ${colors.grey[400]};
    border-radius: 50px;
    text-align: center;
  }

  & .${classes.actions} > button {
    margin: 0 8px;
    border: transparent;
    border-radius: 2px;
    background-color: transparent;
    color: ${colors.grey[300]};

    &:hover {
      background-color: ${colors.grey[700]};
    }

    &:focus {
      outline: 1px solid ${colors.primary[500]};
    }
  }
  `
  );
};
