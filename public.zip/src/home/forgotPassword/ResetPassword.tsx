/* eslint-disable no-useless-escape */
import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";
import {
  Button,
  FilledInput,
  FormControl,
  FormHelperText,
  IconButton,
  InputAdornment,
  InputLabel,
  Typography,
} from "@mui/material";
import { tokens } from "../../theme";
import "./Resetpassword.scss";
import VisibilityRoundedIcon from "@mui/icons-material/VisibilityRounded";
import VisibilityOffRoundedIcon from "@mui/icons-material/VisibilityOffRounded";
import { OtpValidationSchema } from "./OtpValidation";
import { useNavigate } from "react-router-dom";
import { resetPasswordAPI } from "../../api/LoginApi";
import { passwordMsg } from "../../utils/constants";
import { Helmet } from "react-helmet";

export const ResetPassword = (props: OtpValidationSchema) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [confirmPassword, setConfirmPassowrd] = useState<string | null>("");
  const [password, setPassword] = useState<string | null>("");
  const [showPassword, setShowPassword] = useState(false);
  const strongRegex = new RegExp(
    "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})"
  );
  const [pwdErr, setPwdErr] = useState("");
  const [cnfErr, setCnfErr] = useState("");
  const [resetErr, setResetErr] = useState("");
  const navigate = useNavigate();
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  const [showCnfPassword, setShowCnfPassword] = useState(false);
  const handleClickShowcPassword = () => {
    setShowCnfPassword(!showCnfPassword);
  };

  const handlePasswordChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setPassword(e.target.value);
  };
  const handleConfirmedPwdChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setConfirmPassowrd(e.target.value);
  };

  useEffect(() => {
    if (password !== "" || confirmPassword !== "") {
      if (confirmPassword !== "" && password !== confirmPassword) {
        setCnfErr("Password do not match");
      } else {
        setCnfErr("");
      }
    }
  }, [confirmPassword, password]);

  const handelPasswordConfirm = async () => {
    if (password && strongRegex.test(password)) {
      setPwdErr("");
    } else {
      setPwdErr("Password is invalid");
    }
    if (
      password !== "" &&
      confirmPassword !== "" &&
      pwdErr === "" &&
      cnfErr === "" &&
      password &&
      strongRegex.test(password)
    ) {
      try {
        const response = await resetPasswordAPI(props.emailId, password);
        switch (response.data.Status) {
          case 200: {
            navigate("/");
            break;
          }
          case 401: {
            setResetErr(response.data.Message);
            break;
          }
        }
      } catch (err) {
        setResetErr("Server not Responding. Try again");
      }
    } else {
    }
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ResetPassword</title>
      </Helmet>

      <Box
        display={"flex"}
        flexDirection="column"
        className="container-ResetPassword"
      >
        <Box
          display={"flex"}
          flexDirection="column"
          alignSelf="center"
          width="500px"
        >
          <Typography
            variant="h2"
            align="justify"
            alignSelf="center"
            fontWeight="400"
            margin={"40px 0 20px 0"}
            color={colors.grey[900]}
          >
            Create new password
          </Typography>

          {/* Password filed */}

          <FormControl
            variant="filled"
            size="small"
            sx={{ margin: "6px 0 12px 0" }}
          >
            <InputLabel
              htmlFor="password"
              sx={{ color: `${colors.grey[100]}`, marginTop: "2px" }}
              required
            >
              New Password
            </InputLabel>
            <FilledInput
              id="password"
              className="form_TxtField"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => handlePasswordChange(e)}
              placeholder="&#128477;"
              sx={{
                backgroundColor: `${colors.grey[900]}`,
                borderRadius: "24px",
                color: `${colors.redAccent[100]} !important`,
                "& .MuiFormHelperText-root": {
                  color: `${colors.redAccent[900]}`,
                },
                "&.MuiInputBase-root": {
                  fontSize: "18px",
                },
              }}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    sx={{
                      color: `${colors.redAccent[100]}`,
                      marginLeft: "4px",
                    }}
                    edge="end"
                  >
                    {showPassword ? (
                      <VisibilityOffRoundedIcon />
                    ) : (
                      <VisibilityRoundedIcon />
                    )}
                  </IconButton>
                </InputAdornment>
              }
            />
            {pwdErr && (
              <FormHelperText id="helper-text-password" className="helper-text">
                {pwdErr}
              </FormHelperText>
            )}
            {passwordMsg && (
              <FormHelperText id="helper-text-password" className="message">
                {passwordMsg}
              </FormHelperText>
            )}
          </FormControl>
          <FormControl
            variant="filled"
            size="small"
            className="field-container"
          >
            <InputLabel
              htmlFor="cpassword"
              sx={{ color: `${colors.grey[100]}`, marginTop: "2px" }}
              required
            >
              Confirm New Password
            </InputLabel>
            <FilledInput
              id="cpassword"
              className="form_TxtField"
              type={showCnfPassword ? "text" : "password"}
              value={confirmPassword}
              onChange={(e) => handleConfirmedPwdChange(e)}
              placeholder="&#128477;"
              sx={{
                backgroundColor: `${colors.grey[900]}`,
                borderRadius: "24px",
                color: `${colors.redAccent[100]} !important`,
                "& .MuiFormHelperText-root": {
                  color: `${colors.redAccent[900]}`,
                },
                "&.MuiInputBase-root": {
                  fontSize: "18px",
                },
              }}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowcPassword}
                    sx={{
                      color: `${colors.redAccent[100]}`,
                      marginLeft: "4px",
                    }}
                    edge="end"
                  >
                    {showCnfPassword ? (
                      <VisibilityOffRoundedIcon />
                    ) : (
                      <VisibilityRoundedIcon />
                    )}
                  </IconButton>
                </InputAdornment>
              }
            />
            <FormHelperText id="helper-text-cPassword" className="helper-text">
              {cnfErr}
            </FormHelperText>
          </FormControl>
          <Typography
            variant="h5"
            sx={{ color: `${colors.redAccent[900]}` }}
            align="center"
          >
            {resetErr}
          </Typography>
          <FormControl>
            <Button
              className="container-ResetPassword-btn"
              sx={{
                background: `${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
              onClick={() => handelPasswordConfirm()}
            >
              <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
                Change Password
              </Typography>
            </Button>
          </FormControl>
        </Box>
      </Box>
    </>
  );
};

export default ResetPassword;
