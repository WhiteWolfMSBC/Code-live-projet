import OTPInput from "react-otp-input";
import React, { useState } from "react";
import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";
import { Button, FormControl, Typography } from "@mui/material";
import { tokens } from "../../theme";
import "./OtpValidation.scss";
import axios from "axios";
import ResetPassword from "./ResetPassword";
import { FORGOT_URL } from "../../utils/constants";
import { otpValidationAPI } from "../../api/LoginApi";
import { Helmet } from "react-helmet";

export interface OtpValidationSchema {
  emailId: string;
}

export const OtpValidation = (props: OtpValidationSchema) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [OTP, setOTP] = useState("");
  const [resendMsg, setResendMsg] = useState("");
  function handleChange(OTP: React.SetStateAction<string>) {
    setOTP(OTP);
  }
  const [otpErr, setOtpErr] = useState("");
  const [resetScreen, setResetScreen] = useState(false);

  const handelEmailCodeVerify = async () => {
    if (OTP.length < 6) {
      setOtpErr("Please enter OTP");
    } else {
      try {
        const response = await otpValidationAPI(props.emailId, OTP);
        switch (response.data.Status) {
          case 200: {
            setResetScreen(true);
            break;
          }
          case 401: {
            setOtpErr(response.data.Message);
            break;
          }
        }
      } catch (err) {
        setOtpErr("Server not Responding. Try again");
      }
    }
  };
  const handleResendOtp = async () => {
    try {
      const response = await axios.post(FORGOT_URL, {
        email: props.emailId,
        type: "otp_send",
      });
      switch (response.data.Status) {
        case 200: {
          setResendMsg("We have sent Otp on your mail");
          break;
        }
        case 500: {
          setOtpErr(response.data.Message);
          break;
        }
        case 401: {
          setOtpErr(response.data.Message);
          break;
        }
      }
    } catch (err) {
      setOtpErr("Server not Responding. Try again");
    }
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | OtpValidation</title>
      </Helmet>

      {!resetScreen && (
        <Box
        className="container-OtpValidation"
          display={"flex"}
          flexDirection="column"
          alignSelf="center"
          width="500px"
        >
          <Box
            display="flex"
            flexDirection="row"
            alignSelf="center"
            margin="40px 0 0 0"
          >
            <Typography
              variant="h2"
              align="justify"
              alignSelf="center"
              fontWeight="400"
              color={colors.grey[900]}
            >
              Authentication Required
            </Typography>
          </Box>

          <Box
            display="flex"
            flexDirection="row"
            alignSelf="center"
            margin="20px 0 20px 0"
          >
            <Typography
              variant="h6"
              align="justify"
              alignSelf="center"
              fontWeight="400"
              color={colors.grey[900]}
            >
              For your security, we need to authenticate your request. We've
              sent a One Time password(OTP) to the email ***@***.com. Please
              enter it below.
            </Typography>
          </Box>

          <Box display={"flex"} alignSelf="center" marginLeft={3}>
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <OTPInput
                onChange={handleChange}
                value={OTP}
                inputStyle="inputStyle"
                numInputs={6}
              />
            </FormControl>
          </Box>
          <Typography
            variant="h5"
            sx={{ color: `${colors.redAccent[900]}` }}
            align="center"
          >
            {otpErr}
          </Typography>
          <FormControl>
            <Button
            className="container-OtpValidation-btn"
              sx={{
                background: `${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
              onClick={() => handelEmailCodeVerify()}
            >
              <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
                Verify Otp
              </Typography>
            </Button>
          </FormControl>

          <Box
            display="flex"
            flexDirection="row"
            alignSelf="center"
            onClick={handleResendOtp}
          >
            <Typography
              variant="h6"
              align="justify"
              alignSelf="center"
              fontWeight="400"
              color={colors.greenAccent[500]}
            >
              Resend OTP
            </Typography>
          </Box>
        </Box>
      )}
      {resetScreen && <ResetPassword emailId={props.emailId} />}
    </>
  );
};

export default OtpValidation;
