/* eslint-disable jsx-a11y/alt-text */
import React, { useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { useTheme } from "@mui/material/styles";
import { Button, FormControl, Typography } from "@mui/material";
import { tokens } from "../../theme";
import Icon from "../../assets/logo_80.png";
import "./ForgotPassword.scss";
import OtpValidation from "./OtpValidation";
import { forgotEmailAPI } from "../../api/LoginApi";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

export const ForgotPassword = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [emailId, setEmailId] = useState<string>("");
  const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
  const [emailErr, setEmailErr] = useState("");
  const [forgotErr, setForgotErr] = useState("");
  const [openOtp, setOpenOtp] = useState(false);
  const handleEmailChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setEmailId(e.target.value);
  };

  const handelVerifyEmail = async () => {
    if (emailId && emailId !== "") {
      if (!emailRegex.test(emailId)) {
        setEmailErr("Please enter valid Email Id");
      }
    }
    if (emailErr === "" && emailId !== "") {
      try {
        const response: any = await forgotEmailAPI(emailId, "otp_send");
        switch (response.data.Status) {
          case 200: {
            setOpenOtp(true);
            break;
          }
          case 500: {
            setForgotErr(response.data.Message);
            break;
          }
          case 403: {
            setForgotErr(response.data.Message);
            break;
          }
        }
      } catch (err) {
        setForgotErr("Server not Responding. Try again");
      }
    }
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ForgotPassword</title>
      </Helmet>

      <Box
        display={"flex"}
        flexDirection="column"
        className="Container_ForgotPass"
      >
        <Box
          display="flex"
          flexDirection="column"
          alignSelf={"center"}
          margin="20px 0 0 0"
        >
          <Box alignSelf={"center"} marginRight={2}>
            <img src={Icon} />
          </Box>
          <Typography
            variant="h1"
            align="justify"
            alignSelf="center"
            color={colors.grey[900]}
            sx={{
              fontFamily: "Futura Md BT,sans-serif",
              letterSpacing: "5px",
              fontWeight: "400",
            }}
          >
            CLOVERR
          </Typography>
        </Box>
        {!openOtp && (
          <>
            <Typography variant="h2" margin="40px 0 8px 0" align="center">
              Forgot Password
            </Typography>

            <Box
              display={"flex"}
              flexDirection="column"
              alignSelf="center"
              width="500px"
              margin="20px 0 0 0"
              className="Container_ForgotPass-txtField"
            >
              <FormControl
                variant="filled"
                size="small"
                className="field-container"
              >
                <TextField
                  className="form_TxtField"
                  required
                  id="emailId"
                  variant="filled"
                  label="Registered Email ID"
                  placeholder="&#x2709;"
                  type="text"
                  size="small"
                  value={emailId}
                  onChange={(e) => handleEmailChange(e)}
                  sx={{
                    backgroundColor: `${colors.grey[900]}`,
                    "& .MuiInputBase-root": {
                      fontSize: "18px",
                    },
                  }}
                />
              </FormControl>

              <Typography
              className="Container_ForgotPass_txtField-Typography"
                variant="h5"
                sx={{ color: `${colors.redAccent[900]}` }}
                align="center"
              >
                {forgotErr}
              </Typography>
              <FormControl>
                <Button
                  className="Container_ForgotPass_txtField-btn"
                  sx={{
                    background: `${colors.greenAccent[500]}`,
                    "&.MuiButton-root:hover": {
                      WebkitTextDecorationStyle: "none",
                      backgroundColor: `${colors.greenAccent[600]} !important`,
                    },
                  }}
                  onClick={handelVerifyEmail}
                >
                  <Typography
                    variant="h5"
                    sx={{ color: `${colors.grey[900]}` }}
                  >
                    Verify Email
                  </Typography>
                </Button>
              </FormControl>
              <FormControl>
                <Typography variant="h6" align="center">
                  <Link to="/" className="link_Typography">
                    Register
                  </Link>
                </Typography>
              </FormControl>
            </Box>
          </>
        )}
        {openOtp && <OtpValidation emailId={emailId} />}
      </Box>
    </>
  );
};
