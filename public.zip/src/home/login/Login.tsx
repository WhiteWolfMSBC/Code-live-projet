/* eslint-disable jsx-a11y/alt-text */
import {
  Box,
  Button,
  Divider,
  FilledInput,
  FormControl,
  FormHelperText,
  IconButton,
  InputAdornment,
  InputLabel,
  TextField,
  Typography,
  useTheme,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import "./Login.scss";
import { tokens } from "../../theme";
import Icon1 from "../../assets/logo_80.png";
import { useNavigate } from "react-router-dom";
import VisibilityRoundedIcon from "@mui/icons-material/VisibilityRounded";
import VisibilityOffRoundedIcon from "@mui/icons-material/VisibilityOffRounded";
import {
  set_IsLoggedIn,
  set_Role,
  set_Token,
  set_userid,
  set_Username,
} from "../../store/Reducers/UserSlice";
import { useAppDispatch } from "../../store/store";
import Register from "../register/Register";
import { loginAPI } from "../../api/LoginApi";
import { Helmet } from "react-helmet";

const Login = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [username, setUsername] = useState<string | null>("");
  const [password, setPassword] = useState<string | null>("");
  const [pwdErr, setPwdErr] = useState("");
  const [userErr, setUserErr] = useState("");
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [responseErr, setResponseErr] = useState("");
  const handleUsernameChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setUsername(e.target.value);
  };
  const handlePasswordChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setPassword(e.target.value);
  };
  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  const handleSubmit = async (e: any) => {
    e.preventDefault();
    if (username === "" || username === null) {
      setUserErr("Please Enter Username");
    }
    if (password === "" || password === null) {
      setPwdErr("Please Enter Password");
    }
    if (username !== "" && password !== "") {
      try {
        const response: any = await loginAPI(username, password);
        switch (response.data.Status) {
          case 200: {
            await dispatch(set_IsLoggedIn(true));
            await dispatch(set_Token(response.data.Token));
            await dispatch(set_Username(username));
            await dispatch(set_userid(response.data.User_id));
            await dispatch(set_Role(response.data.Role));
            navigate("/dashboard");
            break;
          }
          case 401: {
            setResponseErr(response.data.Message);
            break;
          }
        }
      } catch (err) {
        setResponseErr("Server not Responding");
      }
    }
    console.log("hiiLogin");
  };
  const handleForgotPassowrd = () => {
    navigate("/forgot");
  };
  useEffect(() => {
    setUserErr("");
    setPwdErr("");
    setResponseErr("");
  }, [username, password]);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Home</title>
      </Helmet>

      <Box
        height={"100%"}
        display="flex"
        flexDirection="column"
        style={{ backgroundColor: `${colors.primary[500]}` }}
      >
        {/* Logo*/}
        <Box
          display="flex"
          flexDirection="column"
          alignSelf={"center"}
          margin="20px 0 0 0"
        >
          <Box alignSelf={"center"} marginRight={2}>
            <img src={Icon1} />
          </Box>
          <Typography
            variant="h1"
            align="justify"
            alignSelf="center"
            color={colors.grey[900]}
            sx={{
              fontFamily: "Futura Md BT,sans-serif",
              letterSpacing: "5px",
              fontWeight: "400",
            }}
          >
            CLOVERR
          </Typography>
        </Box>
        <Box
          display={"flex"}
          flexDirection="row"
          justifyContent={"space-evenly"}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              padding: "2%",
              width: "500px",
            }}
          >
            {/* login Component */}
            <Box>
              <Typography variant="h2" margin="40px 0 8px 0" align="center">
                User Login
              </Typography>
            </Box>
            <form onSubmit={(e) => handleSubmit(e)}>
              <Box
                display="flex"
                flexDirection="column"
                margin={"20px 0 0 0"}
                className="login_Form"
              >
                <FormControl
                  variant="filled"
                  size="small"
                  sx={{ margin: "6px 0 12px 0" }}
                >
                  <TextField
                    required
                    className="form_TxtField"
                    id="username"
                    variant="filled"
                    label="Username or Email id"
                    placeholder="&#9993;"
                    type="text"
                    size="small"
                    value={username}
                    onChange={(e) => handleUsernameChange(e)}
                    sx={{
                      backgroundColor: `${colors.redAccent[200]}`,
                    }}
                  />
                  <FormHelperText
                    id="helper-text-cPassword"
                    sx={{
                      color: `${colors.redAccent[900]}`,
                      fontWeight: "700",
                      "& .MuiFormControl-root:focus": {
                        backgroundColor: `${colors.redAccent[100]}`,
                      },
                    }}
                  >
                    {userErr}
                  </FormHelperText>
                </FormControl>
                <FormControl
                  variant="filled"
                  size="small"
                  sx={{ margin: "6px 0 12px 0" }}
                >
                  <InputLabel
                    htmlFor="password"
                    sx={{ color: `${colors.grey[100]}`, marginTop: "2px" }}
                    required
                  >
                    Password
                  </InputLabel>
                  <FilledInput
                    className="form_TxtField"
                    required
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => handlePasswordChange(e)}
                    placeholder="&#128477;"
                    sx={{
                      backgroundColor: `${colors.redAccent[200]}`,
                      color: `${colors.redAccent[100]} !important`,
                    }}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleClickShowPassword}
                          sx={{
                            color: `${colors.redAccent[100]}`,
                            marginLeft: "4px",
                          }}
                          edge="end"
                        >
                          {showPassword ? (
                            <VisibilityOffRoundedIcon />
                          ) : (
                            <VisibilityRoundedIcon />
                          )}
                        </IconButton>
                      </InputAdornment>
                    }
                  />
                  <FormHelperText
                    id="helper-text-password"
                    sx={{
                      color: `${colors.redAccent[900]}`,
                      fontWeight: "700",
                    }}
                  >
                    {pwdErr}
                  </FormHelperText>
                </FormControl>
                <Typography
                  variant="h5"
                  sx={{ color: `${colors.redAccent[900]}` }}
                  align="center"
                >
                  {responseErr}
                </Typography>
                <Button
                  className="login_btn"
                  type="submit"
                  sx={{
                    background: `${colors.greenAccent[500]}`,
                    "&.MuiButton-root:hover": {
                      WebkitTextDecorationStyle: "none",
                      backgroundColor: `${colors.greenAccent[600]} !important`,
                    },
                  }}
                >
                  <Typography
                    variant="h5"
                    sx={{ color: `${colors.grey[900]}` }}
                  >
                    Login
                  </Typography>
                </Button>
                <Button variant="text" onClick={handleForgotPassowrd}>
                  <Typography
                    variant="h6"
                    sx={{ color: `${colors.grey[900]}` }}
                  >
                    Forgot password?
                  </Typography>
                </Button>
              </Box>
            </form>
          </Box>
          <Divider
            orientation="vertical"
            variant="middle"
            flexItem
            sx={{
              borderWidth: "2px",
              borderColor: `${colors.grey[900]}`,
              margin: "0 10px",
            }}
          />
          {/* Register Component */}
          <Box padding="0 10px">
            <Register />
          </Box>
        </Box>
      </Box>
    </>
  );
};
export default Login;
