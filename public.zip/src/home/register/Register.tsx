/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-useless-concat */
import {
  Box,
  Button,
  InputAdornment,
  TextField,
  Typography,
  useTheme,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControl,
  InputLabel,
  FilledInput,
  IconButton,
  FormHelperText,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import CloseSharpIcon from "@mui/icons-material/CloseSharp";
import { tokens } from "../../theme";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import VisibilityRoundedIcon from "@mui/icons-material/VisibilityRounded";
import VisibilityOffRoundedIcon from "@mui/icons-material/VisibilityOffRounded";
import {
  set_IsLoggedIn,
  set_Token,
  set_userid,
  set_Username,
} from "../../store/Reducers/UserSlice";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/bootstrap.css";
import "./Register.scss";
import { useAppDispatch } from "../../store/store";
import { USERNAME_URL } from "../../utils/constants";
import { loginAPI, registerAPI } from "../../api/LoginApi";
import { passwordMsg } from "../../utils/constants";

const Register = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [username, setUsername] = useState<string | null>("");
  const [password, setPassword] = useState<string | null>("");
  const [firstName, setFirstName] = useState<string | null>("");
  const [lastName, setLastName] = useState<string | null>("");
  const [emailId, setEmailId] = useState<string | null>("");
  const [confirmPassword, setConfirmPassowrd] = useState<string | null>("");
  const [pwdErr, setPwdErr] = useState("");
  const [userErr, setUserErr] = useState("");
  const [fnErr, setFnErr] = useState("");
  const [lnErr, setLnErr] = useState("");
  const [emailErr, setEmailErr] = useState("");
  const [contactErr, setContactErr] = useState("");
  const [tncErr, setTncErr] = useState("");
  const strongRegex = new RegExp(
    "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})"
  );
  const [phone, setPhone] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [registerErr, setRegisterErr] = useState("");
  const dispatch = useAppDispatch();
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  const [showcPassword, setShowcPassword] = useState(false);
  const handleClickShowcPassword = () => {
    setShowcPassword(!showcPassword);
  };
  const handleEmailChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setEmailId(e.target.value);
  };
  const handleFirstNameChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFirstName(e.target.value);
  };
  const handleLastNameChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setLastName(e.target.value);
  };
  const handleUserNameChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setUsername(e.target.value);
  };
  const handlePasswordChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setPassword(e.target.value);
  };
  const handleConfirmedPwdChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setConfirmPassowrd(e.target.value);
  };
  const navigate = useNavigate();

  const validateFields = (): boolean => {
    if (emailId && emailId !== "") {
      if (!emailRegex.test(emailId)) {
        setEmailErr("Please enter valid Email Id");
        return false;
      }
    }
    if (!checked) {
      setTncErr("Please check on Terms and Conditions");
      return false;
    } else {
      setTncErr("");
    }
    if (username === "" || username === null) {
      setUserErr("Please Enter Username");
      return false;
    }
    if (password === "" || password === null) {
      setPwdErr("Please Enter Password");
      return false;
    }
    if (password && strongRegex.test(password)) {
      setPwdErr("");
    } else {
      setPwdErr("Password is invalid");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFnErr(firstName !== "" ? "" : "Please enter First Name");
    setLnErr(lastName !== "" ? "" : "Please enter Last Name");
    setEmailErr(emailId !== "" ? "" : "Please enter Email Id");
    setContactErr(phone !== "" ? "" : "Please enter Contact No");
    const validate = validateFields();
    if (
      username !== "" &&
      password !== "" &&
      firstName !== "" &&
      lastName !== "" &&
      emailId !== "" &&
      checked &&
      pwdErr === "" &&
      contactErr === "" &&
      cnfErr === "" &&
      validate &&
      !userFlag
    ) {
      try {
        const response = await registerAPI(
          username,
          password,
          firstName,
          lastName,
          emailId,
          phone
        );
        if (response.data.Status === 200) {
          const loginResponse = await loginAPI(username, password);
          switch (loginResponse.data.Status) {
            case 200: {
              await dispatch(set_IsLoggedIn(true));
              await dispatch(set_Token(loginResponse.data.Token));
              await dispatch(set_Username(username));
              await dispatch(set_userid(loginResponse.data.User_id));
              navigate("/dashboard");
              break;
            }
            case 401: {
              setRegisterErr(loginResponse.data.Message);
              break;
            }
          }
        }
        if (response.data.Status === 401) {
          setRegisterErr(response.data.Message);
        }
      } catch (err) {
        setRegisterErr("Server not Responding. Try again");
      }
    }
    console.log("hiiRegister");
  };
  const [cnfErr, setCnfErr] = useState("");
  const [open, setOpen] = React.useState(false);
  const [userFlag, setUserFlag] = useState(true);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const [checked, setChecked] = useState(false);
  const checkboxHandler = () => {
    setChecked(!checked);
  };

  useEffect(() => {
    setFnErr("");
    setLnErr("");
    setEmailErr("");
    setContactErr("");
    setPwdErr("");
    setTncErr("");
  }, [firstName, lastName, emailId, phone, password, checked]);
  const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
  useEffect(() => {
    if (password !== "" || confirmPassword !== "") {
      if (confirmPassword !== "" && password !== confirmPassword) {
        setCnfErr("Password do not match");
      } else {
        setCnfErr("");
      }
    }
    if (emailId && emailId !== "" && !emailRegex.test(emailId)) {
      setEmailErr("Please enter valid Email Id");
    }
  }, [confirmPassword, emailId, emailRegex, password]);
  const verifyUser = async (user: string | null) => {
    if (username && username.length >= 4) {
      const response = await axios.post(USERNAME_URL, {
        username: user && user.toLowerCase(),
      });
      let message = response.data.Message;
      setUserFlag(message === "Yes");
      switch (message) {
        case "Yes": {
          setUserErr("Username already exists please enter another one");
          break;
        }
        case "No": {
          setUserErr(`${username.toLocaleLowerCase()}` + " is available");
          break;
        }
      }
    } else {
      setUserErr("");
    }
  };
  useEffect(() => {
    if (username && username === null) {
      setUserErr("");
    }
    verifyUser(username);
  }, [username]);
  return (
    <Box className="main-container">
      <Box className="form-container">
        <Box className="title">
          <Typography variant="h2" margin="20px 0 8px 0">
            New User Registration
          </Typography>
        </Box>
        <form onSubmit={(e) => handleSubmit(e)}>
          <Box
            display="flex"
            flexDirection="column"
            margin={"20px 0 0 0"}
            className="register_Form"
          >
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <TextField
                className="form_TxtField"
                required
                id="emailId"
                variant="filled"
                label="Email Id"
                placeholder="&#9993;"
                type="text"
                size="small"
                value={emailId}
                onChange={(e) => handleEmailChange(e)}
                sx={{
                  backgroundColor: `${colors.redAccent[200]}`,
                }}
              />
              <FormHelperText
                id="helper-text-cPassword"
                className="helper-text"
              >
                {emailErr}
              </FormHelperText>
            </FormControl>
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <TextField
                className="form_TxtField"
                required
                id="username"
                variant="filled"
                label="Username"
                type="text"
                size="small"
                placeholder="&#128100;"
                value={username}
                onChange={(e) => handleUserNameChange(e)}
                inputProps={{ style: { textTransform: "lowercase" } }}
                sx={{
                  backgroundColor: `${colors.redAccent[200]}`,
                  border: `{${userErr} != '' && ${userFlag} ? '2px solid red' : '2px solid #00D796'}`,
                }}
              />
              {userErr && userFlag ? (
                <FormHelperText
                  id="helper-text-cPassword"
                  className="helper-text"
                >
                  {userErr}
                </FormHelperText>
              ) : (
                <FormHelperText
                  id="helper-text-cPassword"
                  className="success-text"
                >
                  {userErr}
                </FormHelperText>
              )}
              {userErr === "" ? (
                <FormHelperText id="helper-text-username" className="message">
                  Should have at least 4 character
                </FormHelperText>
              ) : (
                ""
              )}
            </FormControl>
            <Box display="flex" justifyContent="space-between">
              <Box display="flex" flexDirection="column">
                <FormControl
                  variant="filled"
                  size="small"
                  sx={{ margin: "6px 10px 12px 0" }}
                >
                  <TextField
                    className="form_TxtField"
                    required
                    id="firstname"
                    variant="filled"
                    label="First Name"
                    type="text"
                    size="small"
                    placeholder="&#128100;"
                    value={firstName}
                    onChange={(e) => handleFirstNameChange(e)}
                    sx={{
                      backgroundColor: `${colors.redAccent[200]}`,
                    }}
                  />
                  <FormHelperText
                    id="helper-text-cPassword"
                    className="helper-text"
                  >
                    {fnErr}
                  </FormHelperText>
                </FormControl>
              </Box>
              <Box display="flex" flexDirection="column">
                <FormControl
                  variant="filled"
                  size="small"
                  sx={{ margin: "6px 0 12px 10px" }}
                >
                  <TextField
                    className="form_TxtField"
                    required
                    id="lastname"
                    variant="filled"
                    label="Last Name"
                    type="text"
                    size="small"
                    placeholder="&#128100;"
                    value={lastName}
                    onChange={(e) => handleLastNameChange(e)}
                    sx={{
                      backgroundColor: `${colors.redAccent[200]}`,
                    }}
                  />
                  <FormHelperText
                    id="helper-text-cPassword"
                    className="helper-text"
                  >
                    {lnErr}
                  </FormHelperText>
                </FormControl>
              </Box>
            </Box>
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <PhoneInput
                country={"us"}
                enableSearch={false}
                value={phone}
                onChange={(phone) => setPhone(phone)}
              />
              <FormHelperText
                id="helper-text-cPassword"
                className="helper-text"
              >
                {contactErr}
              </FormHelperText>
            </FormControl>
            <FormControl
              variant="filled"
              size="small"
              sx={{ margin: "6px 0 12px 0" }}
            >
              <InputLabel
                htmlFor="password"
                sx={{ color: `${colors.grey[100]}`, marginTop: "2px" }}
                required
              >
                Password
              </InputLabel>
              <FilledInput
                id="password"
                className="form_TxtField"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => handlePasswordChange(e)}
                placeholder="&#128477;"
                sx={{
                  backgroundColor: `${colors.redAccent[200]}`,
                  color: `${colors.redAccent[100]} !important`,
                  "& .MuiFormHelperText-root": {
                    color: `${colors.redAccent[900]}`,
                  },
                }}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      sx={{
                        color: `${colors.redAccent[100]}`,
                        marginLeft: "4px",
                      }}
                      edge="end"
                    >
                      {showPassword ? (
                        <VisibilityOffRoundedIcon />
                      ) : (
                        <VisibilityRoundedIcon />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
              />
              {pwdErr && (
                <FormHelperText
                  id="helper-text-password"
                  className="helper-text"
                >
                  {pwdErr}
                </FormHelperText>
              )}
              {passwordMsg && (
                <FormHelperText id="helper-text-password" className="message">
                  {passwordMsg}
                </FormHelperText>
              )}
            </FormControl>
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <InputLabel
                htmlFor="cpassword"
                sx={{ color: `${colors.grey[100]}`, marginTop: "2px" }}
                required
              >
                Confirm Password
              </InputLabel>
              <FilledInput
                id="cpassword"
                className="form_TxtField"
                type={showcPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => handleConfirmedPwdChange(e)}
                placeholder="&#128477;"
                sx={{
                  backgroundColor: `${colors.grey[900]}`,
                  color: "black !important",
                  "& .MuiFormHelperText-root": {
                    color: "red",
                  },
                }}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowcPassword}
                      sx={{
                        color: `${colors.redAccent[100]}`,
                        marginLeft: "4px",
                      }}
                      edge="end"
                    >
                      {showcPassword ? (
                        <VisibilityOffRoundedIcon />
                      ) : (
                        <VisibilityRoundedIcon />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
              />
              <FormHelperText
                id="helper-text-cPassword"
                className="helper-text"
              >
                {cnfErr}
              </FormHelperText>
            </FormControl>
            <Box>
              <input
                type="checkbox"
                checked={checked}
                id="agree"
                onClick={checkboxHandler}
              />
              <label className="ms-2">
                I agree to Cloverr's
                <span
                  className="ms-2 text-primary"
                  style={{ cursor: "pointer" }}
                  onClick={handleClickOpen}
                >
                  <strong>
                    Terms and conditions and Privacy Policy
                    <span className="text-danger ms-1">*</span>
                  </strong>
                </span>
              </label>
              <FormHelperText id="helper-text-checkbox" className="helper-text">
                {tncErr}
              </FormHelperText>
            </Box>
            <Typography
              variant="h5"
              margin={1}
              align="center"
              maxWidth={"490px"}
              sx={{ color: `${colors.redAccent[900]}` }}
            >
              {registerErr}
            </Typography>
            <Button
              type="submit"
              className="Register_btn"
              sx={{
                background: `${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
                Register
              </Typography>
            </Button>
          </Box>
        </form>
      </Box>
      <Dialog
        open={open}
        keepMounted
        onClose={handleClose}
        aria-describedby="alert-dialog-slide-description"
        sx={{
          "& .MuiDialog-paper": {
            borderRadius: "12px",
            backgroundColor: `${colors.blueAccent[500]}`,
          },
        }}
      >
        <DialogTitle display="flex" justifyContent="space-between">
          <Typography variant="h3">Cloverr Policy</Typography>
          <span onClick={handleClose} style={{ cursor: "pointer" }}>
            <CloseSharpIcon />
          </span>
        </DialogTitle>

        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            <Typography variant="h5">Work in Progress</Typography>
          </DialogContentText>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Register;
