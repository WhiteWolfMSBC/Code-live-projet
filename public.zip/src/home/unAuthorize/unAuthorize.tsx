import { Box, Button, FormControl, Typography, useTheme } from "@mui/material";
import React from "react";
import "./unAuthorize.scss";
import { tokens } from "../../theme";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

export default function UnAuthorized() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <Box>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | UnAuthorize</title>
      </Helmet>

      <Box
        className="container-unauthorize container-xl container-lg container-md container-sm container-xs"
        marginTop={4}
      >
        <Box className="page_404">
          <Box className="col-sm-12">
            <Box className="col-sm-10 col-sm-offset-1  text-center">
              <Box className="four_zero_four_bg">
                <Typography variant="h1" className="container_unauthorized-txth1 text-center text-danger">
                  401 !
                </Typography>
                <Typography variant="h4" className="container_unauthorized-txth4 text-center text-danger">
                  Unauthorized
                </Typography>
              </Box>

              <Box marginLeft="150px" marginTop={-13}>
                <Typography variant="h3" className="container_unauthorized-txth3 text-center text-primary">
                  Look like you're lost
                </Typography>

                <Typography variant="h3" className="container_unauthorized-txth3 text-center text-success">
                  The page you are looking for not available !
                </Typography>

                <FormControl>
                  <Link to="/" className="link_Typography-Home">
                    <Button
                    className="link_Typo-HomeBtn"
                      sx={{
                        background: `${colors.greenAccent[500]}`,
                        color: `${colors.grey[900]}`,
                        "&.MuiButton-root:hover": {
                          WebkitTextDecorationStyle: "none",
                          backgroundColor: `${colors.greenAccent[600]} !important`,
                        },
                      }}
                    >
                      <Typography variant="h6">Go to Home Page</Typography>
                    </Button>
                  </Link>
                </FormControl>
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
