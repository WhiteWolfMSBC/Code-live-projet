import React, { useEffect, useState } from "react";
import "./index.css";
import Login from "./home/login/Login";
import { Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./Admin/Super Admin Panel/Dashboard";
import { ColorModeContext, useMode } from "./theme";
import { ThemeProvider, CssBaseline } from "@mui/material";
import Sidebar from "./components/global/SideBar";
import ApplicationManagement from "./Admin/ApplicationManagement/ApplicationTable";
import UserTable from "./Admin/UserList/UserTable";
import AnalystTable from "./Admin/AnalystList/AnalystTable";
import Register from "./home/register/Register";
import AdminSetting from "./Admin/Setting/AdminSetting";
import UnAuthorized from "./UnAuthorized/UnAuthorized";
import IdeaGenerator from "./Analyst View/IdeaGenerator";
import OneIdeaPerDay from "./Analyst View/One Idea Per Day/OneIdeaPerDay";
import AlternativeWayExecute from "./Analyst View/Alternative Way Execute/AlternativeWayExecute";
import IdeaManagement from "./Analyst View/Idea Management/IdeaManagement";
import RevisedIdea from "./Analyst View/Revised Idea/RevisedIdea";
import ThematicBakset from "./Analyst View/Thematic Baskets/ThematicBaskets";
import ImageDarg from "./ImageDrag/ImageDarg";

function App() {
  const [theme, colorMode] = useMode();
  const [isCollapsed, setIsCollapsed] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [token, setToken] = useState("");
  useEffect(() => {
    console.log(token);
  }, [token]);
  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {isLoggedIn && !token && (
          <Routes>
            <Route
              path="/"
              element={
                <Login
                  isLoggedIn={isLoggedIn}
                  setIsLoggedIn={setIsLoggedIn}
                  setToken={setToken}
                />
              }
            ></Route>
            <Route path="/register" element={<Register />}></Route>
          </Routes>
        )}
        {!isLoggedIn && (
          <div
            className="app"
            style={{ background: `${theme.palette.primary.mainGradient}` }}
          >
            <Sidebar
              isCollapsed={isCollapsed}
              setIsCollapsed={setIsCollapsed}
            />
            <main className="content">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route
                  path="/applicationmanagement"
                  element={<ApplicationManagement />}
                />
                <Route path="/usertable" element={<UserTable />} />
                <Route path="/analysttable" element={<AnalystTable />} />
                <Route path="/forgotPd" element={<IdeaGenerator />} />
                <Route path="/unauthorized" element={<UnAuthorized />} />
                {/* <Route path="/settings" element={<OneIdeaPerDay />} /> */}
                <Route path="/settings" element={<ImageDarg />} />
                <Route
                  path="*"
                  element={<Navigate to="/unauthorized" replace />}
                />
              </Routes>
            </main>
          </div>
        )}
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export default App;
