import React from "react";
import {
  AppBar,
  Toolbar,
  CssBaseline,
  Typography,
  useTheme,
} from "@mui/material";
import { Link } from "react-router-dom";


const useStyles = {
  navlinks: {
    marginLeft: '5px',
    display: "flex",
  },
  logo: {
    flexGrow: "1",
    cursor: "pointer",
  },
  link: {
    textDecoration: "none",
    color: "white",
    fontSize: "20px",
    marginLeft: '20px',
    "&:hover": {
      color: "yellow",
      borderBottom: "1px solid white",
    },
  },
}

function Navbar() {
  return (
    <AppBar position="static">
      <CssBaseline />
      <Toolbar>
        <Typography variant="h4" style={useStyles.logo}>
          Cloverr
        </Typography> 
          <div style={useStyles.navlinks}>
            <Link to="/" style={useStyles.link}>
              Home
            </Link>
            <Link to="/about" style={useStyles.link}>
              About
            </Link>
            <Link to="/contact" style={useStyles.link}>
              Contact us
            </Link>
            <Link to="/login" style={useStyles.link}>
              Login
            </Link>
          </div>
      </Toolbar>
    </AppBar>
  );
}
export default Navbar;