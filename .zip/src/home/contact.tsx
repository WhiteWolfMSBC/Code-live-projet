import React from 'react'
import NavBar from './NavBar'

function contact() {
  return (
    <div>
        <NavBar/>
        contact
    </div>
  )
}

export default contact