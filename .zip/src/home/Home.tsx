import React from 'react'
import NavBar from './NavBar'
import './home.css';
import { Typography } from '@mui/material';

function Home() {
  const cardData=[
    {
      image:'',
      title:'Knowledge',
      description:'Daily actionable ideas and educational content curated by Wall street experts in your own language'
    },
    {
      image:'',
      title:'Information',
      description:'Global financial markets information you need to know'
    },
    {
      image:'',
      title:'Access',
      description:'Broker newutral platform allows you to invest via linked investment and trading accound of your choice'
    }
  ]
  return (
    <div>
        <NavBar/>
        <div className='container'>
          <Typography 
            variant='h2' 
            align='center'
            sx={{
              paddingTop:'30px'
              
            }}
          >
            Control Your finanacial futures
          </Typography>
          <hr></hr>
          <Typography 
            variant='h5' 
            align='center'
            sx={{
              paddingTop:'20px'
            }}
          >
            Through Compounding knowledge
          </Typography>
          <div className='card-container'>
            <div className='card col-md-3 col-lg-3'>
              <img></img>
              <Typography variant='h4' align='center'>Knowledge</Typography>
              <Typography variant='h6' align='center'>Daily actionable ideas and educational content curated by Wall street experts in your own language</Typography>
            </div>
            <div className='card col-md-3 col-lg-3'>
              <img></img>
              <Typography variant='h4' align='center'>Information</Typography>
              <Typography variant='h6' align='center'>Global financial markets information you need to know</Typography>
            </div>
            <div className='card col-md-3 col-lg-3'>
              <img></img>
              <Typography variant='h4' align='center'>Access</Typography>
              <Typography variant='h6' align='center'>Broker newutral platform allows you to invest via linked investment and trading accound of your choice</Typography>
            </div>
          </div>
        </div>
    </div>
  )
}

export default Home