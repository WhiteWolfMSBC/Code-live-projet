import { Box, Button, CircularProgress, Icon, Input, InputAdornment, Link, RadioGroup, TextField, Typography, useTheme} from '@mui/material';
import React, { HtmlHTMLAttributes, useState } from 'react';
import './Login.css';
import { tokens } from '../../theme';
import Icon1 from '../../assets/Frame.svg';
import SearchIcon from "@mui/icons-material/Search";
import {authorizeLogin} from '../../api/LoginApi';
import axios from 'axios';
import { Router, useNavigate } from 'react-router-dom';
 

interface LoginSchema{
  isLoggedIn: boolean;
  setIsLoggedIn : any;
  setToken : any;
}

const  Login = (props:LoginSchema)=> {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [username,setUsername] = useState<string | null>('');
  const [password,setPassword] = useState<string| null>('');
  const [pwdErr, setPwdErr] = useState('');
  const [userErr, setUserErr] = useState('');
  const [globalErr,setGlobalErr] = useState('');
  const LOGIN_URL = 'http://192.168.71.66:5000/login/';
  const [loader,setLoader] = useState(false);
  const navigate = useNavigate();
  const handleUsernameChange = (e:React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>{
    setUsername(e.target.value);
  }
  const handlePasswordChange = (e:React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>{
    setPassword(e.target.value);
  }
  const handleSubmit = async (e:React.MouseEvent<HTMLButtonElement, MouseEvent>) =>{
    setLoader(true);
    console.log('username and password',username,password);
      if(username == '' || username == null){
        setUserErr('Please Enter Username');
      }
      if(password == '' || password == null){
        setPwdErr('Please Enter Password');
      }
      if(username != '' && password != ''){
        try{
            const response = await axios.post(
            LOGIN_URL,
            {username:username,password:password},
          );
          console.log(response);
          if(response.data.Status == 200){
            props.setIsLoggedIn(true);
            props.setToken(response.data.Token);
            console.log(response.data.Token);
            console.log(response.data.Message);
            setLoader(false);
            navigate('/dashboard');
          }
          else{
            setGlobalErr('Invalid Username and passowrd')
          }
        }
        catch(err){
          console.log('this is catch',err);
        }
          // const accessToken = response?.data?.accessToken;
          // const roles = response?.data?.roles;   
    }
  }
  return (
    <Box
      height={'100%'}
      className='main-container'
    >
        {/* <CircularProgress color="inherit" /> */}
        {/* for Image  */}
        <Box width={'60%'} sx={{
          backgroundImage:`url(${Image})`,
          backgroundSize:'cover'
        }}>
        </Box>
        {/* for right side content */}
        <Box width={'40%'} 
          sx={{
            display:'flex',
            flexDirection:'column',
            padding:'10%'
          }}
        >
          
          {/* title and logo */}
          <Box display='flex' justifyContent='flex-start'>
            <img src={Icon1} width='42px' height='42px'/>
            <Typography variant='h2' align='justify' alignSelf='center' fontWeight='700' color={colors.greenAccent[500]}>CLOVERR</Typography>
          </Box>
          {/* heading anf descrption */}
          <Box>
            <Typography variant='h2' margin='40px 0 8px 0'>Hello Again!</Typography>
            <Typography variant='h4'>Welcome back</Typography>
          </Box>
          {globalErr && <Typography variant='h4' align='center'>{globalErr}</Typography>}
          <Box
            display='flex'
            flexDirection = 'column'
            margin={'60px 0 0 0'}
          >
            
            <Typography variant='h4'>Username</Typography>
            <TextField 
                id="username"
                variant="filled"
                label="Username"
                placeholder='&#x2709;'
                type="text"
                size="medium"
                value={username}
                onChange={(e)=>handleUsernameChange(e)}
                sx={{ 
                  backgroundColor:'white', 
                  margin:'6px 0 12px 0',
                  borderRadius:'24px',
                  '& .MuiFilledInput-root':{
                    color:'black !important',
                    borderRadius:'24px !important',
                  },
                  '& .MuiFilledInput-root:before':{
                    borderBottom:'0px !important'
                  },
                  '& .MuiFormHelperText-root':{
                    color:'red'
                  }
                }}
                helperText={userErr}
            />
            <Typography variant='h4'>Password</Typography>
            <TextField 
              id="password"
              variant="filled"
              placeholder='&#xF002;'
              label="Password"
              type="password"
              value={password}
              autoComplete="current-password"
              size="medium"
              onChange={(e)=>handlePasswordChange(e)}
              sx={{ 
                backgroundColor:'white',
                margin:'6px 0 12px 0',
                borderRadius:'24px',
                color:'black !important',
                '& .MuiFilledInput-root':{
                  color:'black !important',
                  borderRadius:'24px !important'
                },
                '& .MuiFilledInput-root:before':{
                  borderBottom:'0px !important'
                },
                '& .MuiFormHelperText-root':{
                  color:'red'
                }
              }}
              helperText={pwdErr}
            />
            <Button 
              sx={{
                background:`${colors.greenAccent[500]}`,
                margin:'12px 0 12px 0',
                height:'50px',
                borderRadius:'24px !important',
                fontWeight:'700',
                '& .css-1y4fclp-MuiButtonBase-root-MuiButton-root':{
                  color:'white !important'
                }
              }}
              onClick={e => handleSubmit(e)}
              >
              Login
            </Button>
            <Typography align='center'>Don't have an account? <Link href='/register' sx={{color:'white'}}>Click Here</Link></Typography>
          </Box>
        </Box>
        {/* <Typography variant='h4' align='center' p={2}> Login </Typography>
        <Box sx={{ 
          display:'flex',
          alignItems:'center',
          flexDirection: 'column' 
          }}
        >
          <Button href='/user' variant="contained" size="medium" sx={{margin:'10px',width:'10%',background:'#666666'}}>User</Button>
          <Button href='/admin' variant="contained" size="medium" sx={{margin:'10px',width:'10%',background:'#666666'}}>Admin</Button>
          <Button href='/analyst' variant="contained" size="medium" sx={{margin:'10px',width:'10%',background:'#666666'}}>Analyst</Button>
        </Box> */}
    </Box>
  )
}
export default Login;