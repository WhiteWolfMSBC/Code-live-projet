import React from 'react'
import NavBar from './NavBar'

function About() {
  return (
    <div>
        <NavBar/>
        About
    </div>
  )
}

export default About