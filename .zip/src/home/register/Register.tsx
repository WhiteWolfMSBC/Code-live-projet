import {
  Box,
  Button,
  Icon,
  Input,
  InputAdornment,
  Link,
  RadioGroup,
  TextField,
  Typography,
  useTheme,
  Autocomplete,
} from "@mui/material";
import React, { HtmlHTMLAttributes, useEffect, useState } from "react";
import { tokens } from "../../theme";
import Icon1 from "../../assets/Frame.svg";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [username, setUsername] = useState<string | null>("");
  const [password, setPassword] = useState<string | null>("");
  const [firstName, setFirstName] = useState<string | null>("");
  const [lastName, setLastName] = useState<string | null>("");
  const [emailId, setEmailId] = useState<string | null>("");
  const [profession, setProfession] = useState<string | null>("");
  const [contactNo, setContactNo] = useState<number | null>();
  const [confirmPassword, setConfirmPassowrd] = useState<string | null>("");
  const [pwdErr, setPwdErr] = useState("");
  const [userErr, setUserErr] = useState("");
  const [load, setLoad] = useState(false);
  const REGISTER_URL = "http://192.168.71.66:5000/register/";
  const p_label = [
    {
      label:'IT',
      id:1
    },
    {
      label:'Medical',
      id:2

    },
    {
      label:'Technology',
      id:3
    },
    {
      label:'Energy',
      id:4
    },
  ]
  const handleEmailChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setEmailId(e.target.value);
  };
  const handleFirstNameChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFirstName(e.target.value);
  };
  const handleLastNameChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setLastName(e.target.value);
  };
  const handleUserNameChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setUsername(e.target.value);
  };
  const handleProfessionChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setProfession(e.target.value);
  };
  const handleContactChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setContactNo(parseInt(e.target.value));
  };
  const handlePasswordChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setPassword(e.target.value);
  };
  const handleConfirmedPwdChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setConfirmPassowrd(e.target.value);
  };
  const handleProffession = (e:any)=>{
    console.log(e.target.value);
    setProfession(e.target.value);
  }
  const navigate = useNavigate();
  const handleSubmit = async (
    e: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    console.log("username and password", username, password);
    if (username == "" || username == null) {
      setUserErr("Please Enter Email id");
    }
    if (password == "" || password == null) {
      setPwdErr("Please Enter Password");
    }
    if (username != "" && password != "") {
      try {
        console.log("Inside try");
        await axios
          .post(REGISTER_URL, {
            username: username,
            password: password,
          })
          .then((response) => {
            console.log("this is response", response);
            const message = response.data.Message;
            const user = response.data.User;
            console.log(message, user);
            if (message == "Registered Successfully.") {
              setLoad(true);
              navigate("/");
            } else {
              setPwdErr("Invalid Input");
            }
          })
          .catch((error) => {
            console.log("this is inside catch", error);
          });
      } catch (err) {
        console.log("this is catch", err);
      }
      // // const accessToken = response?.data?.accessToken;
      // // const roles = response?.data?.roles;
    }
  };
  const [cnfErr,setCnfErr] = useState('');
  useEffect(()=>{
    console.log(emailId);
    console.log(firstName);
    console.log(lastName);
    console.log(username);
    console.log(password);
    console.log(confirmPassword);
    console.log(profession);
    console.log(contactNo);
  },[username])
  useEffect(()=>{
    if(password != '' && confirmPassword != ''){
      if(password != confirmPassword){
        setCnfErr('Password do not match');
      }
    }
  },[confirmPassword])
  return (
    <Box
      height={"100%"}
      sx={{
        display: "flex",
        justifyContent: "center",
      }}
    >
      {/* for Image  */}
      {/* <Box width={'60%'} sx={{
          backgroundImage:`url(${Image})`,
          backgroundSize:'cover'
        }}>
        </Box> */}
      {/* for right side content */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          padding: "2%",
          width: "500px",
        }}
      >
        {/* title and logo */}
        <Box display="flex" justifyContent="center">
          <img src={Icon1} width="42px" height="42px" />
          <Typography
            variant="h2"
            align="justify"
            alignSelf="center"
            fontWeight="700"
            color={colors.greenAccent[500]}
          >
            CLOVERR
          </Typography>
        </Box>
        {/* heading anf descrption */}
        <Box alignSelf="center">
          <Typography variant="h2" margin="20px 0 8px 0">
            Register Here!!{" "}
          </Typography>
          {/* <Typography variant='h4'>Welcome to Cloverr</Typography> */}
        </Box>
        <Box display="flex" flexDirection="column" margin={"40px 0 0 0"}>
          <Typography variant="h4">Email Id</Typography>
          <TextField
            id="emailId"
            variant="filled"
            label="emailid"
            placeholder="&#x2709;"
            type="text"
            size="small"
            value={emailId}
            onChange={(e) => handleEmailChange(e)}
            sx={{
              backgroundColor: "white",
              margin: "6px 0 12px 0",
              borderRadius: "24px",
              "& .MuiFilledInput-root": {
                color: "black !important",
                backgroundColor: "white",
                borderRadius: "24px !important",
              },
              "& .MuiFilledInput-root:before": {
                borderBottom: "0px !important",
              },
              "& .MuiFormHelperText-root": {
                color: "red",
              },
            }}
            helperText={userErr}
          />
          <Typography variant="h4">Username</Typography>
          <TextField
            id="username"
            variant="filled"
            label="Username"
            placeholder="&#x2709;"
            type="text"
            size="small"
            value={username}
            onChange={(e) => handleUserNameChange(e)}
            sx={{
              backgroundColor: "white",
              margin: "6px 0 12px 0",
              borderRadius: "24px",
              "& .MuiFilledInput-root": {
                color: "black !important",
                backgroundColor: "white",
                borderRadius: "24px !important",
              },
              "& .MuiFilledInput-root:before": {
                borderBottom: "0px !important",
              },
              "& .MuiFormHelperText-root": {
                color: "red",
              },
            }}
            helperText={userErr}
          />
          <Typography variant="h4">First Name</Typography>
          <TextField
            id="firstname"
            variant="filled"
            label="First Name"
            placeholder="&#x2709;"
            type="text"
            size="small"
            value={firstName}
            onChange={(e) => handleFirstNameChange(e)}
            sx={{
              backgroundColor: "white",
              margin: "6px 0 12px 0",
              borderRadius: "24px",
              "& .MuiFilledInput-root": {
                color: "black !important",
                backgroundColor: "white",
                borderRadius: "24px !important",
              },
              "& .MuiFilledInput-root:before": {
                borderBottom: "0px !important",
              },
              "& .MuiFormHelperText-root": {
                color: "red",
              },
            }}
            helperText={userErr}
          />
          <Typography variant="h4">Last Name</Typography>
          <TextField
            id="lastname"
            variant="filled"
            label="lastname"
            placeholder="&#x2709;"
            type="text"
            size="small"
            value={lastName}
            onChange={(e) => handleLastNameChange(e)}
            sx={{
              backgroundColor: "white",
              margin: "6px 0 12px 0",
              borderRadius: "24px",
              "& .MuiFilledInput-root": {
                color: "black !important",
                backgroundColor: "white",
                borderRadius: "24px !important",
              },
              "& .MuiFilledInput-root:before": {
                borderBottom: "0px !important",
              },
              "& .MuiFormHelperText-root": {
                color: "red",
              },
            }}
            helperText={userErr}
          />
          <Typography variant="h4">Contanct No.</Typography>
          <TextField
            id="contact"
            variant="filled"
            placeholder="&#x2709;"
            type="number"
            size="small"
            value={contactNo}
            onChange={(e) => handleContactChange(e)}
            sx={{
              backgroundColor: "white",
              margin: "6px 0 12px 0",
              borderRadius: "24px",
              "& .MuiFilledInput-root": {
                color: "black !important",
                backgroundColor: "white",
                borderRadius: "24px !important",
              },
              "& .MuiFilledInput-root:before": {
                borderBottom: "0px !important",
              },
              "& .MuiFormHelperText-root": {
                color: "red",
              },
            }}
            helperText={userErr}
          />
          <Typography variant="h4">Profession</Typography>
          <Autocomplete
            clearOnEscape
            id="combo-box-demo"
            options={p_label}
            onSelect={(e:any) => handleProffession(e)}
            renderInput={(params:any) => 
              <TextField 
                variant="filled" 
                {...params} 
                label="Profession" 
                size='small'
                sx={{
                  backgroundColor: "white",
                  margin: "6px 0 12px 0",
                  borderRadius: "24px",
                  "& .MuiFilledInput-root": {
                    color: "black !important",
                    backgroundColor: "white",
                    borderRadius: "24px !important",
                  },
                  "& .MuiFilledInput-root:before": {
                    borderBottom: "0px !important",
                  },
                  "& .MuiFormHelperText-root": {
                    color: "red",
                  },
                }}
                />}
          />
          <Typography variant="h4">Password</Typography>
          <TextField
            id="password"
            variant="filled"
            placeholder="&#xF002;"
            label="Password"
            type="password"
            value={password}
            autoComplete="current-password"
            size="small"
            onChange={(e) => handlePasswordChange(e)}
            sx={{
              backgroundColor: "white",
              margin: "6px 0 12px 0",
              borderRadius: "24px",
              color: "black !important",
              "& .MuiFilledInput-root": {
                color: "black !important",
                borderRadius: "24px !important",
              },
              "& .MuiFilledInput-root:before": {
                borderBottom: "0px !important",
              },
              "& .MuiFormHelperText-root": {
                color: "red",
              },
            }}
            helperText={pwdErr}
          />
          <Typography variant="h4">Confirmed Password</Typography>
          <TextField
            id="cpassword"
            variant="filled"
            placeholder="&#xF002;"
            label="Confirmed Password"
            type="password"
            value={confirmPassword}
            autoComplete="current-password"
            size="small"
            onChange={(e) => handleConfirmedPwdChange(e)}
            sx={{
              backgroundColor: "white",
              margin: "6px 0 12px 0",
              borderRadius: "24px",
              color: "black !important",
              "& .MuiFilledInput-root": {
                color: "black !important",
                borderRadius: "24px !important",
              },
              "& .MuiFilledInput-root:before": {
                borderBottom: "0px !important",
              },
              "& .MuiFormHelperText-root": {
                color: "red",
              },
            }}
            helperText={cnfErr}
          />
          <Typography>
            Placeholder for checkbox of terms and condition
          </Typography>
          <Button
            sx={{
              background: `${colors.greenAccent[500]}`,
              margin: "12px 0 12px 0",
              height: "50px",
              borderRadius: "24px !important",
              fontWeight: "700",
              "& .MuiButtonBase-root .MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",
                backgroundColor: "grey !important",
              },
            }}
            onClick={(e) => handleSubmit(e)}
          >
            <Typography variant="h5" color="white">
              Register
            </Typography>
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default Register;
