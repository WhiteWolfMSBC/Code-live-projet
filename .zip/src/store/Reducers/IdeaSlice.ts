import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../store";
//import { fetchCount } from './counterAPI';

export interface UserState {
  imageUpload: boolean;
  mediaLink: boolean;
  chartUpload: boolean;
  videoUpload: boolean;
  wayToTrade: boolean;
  text: boolean;
  textBox: boolean;
  tag: boolean;
}

const initialState: UserState = {
  imageUpload: false,
  mediaLink: false,
  chartUpload: false,
  videoUpload: false,
  wayToTrade: false,
  text: false,
  textBox: false,
  tag: false,
};

export const ideaSlice = createSlice({
  name: "idea",
  initialState,
  // The `reducers` field lets us define reducers and generate associated actions
  reducers: {
    set_Editor: (state, action) => {
      switch (action.payload.type) {
        case "imageUpload":
          state.imageUpload = true;
          break;
        case "mediaLink":
          state.mediaLink = true;
          break;
        case "chartUpload":
          state.chartUpload = true;
          break;
        case "wayToTrade":
          state.wayToTrade = true;
          break;
        case "videoUpload":
          state.videoUpload = true;
          break;
        case "text":
          state.text = true;
          break;
        case "textBox":
          state.textBox = true;
          break;
        case "tag":
          state.tag = true;
          break;
      }
    },
  },
});

export const imageUpload = (state: RootState) => state.idea.imageUpload;
export const mediaLink = (state: RootState) => state.idea.mediaLink;
export const chartUpload = (state: RootState) => state.idea.chartUpload;
export const wayToTrade = (state: RootState) => state.idea.wayToTrade;
export const videoUpload = (state: RootState) => state.idea.videoUpload;
export const text = (state: RootState) => state.idea.text;
export const textBox = (state: RootState) => state.idea.textBox;
export const tag = (state: RootState) => state.idea.tag;

export const { set_Editor } = ideaSlice.actions;

export default ideaSlice.reducer;
