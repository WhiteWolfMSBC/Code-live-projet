import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState, AppThunk } from '../store';
//import { fetchCount } from './counterAPI';

export interface UserState {
  username:string;
  password:string;
}

const initialState: UserState = {
  username:'',
  password:''
};


export const userSlice = createSlice({
  name: 'user',
  initialState,
  // The `reducers` field lets us define reducers and generate associated actions
  reducers: {
    setUsername:(state,action)=>{
        state.username = action.payload;
    },
    setPassword:(state,action)=>{
        state.password = action.payload;
    }
  },
});


export const { setUsername, setPassword} = userSlice.actions;

export default userSlice.reducer;
