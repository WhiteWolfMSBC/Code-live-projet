import React from "react";
import { Helmet } from "react-helmet";
import { Box, IconButton, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";

export default function TextBox1() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | TextBox</title>
      </Helmet>

      {/* TextEditor */}

      <Box
        sx={{ background: `${colors.greenAccent[500]}` }}
        className="textEditor_Box" marginTop={2}
      >
              <Box>
          {/* Main Buttons */}
          <Box
            display="flex"
            justifyContent={"space-between"}
            sx={{
              background: `${colors.primary[600]}`,
              borderRadius: "5px",
              boxShadow: "0 10px 25px rgb(39 41 43 / 20%)",
            }}
          >
            <Box display={"flex"}>
              <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                <ControlCameraIcon />
              </IconButton>
            </Box>

            <Box display={"flex"}>
              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <BorderColorIcon />
              </IconButton>

              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <AddBoxIcon />
              </IconButton>

              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <DeleteIcon />
              </IconButton>
            </Box>
          </Box>
        </Box>
        <Box
          display="flex"
          flexDirection="column"
          sx={{ padding: "20px 30px 20px 30px" }}
        >
          <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
            <Typography
              variant="h1"
              sx={{ color: `${colors.grey[900]}` }}
              marginBottom={2}
            >
              CaptionPreview <br /> <br /> This is a text box.You can use it to add
              text to your template.
            </Typography>
          </Box>
        </Box>
      </Box>
    </>
  );
}
