import React from "react";
import "../Items/Items.css";
import "./RightTab.css";
import { Helmet } from "react-helmet";
import {
  Box,
  Button,
  IconButton,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";

export default function Tag1() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Tag</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="textEditor_Box" marginTop={2}>
        <Box>
          {/* Main Buttons */}
          <Box
            display="flex"
            justifyContent={"space-between"}
            sx={{
              background: `${colors.primary[600]}`,
              borderRadius: "5px",
              boxShadow: "0 10px 25px rgb(39 41 43 / 20%)",
            }}
          >
            <Box display={"flex"}>
              <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                <ControlCameraIcon />
              </IconButton>
            </Box>

            <Box display={"flex"}>
              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <BorderColorIcon />
              </IconButton>

              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <AddBoxIcon />
              </IconButton>

              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <DeleteIcon />
              </IconButton>
            </Box>
          </Box>
        </Box>
        <Box
          display="flex"
          flexDirection="column"
          sx={{ padding: "20px 30px 20px 30px" }}
        >
          <Box
            alignSelf={"center"}
            marginTop={2}
            marginRight={4}
            marginLeft={4}
          >
            {/* Perform mapping in Buttons */}

            <Button
              className="me-3"
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              # bullish
            </Button>
            <Button
              className="me-3"
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              # bearish
            </Button>
            <Button
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              # options
            </Button>
          </Box>
        </Box>
      </Box>
    </>
  );
}
