import {
  Box,
  Card,
  FormControl,
  IconButton,
  Typography,
  useTheme,
} from "@mui/material";
import React from "react";
import { Helmet } from "react-helmet";
import { tokens } from "../../theme";
import ControlCameraIcon from "@mui/icons-material/ControlCamera";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import AddBoxIcon from "@mui/icons-material/AddBox";
import DeleteIcon from "@mui/icons-material/Delete";

export default function VideoUpload1() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | VideoUpload</title>
      </Helmet>

      <Box className="textEditor_Box" marginTop={2}>
        <Box>
          {/* Main Buttons */}
          <Box
            display="flex"
            justifyContent={"space-between"}
            sx={{
              background: `${colors.primary[600]}`,
              borderRadius: "5px",
              boxShadow: "0 10px 25px rgb(39 41 43 / 20%)",
            }}
          >
            <Box display={"flex"}>
              <IconButton size="large" sx={{ color: `${colors.grey[900]}` }}>
                <ControlCameraIcon />
              </IconButton>
            </Box>

            <Box display={"flex"}>
              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <BorderColorIcon />
              </IconButton>

              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <AddBoxIcon />
              </IconButton>

              <IconButton
                size="large"
                color="inherit"
                sx={{ color: `${colors.grey[900]}` }}
              >
                <DeleteIcon />
              </IconButton>
            </Box>
          </Box>
        </Box>
      </Box>

      {/* Video Url Preview */}

      <Box className="textEditor_Box" marginTop={2}>
        <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
          <FormControl
            variant="filled"
            size="small"
            className="field-container"
          ></FormControl>
        </Box>
      </Box>

      {/* text Box input */}
      <Box className="textEditor_Box" marginTop={2}>
        <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
          <FormControl
            variant="filled"
            size="small"
            className="field-container"
          >
            <Typography
              variant="h5"
              sx={{ color: `${colors.grey[900]}` }}
              marginBottom={2}
            >
              Input caption text here. Use the block's Settings tab to change
              the caption position and set other styles.
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
