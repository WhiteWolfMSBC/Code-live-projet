import { Box, Button, FormControl, Typography, useTheme } from "@mui/material";
import React from "react";
import { tokens } from "../../theme";
import CenterGrid from "./Grid/CenterGrid";
import LeftGrid from "./Grid/LeftGrid";
import RightGrid from "./Grid/RightGrid";
import "./RevisedIdea.css";
import { Helmet } from "react-helmet";
import TopBar from "../../components/global/TopBar";

export default function RevisedIdea() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | AlternativeWayExecute</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Typography
            variant="h4"
            marginLeft={4}
            marginTop={1.5}
            color={colors.greenAccent[500]}
            className="Typography"
          >
            Alternative Way Execute
          </Typography>
        </Box>

        <Box display={"flex"} p={1.5}>
          <FormControl sx={{ padding: "12px 16px 12px 16px !important" }}>
            <Button
              sx={{
                background: `${colors.greenAccent[500]}`,
                margin: "12px 0 12px 0",
                height: "40px",
                borderRadius: "24px !important",
                fontWeight: "700",
                padding: "20px 60px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              Accept Revised
            </Button>
          </FormControl>

          <FormControl sx={{ padding: "12px 16px 12px 16px !important" }}>
            <Button
              className="CreateIdea_btn"
              sx={{
                color: `${colors.grey[900]}`,
                fontWeight: "700",
                padding: "20px 60px",
                margin: "12px 0 12px 0",
                height: "40px",
              }}
              variant="outlined"
              color="success"
            >
              Declined Revised
            </Button>
          </FormControl>

          <TopBar />
        </Box>
      </Box>

      <Box
        display={"flex"}
        justifyContent={"center"}
        className="row"
        marginLeft={4}
        marginTop={1.5}
      >
        <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-6">
          <LeftGrid />
        </Box>
        <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-6">
          <CenterGrid />
        </Box>
        <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-6">
          <RightGrid />
        </Box>
      </Box>
    </>
  );
}
