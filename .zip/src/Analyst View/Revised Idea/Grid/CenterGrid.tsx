/* eslint-disable jsx-a11y/alt-text */
import { Box, Button, Typography, useTheme } from "@mui/material";
import React from "react";
import { tokens } from "../../../theme";

function CenterGrid() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <Box>
      <Box display="flex" flexDirection="column">
        <Box alignSelf={"left"}>
          {/* Perform mapping in Buttons */}

          <Button
            className="me-3"
            sx={{
              background: "#4E33FF",
              color: `${colors.grey[900]}`,
              minHeight: "22px",
              fontSize: "10px",
              borderRadius: "24px !important",
              fontWeight: "400",
              textAlign: "center",
              minWidth: "max-content",
              padding: "4px 9px 4px 9px",
              "&.MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",
                backgroundColor: `${colors.greenAccent[600]} !important`,
              },
            }}
          >
            Real Estate
          </Button>
          <Button
            className="me-3"
            sx={{
              background: "#4E33FF",
              color: `${colors.grey[900]}`,
              minHeight: "22px",
              fontSize: "10px",
              borderRadius: "24px !important",
              fontWeight: "400",
              textAlign: "center",
              minWidth: "max-content",
              padding: "4px 9px 4px 9px",
              "&.MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",
                backgroundColor: `${colors.greenAccent[600]} !important`,
              },
            }}
          >
            Energy
          </Button>
          <Button
            sx={{
              background: "#4E33FF",
              color: `${colors.grey[900]}`,
              minHeight: "22px",
              fontSize: "10px",
              borderRadius: "24px !important",
              fontWeight: "400",
              textAlign: "center",
              minWidth: "max-content",
              padding: "4px 9px 4px 9px",
              "&.MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",
                backgroundColor: `${colors.greenAccent[600]} !important`,
              },
            }}
          >
            Health
          </Button>
        </Box>
      </Box>

      <Box display={"flex"} flexDirection={"column"} marginTop={3}>
        <Box alignSelf={"left"}>
          <Typography
            sx={{ color: `${colors.grey[900]}`, fontWeight: 600 }}
            variant="h2"
          >
            Tital
          </Typography>

          <Typography
            sx={{ color: `${colors.grey[900]}`, fontWeight: 400 }}
            variant="h5"
          >
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. At facere
            nesciunt necessitatibus quidem! Ipsum reprehenderit harum asperiores
            facilis nesciunt suscipit consectetur illo hic, fuga ducimus,
            quisquam quidem eligendi odit numquam. Earum ipsam nulla officiis
            labore repudiandae natus, ipsum eligendi quaerat, iusto quos
            distinctio? facilis nesciunt suscipit consectetur facilis nesciunt
            suscipit consectetur.
          </Typography>

          <Typography
            sx={{ color: `${colors.redAccent[900]}`, fontWeight: 400 }}
            variant="h5"
          >
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. At facere
            nesciunt necessitatibus quidem! Ipsum reprehenderit harum asperiores
            facilis nesciunt suscipit consectetur illo hic, fuga ducimus,
            quisquam quidem eligendi odit numquam. Earum ipsam nulla officiis
            labore repudiandae natus, ipsum eligendi quaerat, iusto quos
            distinctio? facilis nesciunt suscipit consectetur facilis nesciunt
            suscipit consectetur.
          </Typography>
        </Box>

        <Box alignSelf={"left"} marginTop={3}>
          <Typography
            sx={{ color: `${colors.grey[900]}`, fontWeight: 600 }}
            variant="h2"
          >
            Subtitle
          </Typography>

          <Typography
            sx={{ color: `${colors.grey[900]}`, fontWeight: 400 }}
            variant="h5"
          >
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. At facere
            nesciunt necessitatibus quidem! Ipsum reprehenderit harum asperiores
            facilis nesciunt suscipit consectetur illo hicfuga ducimus, quisquam
            quidem eligendi odit numquam.
          </Typography>

          <Box marginTop={2}>
            <img
              className="img-fluid imgIdea"
              src={
                "https://images.unsplash.com/photo-1560221328-12fe60f83ab8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OHx8c3RvY2slMjBtYXJrZXR8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"
              }
            />
          </Box>
        </Box>

        <Box alignSelf={"left"} marginTop={3}>
          <Typography
            sx={{ color: `${colors.grey[900]}`, fontWeight: 600 }}
            variant="h2"
          >
            Subtitle
          </Typography>

          <Typography
            sx={{ color: `${colors.redAccent[900]}`, fontWeight: 400 }}
            variant="h5"
          >
            {/* Lorem ipsum, dolor sit amet consectetur adipisicing elit. At facere
            nesciunt necessitatibus quidem! Ipsum reprehenderit harum asperiores
            facilis nesciunt suscipit consectetur illo hicfuga ducimus, quisquam
            quidem eligendi odit numquam. */}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
}

export default CenterGrid;
