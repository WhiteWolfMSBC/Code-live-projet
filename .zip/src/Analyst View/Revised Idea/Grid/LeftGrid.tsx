import { Box, Card, Typography, useTheme } from "@mui/material";
import React from "react";
import { tokens } from "../../../theme";
import "../RevisedIdea.css";

function LeftGrid() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <div>
      <Box>
        <Box className="containerCard">
          <Card
            className="colorCard"
            sx={{
              background:
                "url(https://images.pexels.com/photos/802024/pexels-photo-802024.jpeg?auto=compress&cs=tinysrgb&w=1600)",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
              backgroundSize: "cover",
              opacity: 0.4,
            }}
          ></Card>
          <Box className="bottom-left" alignSelf={"left"}>
            <Typography
              sx={{ color: `${colors.grey[900]}`, fontWeight: 700 }}
              variant="h2"
            >
              Bloomberg Insight Report
            </Typography>
            <Typography
              sx={{ color: `${colors.grey[900]}`, fontWeight: 400 }}
              variant="h6"
            >
              Bloomberg Terminals to Get Broad.
            </Typography>
          </Box>
        </Box>
        <Box marginTop={2}>
          <Card
            className="colorCard1"
            sx={{
              background:
                "url(https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8c3RvY2slMjBtYXJrZXR8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60)",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
              backgroundSize: "cover",
              opacity: 0.4,
            }}
          ></Card>
        </Box>
      </Box>
    </div>
  );
}

export default LeftGrid;
