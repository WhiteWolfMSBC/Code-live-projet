import {
  Box,
  Button,
  Card,
  FormControl,
  Slider,
  Typography,
  useTheme,
} from "@mui/material";
import React from "react";
import { tokens } from "../../../theme";
import "../RevisedIdea.css";
import ReportOutlinedIcon from "@mui/icons-material/ReportOutlined";

function valuetext(value: number) {
  return `${value}°C`;
}

function RightGrid() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <Box>
      <Box className="containerCard">
        <Card
          className="containerRightCard"
          sx={{
            backgroundColor: `${colors.primary[400]}`,
          }}
        >
          <Typography variant="h3" sx={{ color: `${colors.greenAccent[500]}` }}>
            <span className="text-light">Creator</span> Rating
          </Typography>

          <Box className="row" marginTop={5}>
            <Box className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6">
              <Box alignSelf={"center"}>
                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Super User : Andy Kim
                </Typography>

                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Type : Quart
                </Typography>

                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Ideas : 20
                </Typography>

                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Wins : 15
                </Typography>
              </Box>
            </Box>
            <Box className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6">
              <Box alignSelf={"center"}>
                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Hit Ratio : 70%
                </Typography>

                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Avg Win : 9%
                </Typography>

                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Avg Loss : 2%
                </Typography>

                <Typography sx={{ color: `${colors.grey[900]}` }} variant="h5">
                  Stopped Out : 10%
                </Typography>
              </Box>
            </Box>
          </Box>
        </Card>
      </Box>

      {/* 2 card */}
      <Box className="containerCard" marginTop={2}>
        <Card
          className="containerRightCard"
          sx={{
            backgroundColor: `${colors.primary[400]}`,
          }}
        >
          <Box
            display="flex"
            flexDirection="column"
            sx={{ padding: "20px 30px 20px 30px" }}
          >
            <Box marginTop={2} alignSelf={"left"}>
              {/* Perform mapping in Buttons */}

              <Button
                className="me-3"
                sx={{
                  background: "#4E33FF",
                  color: `${colors.grey[900]}`,
                  minHeight: "22px",
                  fontSize: "10px",
                  borderRadius: "24px !important",
                  fontWeight: "400",
                  textAlign: "center",
                  minWidth: "max-content",
                  padding: "4px 9px 4px 9px",
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
              >
                #bullish
              </Button>
              <Button
                className="me-3"
                sx={{
                  background: "#4E33FF",
                  color: `${colors.grey[900]}`,
                  minHeight: "22px",
                  fontSize: "10px",
                  borderRadius: "24px !important",
                  fontWeight: "400",
                  textAlign: "center",
                  minWidth: "max-content",
                  padding: "4px 9px 4px 9px",
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
              >
                #bearish
              </Button>
              <Button
                sx={{
                  background: "#4E33FF",
                  color: `${colors.grey[900]}`,
                  minHeight: "22px",
                  fontSize: "10px",
                  borderRadius: "24px !important",
                  fontWeight: "400",
                  textAlign: "center",
                  minWidth: "max-content",
                  padding: "4px 9px 4px 9px",
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
              >
                #options
              </Button>
            </Box>

            <Box alignSelf={"left"} marginTop={2}>
              <Typography
                variant="h3"
                sx={{ color: `${colors.grey[900]}`, fontWeight: 700 }}
              >
                The <span className="typograpy_span">best Way</span> to <br />{" "}
                execute
              </Typography>

              <Typography variant="h5">
                The lowest price of IBM fund in this idea <br /> USD 499.99
              </Typography>
            </Box>
          </Box>

          {/* Buttons */}

          <Box
            display="flex"
            flexDirection="row"
            alignSelf="left"
            marginLeft={3}
          >
            <FormControl>
              <Button
                sx={{
                  background: `${colors.greenAccent[500]}`,
                  margin: "12px 0 12px 0",
                  height: "40px",
                  borderRadius: "24px !important",
                  fontWeight: "700",
                  padding: "20px 60px",
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
              >
                View Investment Channels
              </Button>
            </FormControl>
          </Box>
        </Card>
      </Box>
      {/* 3 card */}
      <Box className="containerCard" marginTop={2}>
        <Card
          className="containerRightCard"
          sx={{
            backgroundColor: `${colors.primary[400]}`,
          }}
        >
          <Box display="flex" justifyContent="space-between">
            <Box>
              <Typography
                variant="h2"
                sx={{ color: `${colors.redAccent[900]}` }}
              >
                <span className="text-light">Potential</span> risk
              </Typography>
            </Box>
            <ReportOutlinedIcon
              fontSize="large"
              sx={{ color: `${colors.redAccent[900]}` }}
            />
          </Box>
          <Box marginTop={1}>
            <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
              The Percentage of risk associated with this funds is 5/2.
            </Typography>
          </Box>

          <Box marginTop={1}>
            <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
              Risk Meter
            </Typography>

            <Box marginTop={3} sx={{ width: 370 }}>
              <Slider
                sx={{ color: `${colors.greenAccent[500]}` }}
                aria-label="Temperature"
                defaultValue={30}
                getAriaValueText={valuetext}
                valueLabelDisplay="auto"
                step={10}
                marks
                min={10}
                max={110}
              />
            </Box>
          </Box>
        </Card>
      </Box>

      {/* 4 card */}

      <Box className="containerCard" marginTop={2}>
        <FormControl>
          <Button
            sx={{
              background: `${colors.greenAccent[500]}`,
              margin: "12px 0 12px 0",
              height: "40px",
              borderRadius: "24px !important",
              fontWeight: "700",
              padding: "20px 60px",
              "&.MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",
                backgroundColor: `${colors.greenAccent[600]} !important`,
              },
            }}
          >
            Show Other Ways of Execute
          </Button>
        </FormControl>
      </Box>
    </Box>
  );
}

export default RightGrid;
