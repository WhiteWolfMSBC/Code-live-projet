import { Box, Button, IconButton, Typography, useTheme } from "@mui/material";
import React, { useState } from "react";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import "./Tabs.css";
import { tokens } from "../../theme";
import CreateTemplate from "./CreateTemplate";

function MyTheams() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [createTemplate, setCreateTemplate] = useState(false);

  return (
    <div>
      {!createTemplate && (
        <>
          <Box display="flex" justifyContent={"space-between"}>
            <Box display={"flex"}>
              <Typography
                variant="h4"
                color={colors.greenAccent[500]}
                className="Typography"
              >
                My Themes
              </Typography>
            </Box>

            <Box display={"flex"}>
              <IconButton size="large" color="inherit">
                <KeyboardArrowLeftIcon />
              </IconButton>

              <IconButton size="large" color="inherit">
                <KeyboardArrowRightIcon />
              </IconButton>

              <IconButton size="large" color="inherit">
                <CloseIcon />
              </IconButton>
            </Box>
          </Box>
          <Box
            display={"flex"}
            flexDirection={"column"}
            margin={"auto"}
            marginTop={29}
          >
            <Box alignSelf={"center"}>
              <Typography
                variant="h6"
                color={colors.grey[900]}
                className="Typographytxt"
                align="center"
              >
                There is no theme you created before please use the button to
                create a theme.
              </Typography>
            </Box>

            <Box alignSelf={"center"} marginTop={2}>
              <Button
                className="CreateIdea_btn"
                sx={{
                  color: `${colors.grey[800]}`,
                  backgroundColor: `${colors.greenAccent[500]}`,
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",
                    backgroundColor: `${colors.greenAccent[600]} !important`,
                  },
                }}
                variant="contained"
                color="success"
                onClick={() => {
                  setCreateTemplate(true);
                }}
              >
                <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
                  Create Template
                </Typography>
              </Button>
            </Box>
          </Box>
        </>
      )}
      {createTemplate && <CreateTemplate />}
    </div>
  );
}
export default MyTheams;
