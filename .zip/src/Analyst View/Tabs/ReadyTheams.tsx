import { Box, Card, IconButton, Typography, useTheme } from "@mui/material";
import React from "react";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import "./Tabs.css";
import { tokens } from "../../theme";

function ReadyTheams() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <div>
      <Box display="flex" justifyContent={"space-between"}>
        <Box display={"flex"}>
          <Typography
            variant="h4"
            color={colors.greenAccent[500]}
            className="Typography"
          >
            Ready Themes
          </Typography>
        </Box>

        <Box display={"flex"}>
          <IconButton size="large" color="inherit">
            <KeyboardArrowLeftIcon />
          </IconButton>

          <IconButton size="large" color="inherit">
            <KeyboardArrowRightIcon />
          </IconButton>

          <IconButton size="large" color="inherit">
            <CloseIcon />
          </IconButton>
        </Box>
      </Box>

      <Box marginBottom={2}>
        <Typography
          variant="h6"
          color={colors.grey[900]}
          className="Typographytxt"
        >
          Select a starting point for your templete.
        </Typography>
      </Box>

      {/* Theme Template */}

      <Box justifyContent={"center"} marginTop={2}>
        {/* 1 Card */}

        <Box className="row">
          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/8797307/pexels-photo-8797307.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginTop={1}
                marginBottom={1}
              >
                Lorem ipsum dolor
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/10528234/pexels-photo-10528234.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />
            </Card>
          </Box>

          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/2113566/pexels-photo-2113566.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint
                odit nulla numquam repudiandae nostrum.
              </Typography>
            </Card>
          </Box>

          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/2686558/pexels-photo-2686558.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint
                odit nulla numquam repudiandae nostrum.
              </Typography>
            </Card>
          </Box>

          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/2649403/pexels-photo-2649403.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginTop={1}
                marginBottom={1}
              >
                Lorem ipsum dolor
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/2258536/pexels-photo-2258536.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />
            </Card>
          </Box>
        </Box>

        {/* 2 Card */}

        <Box className="row" marginTop={1}>
          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/3293148/pexels-photo-3293148.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginTop={1}
                marginBottom={1}
              >
                Lorem ipsum dolor
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/3933881/pexels-photo-3933881.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />
            </Card>
          </Box>

          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/1142950/pexels-photo-1142950.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint
                odit nulla numquam repudiandae nostrum.
              </Typography>
            </Card>
          </Box>

          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/10399171/pexels-photo-10399171.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint
                odit nulla numquam repudiandae nostrum.
              </Typography>
            </Card>
          </Box>

          <Box className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
            <Card
              className="card"
              sx={{
                padding: "12px 16px 12px 16px",
                display: "flex",
                flexDirection: "column",
                maxWidth: 350,
                minHeight: 250,
                backgroundColor: `${colors.primary[400]}`,
                cursor: "pointer",
              }}
            >
              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginBottom={1}
              >
                Bloomberg Report.
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/2922672/pexels-photo-2922672.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />

              <Typography
                variant="h5"
                color={colors.grey[900]}
                alignSelf="center"
                marginTop={1}
                marginBottom={1}
              >
                Lorem ipsum dolor
              </Typography>

              <img
                src={
                  "https://images.pexels.com/photos/7267852/pexels-photo-7267852.jpeg?auto=compress&cs=tinysrgb&w=1600"
                }
                height="70px"
                alt={""}
                loading="lazy"
              />
            </Card>
          </Box>
        </Box>
      </Box>
    </div>
  );
}

export default ReadyTheams;
