import { Box, Card, IconButton, Typography, useTheme } from "@mui/material";
import React, { useState } from "react";
import "./Tabs.css";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import { tokens } from "../../theme";
import PhotoIcon from "@mui/icons-material/Photo";
import TextFieldsIcon from "@mui/icons-material/TextFields";
import FormatAlignLeftIcon from "@mui/icons-material/FormatAlignLeft";
import AnalyticsIcon from "@mui/icons-material/Analytics";
import LinkIcon from "@mui/icons-material/Link";
import AutoFixHighIcon from "@mui/icons-material/AutoFixHigh";
import AttachmentIcon from "@mui/icons-material/Attachment";
import PlayCircleFilledIcon from "@mui/icons-material/PlayCircleFilled";
import ImageUpload from "../Items/ImageUpload";
import Text from "../Items/Text";
import TextBox from "../Items/TextBox";
import ChartUpload from "../Items/ChartUpload";
import MediaLink from "../Items/MediaLink";
import BestWayToTrade from "../Items/BestWayToTrade";
import Tags from "../Items/Tags";
import VideoUpload from "../Items/VideoUpload";
import { useAppDispatch } from "../../store/store";
import { set_Editor } from "../../store/Reducers/IdeaSlice";

function CreateTemplate() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [imageUpload, setImageUpload] = useState(false);
  const [textE, setTextE] = useState(false);
  const [textBox, setTextBox] = useState(false);
  const [chartUpload, setChartUpload] = useState(false);
  const [mediaLink, setMediaLink] = useState(false);
  const [bestWaytoTrade, setBestWaytoTrade] = useState(false);
  const [tags, setTags] = useState(false);
  const [videoUpload, setVideoUpload] = useState(false);
  const dispatch = useAppDispatch();

  const [isDragging, setIsDragging] = useState(false);

  function crossIcon() {
    setImageUpload(false);
    setTextE(false);
    setTextBox(false);
    setChartUpload(false);
    setMediaLink(false);
    setBestWaytoTrade(false);
    setTags(false);
    setVideoUpload(false);
  }

  // Baki Hai

  function RightIcon(): void {
    setImageUpload(false);
    setTextE(false);
    setTextBox(false);
    setChartUpload(false);
    setMediaLink(false);
    setBestWaytoTrade(false);
    setTags(false);
    setVideoUpload(false);
  }

  function LeftIcon(): void {
    setImageUpload(false);
    setTextE(false);
    setTextBox(false);
    setChartUpload(false);
    setMediaLink(false);
    setBestWaytoTrade(false);
    setTags(false);
    setVideoUpload(false);
  }
  const handelDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    setIsDragging(true);
    console.log("drag started");
    const data = JSON.stringify({ type: "Object Drag Successfully" });
    e.dataTransfer.setData("text/plain", data);
    console.log("e", e);
  };

  function handleDragEnd(e: React.DragEvent<HTMLDivElement>) {
    setIsDragging(false);
    e.dataTransfer.clearData();
  }

  return (
    <div>
      <Box display="flex" justifyContent={"space-between"}>
        <Box display={"flex"}>
          <Typography
            variant="h4"
            color={colors.greenAccent[500]}
            className="Typography"
          >
            Create Your Template
          </Typography>
        </Box>

        <Box display={"flex"}>
          <IconButton size="large" color="inherit">
            <KeyboardArrowLeftIcon onClick={() => LeftIcon()} />
          </IconButton>

          <IconButton size="large" color="inherit">
            <KeyboardArrowRightIcon onClick={() => RightIcon()} />
          </IconButton>

          <IconButton size="large" color="inherit">
            <CloseIcon onClick={() => crossIcon()} />
          </IconButton>
        </Box>
      </Box>

      <Box marginBottom={5}>
        <Typography
          variant="h6"
          color={colors.grey[900]}
          className="Typographytxt"
        >
          Drag any of blocks below into the idea preview on the right. You can
          create your own thesis step by step. You can use up 10 text boxes and
          graphics. Make sure your content is short and sharp.
        </Typography>
      </Box>

      {!imageUpload &&
        !textE &&
        !textBox &&
        !chartUpload &&
        !mediaLink &&
        !bestWaytoTrade &&
        !tags &&
        !videoUpload && (
          <Box justifyContent={"center"} marginTop={5}>
            <div className="row">
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    setImageUpload(true);
                    dispatch(set_Editor({ type: "imageUpload" }));
                  }}
                >
                  <Typography
                    variant="h2"
                    color={colors.greenAccent[500]}
                    align="right"
                  >
                    *
                  </Typography>

                  <PhotoIcon
                    sx={{
                      height: "80px",
                      width: "80px",
                      alignSelf: "center",
                    }}
                  />
                  <Typography
                    variant="h5"
                    color={colors.grey[900]}
                    alignSelf="center"
                  >
                    Image Upload
                  </Typography>
                </Card>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12 text-center">
                <Card
                  // draggable="true"
                  draggable
                  onDragStart={(e) => handelDragStart(e)}
                  onDragEnd={(e) => handleDragEnd(e)}
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    // backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                    backgroundColor: isDragging ? "#fbb" : "palegoldenrod",
                  }}
                  onClick={() => {
                    setTextE(true);
                    dispatch(set_Editor({ type: "text" }));
                  }}
                >
                  <Typography
                    variant="h2"
                    color={colors.greenAccent[500]}
                    align="right"
                  >
                    *
                  </Typography>
                  <TextFieldsIcon
                    sx={{ height: "80px", width: "80px", alignSelf: "center" }}
                  />
                  <Typography
                    variant="h5"
                    color={colors.grey[900]}
                    alignSelf="center"
                  >
                    Text
                  </Typography>
                </Card>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12 text-center">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    setTextBox(true);
                    dispatch(set_Editor({ type: "textBox" }));
                  }}
                >
                  <Typography
                    variant="h2"
                    color={colors.greenAccent[500]}
                    align="right"
                  >
                    *
                  </Typography>
                  <FormatAlignLeftIcon
                    sx={{ height: "80px", width: "80px", alignSelf: "center" }}
                  />
                  <Typography
                    variant="h5"
                    color={colors.grey[900]}
                    alignSelf="center"
                  >
                    TextBox
                  </Typography>
                </Card>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12 text-center">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    setChartUpload(true);
                    dispatch(set_Editor({ type: "chartUpload" }));
                  }}
                >
                  <Typography
                    variant="h2"
                    color={colors.greenAccent[500]}
                    align="right"
                  >
                    *
                  </Typography>
                  <AnalyticsIcon
                    sx={{ height: "80px", width: "80px", alignSelf: "center" }}
                  />
                  <Typography
                    variant="h5"
                    color={colors.grey[900]}
                    alignSelf="center"
                  >
                    Chart Upload
                  </Typography>
                </Card>
              </div>
            </div>

            {/* 2 box */}

            <div className="row mt-5">
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12 text-center">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                  onClick={() => {
                    setMediaLink(true);
                    dispatch(set_Editor({ type: "mediaLink" }));
                  }}
                >
                  <Box alignSelf={"center"} margin="auto">
                    <LinkIcon
                      sx={{
                        height: "80px",
                        width: "80px",
                        alignSelf: "center",
                      }}
                    />
                    <Typography
                      variant="h5"
                      color={colors.grey[900]}
                      alignSelf="center"
                    >
                      Media Link
                    </Typography>
                  </Box>
                </Card>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12 text-center">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    setBestWaytoTrade(true);
                    dispatch(set_Editor({ type: "wayToTrade" }));
                  }}
                >
                  <Typography
                    variant="h2"
                    color={colors.greenAccent[500]}
                    align="right"
                  >
                    *
                  </Typography>
                  <AutoFixHighIcon
                    sx={{ height: "80px", width: "80px", alignSelf: "center" }}
                  />
                  <Typography
                    variant="h5"
                    color={colors.grey[900]}
                    alignSelf="center"
                  >
                    BestWay to Tarde
                  </Typography>
                </Card>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12 text-center">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    setTags(true);
                    dispatch(set_Editor({ type: "tag" }));
                  }}
                >
                  <Typography
                    variant="h2"
                    color={colors.greenAccent[500]}
                    align="right"
                  >
                    *
                  </Typography>
                  <AttachmentIcon
                    sx={{ height: "80px", width: "80px", alignSelf: "center" }}
                  />
                  <Typography
                    variant="h5"
                    color={colors.grey[900]}
                    alignSelf="center"
                  >
                    Tags
                  </Typography>
                </Card>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-sm-12 text-center">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    setVideoUpload(true);
                    dispatch(set_Editor({ type: "videoUpload" }));
                  }}
                >
                  <Box alignSelf={"center"} margin="auto">
                    <PlayCircleFilledIcon
                      sx={{
                        height: "80px",
                        width: "80px",
                        alignSelf: "center",
                      }}
                    />
                    <Typography
                      variant="h5"
                      color={colors.grey[900]}
                      alignSelf="center"
                    >
                      Video Upload
                    </Typography>
                  </Box>
                </Card>
              </div>
            </div>
          </Box>
        )}
      {imageUpload && <ImageUpload />}
      {textE && <Text />}
      {textBox && <TextBox />}
      {chartUpload && <ChartUpload />}
      {mediaLink && <MediaLink />}
      {bestWaytoTrade && <BestWayToTrade />}
      {tags && <Tags />}
      {videoUpload && <VideoUpload />}
    </div>
  );
}

export default CreateTemplate;
