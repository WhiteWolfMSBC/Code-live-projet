import { Box, Typography, useTheme } from "@mui/material";
import React from "react";
import { Helmet } from "react-helmet";
import TopBar from "../../components/global/TopBar";
import { tokens } from "../../theme";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import ThematicBasketTable from "./ThematicBasketTable";
import "./Thematicbasket.css";

export default function ThematicBaskets() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ThematicBaskets</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Typography
            variant="h4"
            marginLeft={4}
            marginTop={1.5}
            color={colors.greenAccent[500]}
            className="Typography"
          >
            ThematicBaskets
          </Typography>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>
      </Box>

      <Box className="Ideagemarator_ThematicBasket ">
        <Box display={"flex"}>
          <Box alignSelf={"left"} marginLeft={4}>
            <Box className="input-group mb-3">
              <Box className="input-group flex-nowrap">
                <input
                  type="text"
                  className="form-control SerchInput"
                  placeholder="Serch in Ticker ...."
                  aria-label="Username"
                  aria-describedby="addon-wrapping"
                />
                <span className="input-group-text" id="addon-wrapping">
                  <SearchRoundedIcon />
                </span>
              </Box>
            </Box>
          </Box>
        </Box>

        {/* Table */}

        <Box marginLeft={4} marginTop={1.5}>
          <ThematicBasketTable />
        </Box>
      </Box>
    </>
  );
}
