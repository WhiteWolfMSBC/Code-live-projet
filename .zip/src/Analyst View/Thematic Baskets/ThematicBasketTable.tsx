import React from 'react'

function ThematicBasketTable() {
  return (
    <div>
      yhnb 
    </div>
  )
}

export default ThematicBasketTable