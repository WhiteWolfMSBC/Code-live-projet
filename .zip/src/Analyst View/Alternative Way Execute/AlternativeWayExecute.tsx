import { Typography, useTheme } from "@mui/material";
import React from "react";
import { tokens } from "../../theme";
import Box from "@mui/material/Box";
import "./AlternativeWayExecute.css";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import AlternativeWayTable from "./AlternativeWayTable";

export default function AlternativeWayExecute() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | AlternativeWayExecute</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Typography
            variant="h4"
            marginLeft={4}
            marginTop={1.5}
            color={colors.greenAccent[500]}
            className="Typography"
          >
            Alternative Way Execute
          </Typography>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>
      </Box>

      {/* AlternativeWayExecute */}

      <Box display={"flex"}>
        <Box alignSelf={"left"} marginLeft={4}>
          <Box className="input-group mb-3">
            <Box className="input-group flex-nowrap">
              <input
                type="text"
                className="form-control SerchInput"
                placeholder="Serch in Ticker ...."
                aria-label="Username"
                aria-describedby="addon-wrapping"
              />
              <span className="input-group-text" id="addon-wrapping">
                <SearchRoundedIcon />
              </span>
            </Box>
          </Box>
        </Box>
      </Box>

      {/* Table */}

      <Box marginLeft={4} marginTop={1.5}>
        <AlternativeWayTable />
      </Box>
    </>
  );
}
