import React, { useEffect, useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import {
  Box,
  IconButton,
  TableSortLabel,
  Typography,
  useTheme,
} from "@mui/material";
import "../../Admin/UserList/UserTable.css";
import { tokens } from "../../theme";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import { styled } from "@mui/system";
import TablePaginationUnstyled, {
  tablePaginationUnstyledClasses as classes,
} from "@mui/base/TablePaginationUnstyled";
import axios from "axios";
import { makeStyles } from "@material-ui/core/styles";

type resultProps = {
  ticker: any;
  action: any;
  stopLoss: any;
  takeProfit: any;
  entryDate: any;
  exitDate: any;
  risk: any;
  returnPotential: any;
};

const blue = {
  200: "#A5D8FF",
  400: "#3399FF",
};

const grey = {
  50: "#f6f8fa",
  100: "#eaeef2",
  200: "#d0d7de",
  300: "#afb8c1",
  400: "#8c959f",
  500: "#6e7781",
  600: "#57606a",
  700: "#424a53",
  800: "#32383f",
  900: "#24292f",
};

const CustomTablePagination = styled(TablePaginationUnstyled)(
  ({ theme }) => `
  & .${classes.spacer} {
    display: none;
  }

  & .${classes.toolbar}  {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;

    @media (min-width: 768px) {
      flex-direction: row;
      align-items: center;
    }
  }

  & .${classes.selectLabel} {
    margin: 0;
  }

  & .${classes.select}{
    padding: 2px;
    border: 1px solid ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
    border-radius: 50px;
    background-color: transparent;
    color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};

    &:hover {
      background-color: ${theme.palette.mode === "dark" ? grey[800] : grey[50]};
    }

    &:focus {
      outline: 1px solid ${
        theme.palette.mode === "dark" ? blue[400] : blue[200]
      };
    }
  }

  & .${classes.displayedRows} {
    margin: 0;

    @media (min-width: 768px) {
      margin-left: auto;
    }
  }

  & .${classes.actions} {
    padding: 2px;
    border: 1px solid ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
    border-radius: 50px;
    text-align: center;
  }

  & .${classes.actions} > button {
    margin: 0 8px;
    border: transparent;
    border-radius: 2px;
    background-color: transparent;
    color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};

    &:hover {
      background-color: ${theme.palette.mode === "dark" ? grey[800] : grey[50]};
    }

    &:focus {
      outline: 1px solid ${
        theme.palette.mode === "dark" ? blue[400] : blue[200]
      };
    }
  }
  `
);

const useStyles: any = makeStyles((theme: any) => ({
  root: {
    width: "100%",
  },
  paper: {
    width: "100%",
    marginBottom: theme.spacing(2),
  },
  table: {
    minWidth: 750,
  },
  visuallyHidden: {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: 1,
    margin: -1,
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    top: 20,
    width: 1,
  },
}));

function descendingComparator(
  a: { [x: string]: number },
  b: { [x: string]: number },
  orderBy: string | number
) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order: string, orderBy: string) {
  return order === "desc"
    ? (a: any, b: any) => descendingComparator(a, b, orderBy)
    : (a: any, b: any) => -descendingComparator(a, b, orderBy);
}

function stableSort(
  array: any[],
  comparator: { (a: any, b: any): number; (arg0: any, arg1: any): any }
) {
  const stabilizedThis = array.map((el: any, index: any) => [el, index]);
  stabilizedThis.sort((a: number[], b: number[]) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map((el: any[]) => el[0]);
}

//  Table heading

const headCells = [
  {
    id: "ticker",
    numeric: true,
    disablePadding: false,
    label: "Ticker",
  },
  { id: "action", numeric: true, disablePadding: false, label: "Action" },
  { id: "size", numeric: true, disablePadding: false, label: "Size" },
  {
    id: "stopLoss",
    numeric: true,
    disablePadding: false,
    label: "StopLoss",
  },
  {
    id: "takeProfit",
    numeric: true,
    disablePadding: false,
    label: "TakeProfit",
  },
  {
    id: "entryDate",
    numeric: true,
    disablePadding: false,
    label: "EntryDate",
  },
  {
    id: "exitDate",
    numeric: true,
    disablePadding: false,
    label: "ExitDate",
  },
  {
    id: "risk",
    numeric: true,
    disablePadding: false,
    label: "Risk",
  },
  {
    id: "returnPotential",
    numeric: true,
    disablePadding: false,
    label: "ReturnPotential",
  },
];

function EnhancedTableHead(props: {
  classes: any;
  order: any;
  orderBy: any;
  onRequestSort: any;
  rowCount: any;
}) {
  const { classes, order, orderBy, onRequestSort } = props;
  const createSortHandler = (property: string) => (event: any) => {
    onRequestSort(event, property);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            className="rowtableCell"
            align="left"
            key={headCell.id}
            sortDirection={orderBy === headCell.id ? order : false}
            sx={{ backgroundColor: `${colors.primary[200]}` }}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <span className={classes.visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </span>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

export default function AlternativeWayTable() {
  const classes = useStyles();
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [pg, setpg] = React.useState(0);
  const [rpg, setrpg] = React.useState(20);

  // User Api data Call

  const [user, setUser] = useState<resultProps[]>([]);
  console.log(user);

  const fetchData = async () => {
    try {
      const item = await axios.get("https://dummyjson.com/products");
      console.log(item);
      setUser(item.data.products);
      console.log(item.data.products);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleChangePage = (
    event: any,
    newpage: React.SetStateAction<number>
  ) => {
    setpg(newpage);
  };

  const handleChangeRowsPerPage = (event: { target: { value: string } }) => {
    setrpg(parseInt(event.target.value, 10));
    setpg(0);
  };

  const handleRequestSort = (
    event: any,
    property: React.SetStateAction<string>
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | AlternativeWayExecute</title>
      </Helmet>
      <Box
        marginLeft={4}
        marginRight={2}
        display={"flex"}
        flexDirection="column"
      >
        <TableContainer>
          <Table stickyHeader={true} aria-label="User List Table">
            <EnhancedTableHead
              classes={classes}
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
              rowCount={user.length}
            />
            <TableBody>
              {stableSort(
                user.slice(pg * rpg, pg * rpg + rpg),
                getComparator(order, orderBy)
              ).map(
                (row: {
                  title: any;
                  description: any;
                  price: any;
                  discountPercentage: any;
                  rating: any;
                  stock: any;
                  brand: any;
                  category: any;
                  id: any;
                }) => {
                  return (
                    <TableRow hover>
                      <TableCell className="TableBody" align="left">
                        {row.title}
                      </TableCell>
                      <TableCell
                        sx={{ color: `${colors.greenAccent[500]}` }}
                        className="TableBody"
                        align="left"
                      >
                        {row.description}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.price}
                      </TableCell>
                      <TableCell
                        sx={{ color: `${colors.redAccent[900]}` }}
                        className="TableBody"
                        align="left"
                      >
                        {row.discountPercentage}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.rating}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.stock}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.brand}
                      </TableCell>
                      <TableCell
                        sx={{ color: `${colors.redAccent[800]}` }}
                        className="TableBody"
                        align="left"
                      >
                        {row.category}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.id}
                      </TableCell>
                    </TableRow>
                  );
                }
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Box alignSelf={"end"}>
          <CustomTablePagination
            rowsPerPageOptions={[10, 20, 30, { label: "All", value: -1 }]}
            colSpan={3}
            count={user.length}
            rowsPerPage={rpg}
            page={pg}
            slotProps={{
              select: {
                "aria-label": "UserList Pagination",
              },
              actions: {
                showFirstButton: true,
                showLastButton: true,
              } as any,
            }}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Box>
      </Box>
    </>
  );
}
