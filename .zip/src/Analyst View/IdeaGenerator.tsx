import React, { useState } from "react";
import "./IdeaGenerator.css";
import Box from "@mui/material/Box";
import {
  Button,
  TableContainer,
  Typography,
  useTheme,
} from "@mui/material";
import { tokens } from "../theme";
import TopBar from "../components/global/TopBar";
import { Helmet } from "react-helmet";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import Tab from "@mui/material/Tab";
import CreateTemplate from "./Tabs/CreateTemplate";
import MyTheams from "./Tabs/MyTheams";
import ReadyTheams from "./Tabs/ReadyTheams";
import PlusSvgIcon from "../Util/SvgIcon";
import ImageUpload1 from "./RightSideTabs/ImageUpload1";
import Text1 from "./RightSideTabs/Text1";
import TextBox1 from "./RightSideTabs/TextBox1";
import ChartUpload1 from "./RightSideTabs/ChartUpload1";
import BestWayToTrade1 from "./RightSideTabs/BestWayToTrade1";
import Tags1 from "./RightSideTabs/Tags1";
import VideoUpload1 from "./RightSideTabs/VideoUpload1";
import MediaLink1 from "./RightSideTabs/MediaLink1";
import { useAppSelector } from "../store/store";
import {
  chartUpload,
  imageUpload,
  mediaLink,
  text,
  textBox,
  videoUpload,
  wayToTrade,
  tag,
} from "../store/Reducers/IdeaSlice";

function IdeaGenerator() {
  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  // right
  const imageUploadFlag = useAppSelector(imageUpload);
  const mediaLinkFlag = useAppSelector(mediaLink);
  const chartUploadFlag = useAppSelector(chartUpload);
  const wayToTradeFlag = useAppSelector(wayToTrade);
  const videoUploadFlag = useAppSelector(videoUpload);
  const textFlag = useAppSelector(text);
  const textBoxFlag = useAppSelector(textBox);
  const tagFlag = useAppSelector(tag);

  const [isOver, setIsOver] = useState(false);

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    const dataJSON = e.dataTransfer.getData("text/plain");
    console.log(dataJSON);
  };

  function handleDragLeave() {
    setIsOver(false);
  }

  function handleDragOver(e: React.DragEvent<HTMLDivElement>) {
    if (e.dataTransfer.types[0] === "text/plain") {
      setIsOver(true);
      e.preventDefault();
    }
  }

  function crossIcon() {
    console.log("hii");
  }

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Analyst | Idea Generator</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Box display={"flex"}>
            <Typography
              variant="h4"
              marginLeft={4}
              marginTop={1.5}
              color={colors.greenAccent[500]}
              className="Typography"
            >
              Idea Generator
            </Typography>
          </Box>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>
      </Box>

      {/* Create Idea */}

      <Box marginLeft={4} marginRight={2}>
        <Box
          className="CreateIdea-Box"
          sx={{ backgroundColor: `${colors.primary[400]}` }}
          display="flex"
          justifyContent={"space-between"}
        >
          <Box display={"flex"}>
            <Typography
              variant="h3"
              className="CreateIdea_txt"
              sx={{
                color: `${colors.grey[900]}`,
              }}
            >
              Create an Idea for "One Idea Per Day"
            </Typography>
          </Box>

          <Box display={"flex"}>
            <Button
              className="CreateIdea_btn"
              sx={{
                color: `${colors.grey[900]}`,
              }}
              variant="outlined"
              color="success"
            >
              <RemoveRedEyeIcon
                fontSize="small"
                className="me-3"
                sx={{ color: `${colors.grey[900]}` }}
              />
              Preview
            </Button>

            <Button
              className="CreateIdea_btn"
              sx={{
                color: `${colors.grey[800]}`,
                backgroundColor: `${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
              variant="contained"
              color="success"
            >
              Create Template
            </Button>
          </Box>
        </Box>

        {/* Tabs (Body) */}

        <Box className="CreateIdea-Box1" marginTop={5}>
          <div className="row">
            <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <Box>
                <TabContext value={value}>
                  <Box display="flex" justifyContent={"space-between"}>
                    <TabList
                      onChange={handleChange}
                      className="tablist"
                      sx={{}}
                    >
                      <Tab
                        id="applicationTabletabs"
                        sx={{
                          color: `${colors.grey[900]}`,
                          backgroundColor: `${colors.primary[400]}`,
                        }}
                        className="applicationtab me-3"
                        label="Create Template"
                        value="1"
                      />
                      <Tab
                        sx={{
                          color: `${colors.grey[900]}`,
                          backgroundColor: `${colors.primary[400]}`,
                        }}
                        className="applicationtab me-3"
                        label="Ready Theams"
                        value="2"
                      />
                      <Tab
                        sx={{
                          color: `${colors.grey[900]}`,
                          backgroundColor: `${colors.primary[400]}`,
                        }}
                        className="applicationtab me-3"
                        label="My Theams"
                        value="3"
                      />
                    </TabList>
                  </Box>

                  <TableContainer
                    className="tableContainer"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                  >
                    <TabPanel value="1">
                      <CreateTemplate />
                    </TabPanel>
                    <TabPanel value="2">
                      <ReadyTheams />
                    </TabPanel>
                    <TabPanel value="3">
                      <MyTheams />
                    </TabPanel>
                  </TableContainer>
                </TabContext>
              </Box>
            </div>

            <div className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <Box
                className="Body_DargObjectBox"
                display={"flex"}
                flexDirection={"column"}
                sx={{
                  maxHeight: "400px",
                  backgroundColor: `${colors.primary[400]}`,
                  padding: "12px 16px 12px 16px",
                }}
              >
                {!imageUploadFlag &&
                  !textFlag &&
                  !textBoxFlag &&
                  !chartUploadFlag &&
                  !mediaLinkFlag &&
                  !wayToTradeFlag &&
                  !tagFlag &&
                  !videoUploadFlag && (
                    <>
                      <Box
                        onDrop={handleDrop}
                        onDragOver={(e) => handleDragOver(e)}
                        onDragLeave={handleDragLeave}
                        alignSelf={"center"}
                        margin="auto"
                        sx={{
                          backgroundColor: isOver ? "#bbf" : "rgba(0,0,0,.12)",
                        }}
                      >
                        <Box alignSelf={"center"}>
                          <PlusSvgIcon />

                          <Typography
                            variant="h5"
                            color={colors.grey[900]}
                            align="center"
                          >
                            Drag Objects to Create
                          </Typography>
                        </Box>
                      </Box>
                    </>
                  )}
                {imageUploadFlag && <ImageUpload1 />}
                {textFlag && <Text1 />}
                {textBoxFlag && <TextBox1 />}
                {chartUploadFlag && <ChartUpload1 />}
                {mediaLinkFlag && <MediaLink1 />}
                {wayToTradeFlag && <BestWayToTrade1 />}
                {tagFlag && <Tags1 />}
                {videoUploadFlag && <VideoUpload1 />}
              </Box>
            </div>
          </div>
        </Box>
      </Box>
    </>
  );
}

export default IdeaGenerator;
