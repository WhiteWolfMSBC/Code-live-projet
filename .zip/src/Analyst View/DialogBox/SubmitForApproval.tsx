import {
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Typography,
} from "@mui/material";
import React from "react";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";
import TaskAltIcon from "@mui/icons-material/TaskAlt";
import "./Dialog.css";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";

function SubmitForApproval() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [btnopen, setBtnopen] = React.useState(false);

  const handelBtnSaveOpen = () => {
    setBtnopen(true);
  };

  const handelBtnSaveClose = () => {
    setBtnopen(false);
  };
  return (
    <div>
      <Box className="text-center mt-3">
        <Button
          sx={{
            color: `${colors.grey[900]}`,
          }}
          variant="contained"
          color="success"
          onClick={handelBtnSaveOpen}
          className={"outlineBtn"}
        >
          Save Changes
        </Button>
      </Box>

      {/* Dialog Box */}

      <Dialog
        open={btnopen}
        onClose={handelBtnSaveClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        sx={{ background: "#1717171" }}
      >
        <DialogTitle>
          <Box display="flex" justifyContent="space-between">
            <Box></Box>
            <span onClick={handelBtnSaveClose}>
              <CancelOutlinedIcon sx={{ fontSize: "25px" }} />
            </span>
          </Box>

          <Box display="flex" justifyContent="center">
            <TaskAltIcon
              fontSize="large"
              sx={{ color: `${colors.greenAccent[500]}`, fontSize: "60px" }}
            />
          </Box>

          <Box
            display="flex"
            justifyContent="center"
            flexDirection={"column"}
            margin={2}
          >
            <Box alignSelf={"center"}>
              <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
                Submit for Approval
              </Typography>
            </Box>

            <Box alignSelf={"center"} marginTop={1}>
              <Typography variant="h5" sx={{ color: `${colors.grey[900]}` }}>
                Submit your idea now for approval
              </Typography>
            </Box>
          </Box>
        </DialogTitle>
        <DialogContent>
          <DialogContentText
            display="flex"
            justifyContent="center"
            flexDirection="row"
            id="alert-dialog-description"
          >
            <Button
              className="FilledApprovedBtn"
              sx={{
                color: `${colors.grey[900]}`,
                border: `1px solid ${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
              variant="outlined"
              color="success"
            >
              Edit Theme
            </Button>

            <Button
              className="FilledApprovedBtn ms-3"
              sx={{
                color: `${colors.grey[800]}`,
                backgroundColor: `${colors.greenAccent[500]}`,
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
              variant="contained"
              color="success"
            >
              Submit For Approval
            </Button>
          </DialogContentText>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default SubmitForApproval;
