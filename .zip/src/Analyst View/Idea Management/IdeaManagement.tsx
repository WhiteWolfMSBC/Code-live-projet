import * as React from "react";
import Box from "@mui/material/Box";
import TabContext from "@mui/lab/TabContext";
import {
  IconButton,
  TableContainer,
  Typography,
  useTheme,
} from "@mui/material";
import { tokens } from "../../theme";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import "./IdeaManagement.css";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import Dropdown from "../../Admin/ApplicationManagement/Dropdown";
import IdeaManagementTable from "./IdeaManagementTable";
import { TabPanel } from "@mui/lab";

export default function IdeaManagement() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | IdeaManagement</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"} sx={{ m: "8px" }}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Box display={"flex"}>
            <Typography
              variant="h4"
              marginLeft={4}
              marginTop={1.5}
              color={colors.greenAccent[500]}
              className="Typography"
            >
              Idea Management
            </Typography>

            <IconButton size="large" color="inherit">
              <KeyboardArrowLeftIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <KeyboardArrowRightIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <CloseIcon />
            </IconButton>
          </Box>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>
      </Box>

      {/* Tabs */}

      <Box marginLeft={4} marginRight={2}>
        <TabContext value={""}>
          <Box display="flex" justifyContent={"space-between"}>
            <Box>
              <Dropdown />
            </Box>
          </Box>

          <TableContainer className="tableContainer1">
            <TabPanel value={""}>
              <IdeaManagementTable />
            </TabPanel>
          </TableContainer>
        </TabContext>
      </Box>
    </>
  );
}
