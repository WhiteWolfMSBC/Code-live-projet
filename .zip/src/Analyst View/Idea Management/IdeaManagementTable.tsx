import * as React from "react";
import { useTheme } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { tokens } from "../../theme";
import "./IdeaManagement.css";

function createData(
  IdeaName: string,
  User: string,
  CreationData: string,
  Status: any,
  Note: string,
  Icon: any
) {
  return {
    IdeaName,
    User,
    CreationData,
    Status,
    Note,
    Icon,
  };
}

// 2 table data

function createData1(
  IdeaName: string,
  User: string,
  CreationData: string,
  Status: any,
  Note: string,
  Icon: any
) {
  return {
    IdeaName,
    User,
    CreationData,
    Status,
    Note,
    Icon,
  };
}

// 3 table data

function createData2(
  IdeaName: string,
  User: string,
  CreationData: string,
  Status: any,
  Note: string,
  Icon: any
) {
  return {
    IdeaName,
    User,
    CreationData,
    Status,
    Note,
    Icon,
  };
}

// 3 table data

function createData3(
  IdeaName: string,
  User: string,
  CreationData: string,
  Status: any,
  Note: string,
  Icon: any
) {
  return {
    IdeaName,
    User,
    CreationData,
    Status,
    Note,
    Icon,
  };
}

export default function IdeaManagement() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const rows = [
    createData(
      "Bloomberg Insight reports",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#171717",
          height: "29px",
          width: "152px",
          backgroundColor: "#00D796",
          fontSize: "10px",
          padding: "6px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
        }}
        variant="contained"
        color="success"
      >
        {/* <DoneIcon  fontSize="small"/> */}
        <span>Approved</span>
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
    createData(
      "Crypto Currency",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#171717",
          border: "1px solid #00D796",
          height: "29px",
          width: "152px",
          backgroundColor: "#00D796",
          fontSize: "10px",
          padding: "6px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
        }}
        variant="contained"
        color="success"
      >
        {/* <DoneIcon  fontSize="small" /> */}
        <span>Approved</span>
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
  ];
  const rows2 = [
    createData2(
      "Bloomberg Insight reports",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#ffffff",
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          backgroundColor: "#4F3CC0",
          fontSize: "10px",
          padding: "6px",
          border: "1px solid #4F3CC0",
        }}
        variant="contained"
      >
        {/* <InfoIcon  fontSize="small"/> */}
        <span>Pending</span>
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
    createData2(
      "Crypto Currency",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#ffffff",
          border: "1px solid #4F3CC0",
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          backgroundColor: "#4F3CC0",
          fontSize: "10px",
          padding: "6px",
        }}
        variant="contained"
      >
        {/* <InfoIcon  fontSize="small"/> */}
        <span>Pending</span>
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
  ];
  const rows3 = [
    createData3(
      "Bloomberg Insight reports",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          fontSize: "10px",
          padding: "6px",
          borderRadius: 10,
          color: "#171717",
          backgroundColor: "#F8C02F",
          border: "1px solid #F8C02F",
        }}
        variant="contained"
        color="warning"
      >
        {/* <AutorenewIcon  fontSize="small"/> */}
        Waiting for Translation
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
    createData3(
      "Crypto Currency",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          fontSize: "10px",
          padding: "6px",
          color: "#171717",
          backgroundColor: "#F8C02F",
          border: "1px solid #F8C02F",
        }}
        variant="contained"
        color="warning"
      >
        {/* <AutorenewIcon  fontSize="small"/> */}
        Waiting for Translation
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
  ];

  const rows1 = [
    createData1(
      "Bloomberg Insight reports",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#ffffff",
          border: "1px solid #FC4746",
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          fontSize: "10px",
          padding: "6px",
        }}
        variant="contained"
        color="error"
      >
        {/* <WarningIcon  fontSize="small"/> */}
        Revised
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
    createData1(
      "Crypto Currency",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#ffffff",
          border: "1px solid #FC4746",
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          fontSize: "10px",
          padding: "6px",
        }}
        variant="contained"
        color="error"
      >
        {/* <WarningIcon  fontSize="small"/> */}
        Revised
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
    createData1(
      "Crypto Currency",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#ffffff",
          border: "1px solid #FC4746",
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          fontSize: "10px",
          padding: "6px",
        }}
        variant="contained"
        color="error"
      >
        {/* <WarningIcon  fontSize="small"/> */}
        Revised
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
    createData1(
      "Crypto Currency",
      "Analyst",
      "08/10/2022",
      <Button
        sx={{
          borderRadius: 10,
          color: "#ffffff",
          border: "1px solid #FC4746",
          height: "29px",
          width: "152px",
          fontWeight: 400,
          alignItems: "center",
          lineHeight: "12px",
          fontSize: "10px",
          padding: "6px",
        }}
        variant="contained"
        color="error"
      >
        {/* <WarningIcon  fontSize="small"/> */}
        Revised
      </Button>,
      "Idea of the Month Loerem dolar sit a met",
      ""
    ),
  ];
  return (
    <>
      <Typography
        sx={{ color: "#00D796", fontWeight: "bold" }}
        marginBottom={2}
        variant="h6"
        component="h2"
      >
        Approved Ideas
      </Typography>
      <TableContainer>
        <Table
          align="center"
          sx={{
            minWidth: 650,
          }}
          aria-label="customized table"
        >
          <TableHead
            sx={{ borderBottom: "1px solid #3C3C3C", borderRadius: "8px" }}
          >
            <TableRow>
              <TableCell
                align="left"
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
              >
                Idea Name
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                User
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Creation Data
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Status
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Note
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                <BorderColorIcon fontSize="small" />
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <TableRow
                key={row.IdeaName}
                sx={{
                  "&:last-child td, &:last-child th": { border: 0 },
                }}
              >
                <TableCell className="col-lg-3" align="left">
                  {row.IdeaName}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row.User}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row.CreationData}
                </TableCell>
                <TableCell className="col-lg-3" align="left">
                  {row.Status}
                </TableCell>
                <TableCell className="col-lg-4" align="left">
                  {row.Note}
                </TableCell>
                <TableCell align="left">{row.Icon}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* 2nd table */}

      <Typography
        marginBottom={2}
        className="mt-5"
        sx={{ color: "#00D796", fontWeight: "bold" }}
        variant="h6"
        component="h2"
      >
        Pending Revised Idea
      </Typography>

      <TableContainer sx={{ borderRadius: "13px" }}>
        <Table
          align="center"
          sx={{
            minWidth: 650,
          }}
          aria-label="simple table"
        >
          <TableHead
            sx={{ borderBottom: "1px solid #3C3C3C", borderRadius: "8px" }}
          >
            <TableRow>
              <TableCell
                align="left"
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
              >
                Idea Name
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                User
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Creation Data
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Status
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Note
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                <BorderColorIcon fontSize="small" />
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows1.map((row1) => (
              <TableRow
                key={row1.IdeaName}
                sx={{
                  "&:last-child td, &:last-child th": { border: 0 },
                }}
              >
                <TableCell className="col-lg-3" align="left">
                  {row1.IdeaName}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row1.User}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row1.CreationData}
                </TableCell>
                <TableCell className="col-lg-3" align="left">
                  {row1.Status}
                </TableCell>
                <TableCell className="col-lg-4" align="left">
                  {row1.Note}
                </TableCell>
                <TableCell align="left">{row1.Icon}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* 3rd table */}

      <Typography
        marginBottom={2}
        className="mt-5"
        sx={{ color: "#00D796", fontWeight: "bold" }}
        variant="h6"
        component="h2"
      >
        Pending Approval Ideas
      </Typography>

      <TableContainer sx={{ borderRadius: "13px" }}>
        <Table
          align="center"
          sx={{
            minWidth: 650,
          }}
          aria-label="simple table"
        >
          <TableHead
            sx={{ borderBottom: "1px solid #3C3C3C", borderRadius: "8px" }}
          >
            <TableRow>
              <TableCell
                align="left"
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
              >
                Idea Name
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                User
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Creation Data
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Status
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Note
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                <BorderColorIcon fontSize="small" />
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows2.map((row2) => (
              <TableRow
                key={row2.IdeaName}
                sx={{
                  "&:last-child td, &:last-child th": { border: 0 },
                }}
              >
                <TableCell className="col-lg-3" align="left">
                  {row2.IdeaName}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row2.User}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row2.CreationData}
                </TableCell>
                <TableCell className="col-lg-3" align="left">
                  {row2.Status}
                </TableCell>
                <TableCell className="col-lg-4" align="left">
                  {row2.Note}
                </TableCell>
                <TableCell align="left">{row2.Icon}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* 4rd table */}

      <Typography
        marginBottom={2}
        className="mt-5"
        sx={{ color: "#00D796", fontWeight: "bold" }}
        variant="h6"
        component="h2"
      >
        Ideas Translated or to br Translate
      </Typography>

      <TableContainer sx={{ borderRadius: "13px" }}>
        <Table
          align="center"
          sx={{
            minWidth: 650,
          }}
          aria-label="simple table"
        >
          <TableHead
            sx={{ borderBottom: "1px solid #3C3C3C", borderRadius: "8px" }}
          >
            <TableRow>
              <TableCell
                align="left"
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
              >
                Idea Name
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                User
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Creation Data
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Status
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                Note
              </TableCell>
              <TableCell
                sx={{
                  "&.MuiTableCell-head": {
                    fontWeight: "700",
                    fontSize: 12,
                  },
                  backgroundColor: `${colors.primary[200]}`,
                }}
                align="left"
              >
                <BorderColorIcon fontSize="small" />
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows3.map((row3) => (
              <TableRow
                key={row3.IdeaName}
                sx={{
                  "&:last-child td, &:last-child th": { border: 0 },
                }}
              >
                <TableCell className="col-lg-3" align="left">
                  {row3.IdeaName}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row3.User}
                </TableCell>
                <TableCell className="col-lg-2" align="left">
                  {row3.CreationData}
                </TableCell>
                <TableCell className="col-lg-3" align="left">
                  {row3.Status}
                </TableCell>
                <TableCell className="col-lg-4" align="left">
                  {row3.Note}
                </TableCell>
                <TableCell align="left">{row3.Icon}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
}
