import React, { useState } from "react";
import "./Items.css";
import { Helmet } from "react-helmet";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function BestWayToTrade() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [link, setLink] = useState("");

  const handleChange = (event: SelectChangeEvent) => {
    setLink(event.target.value as string);
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | BestWayToTrade</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="textEditor_Box">
        <Box display="flex" flexDirection="column">
          <Box
            alignSelf={"center"}
            marginTop={4}
            marginRight={4}
            marginLeft={4}
          >
            {/* 1 textfield */}
            <Typography marginBottom={1}>Subtitle Edit</Typography>

            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <TextField
                required
                id="emailId"
                variant="filled"
                label="The best way to exexute"
                placeholder="&#x2709;"
                type="text"
                size="small"
                sx={{
                  backgroundColor: `${colors.primary[400]}`,
                  borderRadius: "10px",
                  minWidth: "700px",

                  "& .MuiInputBase-root": {
                    fontSize: "18px",
                    color: `${colors.grey[900]}`,
                  },
                  "& .MuiFilledInput-input": {
                    color: `${colors.grey[400]} !important`,
                  },
                }}
              />
            </FormControl>
          </Box>

          <Box
            alignSelf={"center"}
            marginTop={4}
            marginRight={4}
            marginLeft={4}
          >
            {/* 2 & 3 textfield  (Select, textfiled)*/}
            <Box className="row" alignSelf={"center"}>
              <Box
                className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6"
                alignSelf={"center"}
              >
                <Typography marginBottom={1}>Fund Choose</Typography>

                <FormControl
                  variant="filled"
                  size="small"
                  className="field-container"
                >
                  <InputLabel id="mediaLink">Funds name</InputLabel>
                  <Select
                    labelId="mediaLink"
                    required
                    id="mediaLink"
                    size="small"
                    value={link}
                    label="Age"
                    variant="filled"
                    onChange={handleChange}
                    sx={{
                      borderRadius: "10px",
                      minWidth: "345px",
                      height: "50px !important",

                      "& .MuiInputBase-root": {
                        fontSize: "18px",
                        color: `${colors.grey[900]}`,
                      },
                      "& .MuiFilledInput-input": {
                        color: `${colors.grey[400]} !important`,
                      },
                    }}
                  >
                    <MenuItem value={1}>IBM Fund</MenuItem>
                    <MenuItem value={2}>TCS Fund</MenuItem>
                    <MenuItem value={3}>Wipro Fund</MenuItem>
                  </Select>
                </FormControl>
              </Box>

              <Box
                className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6"
                alignSelf={"center"}
              >
                <Typography marginBottom={1}>Trade Price</Typography>

                <FormControl
                  variant="filled"
                  size="small"
                  className="field-container"
                >
                  <TextField
                    required
                    id="emailId"
                    variant="filled"
                    label="Price"
                    placeholder="&#x2709;"
                    type="text"
                    size="small"
                    value={"USD 499.99"}
                    sx={{
                      backgroundColor: `${colors.primary[400]}`,
                      borderRadius: "10px",
                      minWidth: "345px",
                      color: `${colors.grey[900]}`,

                      "& .MuiInputBase-root": {
                        fontSize: "18px",
                        color: `${colors.grey[900]}`,
                      },
                      "& .MuiFilledInput-input": {
                        color: `${colors.grey[400]} !important`,
                      },
                    }}
                  />
                </FormControl>
              </Box>
            </Box>
          </Box>

          <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
            <Typography marginBottom={3}>Links that used before</Typography>

            {/* Perform mapping in Buttons */}

            <Button
              className="me-3"
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              #bullish
            </Button>
            <Button
              className="me-3"
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              #bearish
            </Button>
            <Button
              sx={{
                background: "#4E33FF",
                color: `${colors.grey[900]}`,
                minHeight: "22px",
                fontSize: "10px",
                borderRadius: "24px !important",
                fontWeight: "400",
                textAlign: "center",
                minWidth: "max-content",
                padding: "4px 9px 4px 9px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              #options
            </Button>
          </Box>
        </Box>

        {/* Buttons */}

        <Box
          display="flex"
          flexDirection="row"
          alignSelf="left"
          marginTop={4}
          marginLeft={4}
        >
          <FormControl>
            <Button
              sx={{
                background: `${colors.greenAccent[500]}`,
                margin: "12px 0 12px 0",
                height: "40px",
                borderRadius: "24px !important",
                fontWeight: "700",
                padding: "20px 60px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                Save & Close
              </Typography>
            </Button>
          </FormControl>

          <FormControl>
            <Typography
              variant="h6"
              sx={{
                color: `${colors.grey[100]}`,
                fontWeight: "700",
                padding: "21px 20px",
              }}
            >
              We'll autosave every 20 seconds
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
