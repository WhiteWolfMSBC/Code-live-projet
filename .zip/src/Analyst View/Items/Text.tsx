import React, { useState } from "react";
import JoditReact from "jodit-react-ts";
import "jodit/build/jodit.min.css";
import "./Items.css";
import { Helmet } from "react-helmet";
import { Box, Button, FormControl, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function Text() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [value, setValue] = useState<string>();
  console.log({ value });

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Text</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="textEditor_Box">
        <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
          <JoditReact
            onChange={(content: any) => setValue(content)}
            defaultValue="Lorem ipsum dolor sit amet consectetur adipisicing elit. 
            Quis, praesentium? Nostrum excepturi neque a, maiores in natus consectetur 
            dolor nam blanditiis totam et recusandae aut doloremque ad quam cumque eum!"
          />
        </Box>

        {/* Buttons */}

        <Box
          display="flex"
          flexDirection="row"
          alignSelf="left"
          marginTop={8}
          marginRight={4}
          marginLeft={4}
        >
          <FormControl>
            <Button
              sx={{
                background: `${colors.greenAccent[500]}`,
                margin: "12px 0 12px 0",
                height: "40px",
                borderRadius: "24px !important",
                fontWeight: "700",
                padding: "20px 60px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                Save & Close
              </Typography>
            </Button>
          </FormControl>

          <FormControl>
            <Typography
              variant="h6"
              sx={{
                color: `${colors.grey[100]}`,
                fontWeight: "700",
                padding: "21px 20px",
              }}
            >
              We'll autosave every 20 seconds
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
