import React from "react";
import "./Items.css";
import { Helmet } from "react-helmet";
import { Box, Button, Card, FormControl, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function ChartUpload() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ChartUpload</title>
      </Helmet>

      {/* TextEditor */}

      <Box>
        {/* Cards */}

        <Box justifyContent={"center"} marginTop={5}>
          {/* 1st Row */}

          <Box>
            <div className="row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                >
                  <img
                    className="Card-img"
                    src={
                      "https://www.tibco.com/sites/tibco/files/media_entity/2022-01/PieChart-01.svg"
                    }
                    alt=""
                  />
                </Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                >
                  <img
                    className="Card-img"
                    src={
                      "https://www.ft.com/__origami/service/image/v2/images/raw/ftcms%3A347ece48-0f69-11e9-a3aa-118c761d2745?source=ig"
                    }
                    alt=""
                  />
                </Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                >
                  <img
                    className="Card-img"
                    src={
                      "https://docs.moodle.org/dev/images_dev/c/c5/bar_chart.png"
                    }
                    alt=""
                  />
                </Card>
              </div>
            </div>
          </Box>

          {/* 2nd Row */}

          <Box marginTop={2}>
            <div className="row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                ></Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                ></Card>
              </div>

              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-sm-12">
                <Card
                  className="card"
                  sx={{
                    padding: "12px 16px 12px 16px",
                    display: "flex",
                    flexDirection: "column",
                    maxWidth: 300,
                    minHeight: 180,
                    backgroundColor: `${colors.primary[400]}`,
                    cursor: "pointer",
                  }}
                ></Card>
              </div>
            </div>
          </Box>
        </Box>

        {/* Buttons */}

        <Box display="flex" flexDirection="row" alignSelf="left">
          <FormControl>
            <Button
              sx={{
                background: `${colors.greenAccent[500]}`,
                margin: "12px 0 12px 0",
                height: "40px",
                borderRadius: "24px !important",
                fontWeight: "700",
                padding: "20px 60px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                Save & Close
              </Typography>
            </Button>
          </FormControl>

          <FormControl>
            <Typography
              variant="h6"
              sx={{
                color: `${colors.grey[100]}`,
                fontWeight: "700",
                padding: "21px 20px",
              }}
            >
              We'll autosave every 20 seconds
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
