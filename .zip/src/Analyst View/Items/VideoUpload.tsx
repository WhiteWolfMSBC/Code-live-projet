import React, { useState } from "react";
import JoditReact from "jodit-react-ts";
import "jodit/build/jodit.min.css";
import "./Items.css";
import { Helmet } from "react-helmet";
import { Box, Button, FormControl, TextField, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";
import ReactPlayer from "react-player";

export default function VideoUpload() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [value, setValue] = useState<string>();
  console.log({ value });

  // Url For Video

  const [urlData, seturlData] = useState("");

  const handleChange = (event: any) => {
    seturlData(event.target.value);
  };

  // video

  const [play, setPlay] = useState(false);
  const handleMouseEnter = () => {
    setPlay(true);
  };
  const handleMouseLeave = () => {
    setPlay(false);
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | VideoUpload</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="textEditor_Box">
        <Box display="flex" flexDirection="column">
          <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <TextField
                required
                value={urlData}
                onChange={handleChange}
                id="emailId"
                variant="filled"
                label="Add Video URL in editor, drop a previw image here"
                placeholder="&#x2709;"
                type="text"
                size="small"
                sx={{
                  backgroundColor: `${colors.primary[400]}`,
                  borderRadius: "10px",
                  minWidth: "760px",

                  "& .MuiInputBase-root": {
                    fontSize: "18px",
                    color: `${colors.grey[900]}`,
                  },
                  "& .MuiFilledInput-input": {
                    color: `${colors.grey[400]} !important`,
                  },
                }}
              />
            </FormControl>
          </Box>

          <Box>
            {/* Video */}

            <Box
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              <ReactPlayer
                width={"50px"}
                height={"50px"}
                playing={play}
                pip
                controls={true}
                config={{ file: { forceHLS: true } }}
                url={urlData}
              />
            </Box>
          </Box>

          <Box alignSelf={"left"} marginTop={2} marginRight={4} marginLeft={4}>
            <JoditReact
              onChange={(content: any) => setValue(content)}
              defaultValue="Input caption text here. Use the block's 
          Settings tab to change the caption position and set other 
          styles."
            />
          </Box>
        </Box>

        {/* Buttons */}

        <Box
          display="flex"
          flexDirection="row"
          alignSelf="left"
          marginRight={4}
          marginLeft={4}
        >
          <FormControl>
            <Button
              sx={{
                background: `${colors.greenAccent[500]}`,
                margin: "12px 0 12px 0",
                height: "40px",
                borderRadius: "24px !important",
                fontWeight: "700",
                padding: "20px 60px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                Save & Close
              </Typography>
            </Button>
          </FormControl>

          <FormControl>
            <Typography
              variant="h6"
              sx={{
                color: `${colors.grey[100]}`,
                fontWeight: "700",
                padding: "21px 20px",
              }}
            >
              We'll autosave every 20 seconds
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
