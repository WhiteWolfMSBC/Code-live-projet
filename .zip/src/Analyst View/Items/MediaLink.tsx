import React, { useState } from "react";
import "./Items.css";
import { Helmet } from "react-helmet";
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { tokens } from "../../theme";

export default function MediaLink() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [link, setLink] = useState("");

  const handleChange = (event: SelectChangeEvent) => {
    setLink(event.target.value as string);
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | MediaLink</title>
      </Helmet>

      {/* TextEditor */}

      <Box className="textEditor_Box">
        <Box display="flex" flexDirection="column">
          <Box
            alignSelf={"center"}
            marginTop={6}
            marginRight={4}
            marginLeft={4}
          >
            {/* Link Url 1 textfield */}
            <Typography marginBottom={1}>Link URL is here</Typography>

            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <TextField
                required
                id="emailId"
                variant="filled"
                label="MediaLink"
                placeholder="&#x2709;"
                type="text"
                size="small"
                value={
                  "https://www.youtube.com/watch?v=WcIcVapfqXw&ab_channel=SelenaGomezVEVO"
                }
                sx={{
                  backgroundColor: `${colors.primary[400]}`,
                  borderRadius: "10px",
                  minWidth: "700px",

                  "& .MuiInputBase-root": {
                    fontSize: "18px",
                    color: `${colors.grey[900]}`,
                  },
                  "& .MuiFilledInput-input": {
                    color: `${colors.grey[400]} !important`,
                  },
                }}
              />
            </FormControl>
          </Box>

          <Box
            alignSelf={"center"}
            marginTop={6}
            marginRight={4}
            marginLeft={4}
          >
            {/* Link Url 2 textfield  (Select)*/}
            <Typography marginBottom={1}>Links that used before</Typography>

            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <InputLabel id="mediaLink">MediaLink</InputLabel>
              <Select
                labelId="mediaLink"
                required
                id="mediaLink"
                size="small"
                value={link}
                label="Age"
                variant="filled"
                onChange={handleChange}
                sx={{
                  borderRadius: "10px",
                  minWidth: "700px",
                  height: "50px !important",

                  "& .MuiInputBase-root": {
                    fontSize: "18px",
                    color: `${colors.grey[900]}`,
                  },
                  "& .MuiFilledInput-input": {
                    color: `${colors.grey[400]} !important`,
                  },
                }}
              >
                <MenuItem value={1}>
                  https://www.youtube.com/watch?v=MjRRQdnOR-A&ab_channel=shakiraVEVO
                </MenuItem>
                <MenuItem value={2}>
                  https://www.youtube.com/watch?v=QzakjlbO2Lc&ab_channel=KygoOfficialVEVO
                </MenuItem>
                <MenuItem value={3}>
                  https://www.youtube.com/watch?app=desktop&v=RP2teAKjYFA&ab_channel=Lauv
                </MenuItem>
              </Select>
            </FormControl>
          </Box>
        </Box>

        {/* Buttons */}

        <Box
          display="flex"
          flexDirection="row"
          alignSelf="left"
          marginTop={8}
          marginLeft={4}
        >
          <FormControl>
            <Button
              sx={{
                background: `${colors.greenAccent[500]}`,
                margin: "12px 0 12px 0",
                height: "40px",
                borderRadius: "24px !important",
                fontWeight: "700",
                padding: "20px 60px",
                "&.MuiButton-root:hover": {
                  WebkitTextDecorationStyle: "none",
                  backgroundColor: `${colors.greenAccent[600]} !important`,
                },
              }}
            >
              <Typography variant="h6" sx={{ color: `${colors.grey[900]}` }}>
                Save & Close
              </Typography>
            </Button>
          </FormControl>

          <FormControl>
            <Typography
              variant="h6"
              sx={{
                color: `${colors.grey[100]}`,
                fontWeight: "700",
                padding: "21px 20px",
              }}
            >
              We'll autosave every 20 seconds
            </Typography>
          </FormControl>
        </Box>
      </Box>
    </>
  );
}
