import { Button, FormControl, Typography, useTheme } from "@mui/material";
import React from "react";
import { tokens } from "../../theme";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import "./OneIdeaPerDay.css";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import ReportGmailerrorredOutlinedIcon from "@mui/icons-material/ReportGmailerrorredOutlined";

export default function OneIdeaPerDay() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | OneIdeaPerDay</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Typography
            variant="h4"
            marginLeft={4}
            marginTop={1.5}
            color={colors.greenAccent[500]}
            className="Typography"
          >
            OneIdeaPerDay
          </Typography>
        </Box>

        <Box display={"flex"} p={1.5}>
          <Button
            className="CreateIdea_btn"
            sx={{
              color: `${colors.grey[800]}`,
              backgroundColor: `${colors.greenAccent[500]}`,
              marginTop: "23px",
              "&.MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",
                backgroundColor: `${colors.greenAccent[600]} !important`,
              },
            }}
            variant="contained"
            color="success"
          >
            Submit for Approval
          </Button>
          <TopBar />
        </Box>
      </Box>

      {/* OneIdeaPerDay */}

      <Box marginLeft={4} marginRight={2}>
        <Box display={"flex"} flexDirection={"column"}>
          <Box className="row">
            <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <Box
                    display="flex"
                    flexDirection="column"
                    sx={{ padding: "20px 30px 20px 30px" }}
                  >
                    <Box alignSelf={"left"}>
                      {/* Buttons */}

                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bullish
                      </Button>
                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bearish
                      </Button>
                      <Button
                        className="tagBtn"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # options
                      </Button>
                    </Box>

                    {/* Heading */}

                    <Box marginTop={3} alignSelf={"left"}>
                      <FormControl>
                        <Typography className="headingTxt" variant="h1">
                          Alternative 1
                        </Typography>
                      </FormControl>
                    </Box>

                    {/* Row & Coloum */}

                    <Box className="row" marginTop={3}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Risk</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.redAccent[600]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Potantial Return</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.greenAccent[500]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Leverage</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Short Selling</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                    </Box>

                    {/* Another Row and Coloum */}

                    <Box className="row" marginTop={4}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Hedged</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            Yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-5 col-lg-5 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Note</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.blueAccent[500]}` }}
                          >
                            Buy TSLA Call Options
                          </Typography>
                        </Box>
                      </Box>
                      <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"></Box>
                    </Box>

                    {/* Button */}
                    <Box marginTop={2}>
                      <FormControl>
                        <Button
                          className="CreateIdea_btn"
                          sx={{
                            color: `${colors.grey[800]}`,
                            backgroundColor: `${colors.greenAccent[500]}`,
                            marginTop: "23px",
                            "&.MuiButton-root:hover": {
                              WebkitTextDecorationStyle: "none",
                              backgroundColor: `${colors.greenAccent[600]} !important`,
                            },
                          }}
                          variant="contained"
                          color="success"
                        >
                          View Investment Channels
                        </Button>
                      </FormControl>
                    </Box>

                    {/* Warning Icon */}

                    <Box display="flex" justifyContent="space-between">
                      <Box></Box>
                      <span>
                        <ReportGmailerrorredOutlinedIcon
                          sx={{
                            fontSize: "45px",
                            color: `${colors.redAccent[600]}`,
                          }}
                        />
                      </span>
                    </Box>
                  </Box>
                </Card>
              </Box>
            </Box>

            <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <Box
                    display="flex"
                    flexDirection="column"
                    sx={{ padding: "20px 30px 20px 30px" }}
                  >
                    <Box alignSelf={"left"}>
                      {/* Buttons */}

                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bullish
                      </Button>
                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bearish
                      </Button>
                      <Button
                        className="tagBtn"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # options
                      </Button>
                    </Box>

                    {/* Heading */}

                    <Box marginTop={3} alignSelf={"left"}>
                      <FormControl>
                        <Typography className="headingTxt" variant="h1">
                          Alternative 2
                        </Typography>
                      </FormControl>
                    </Box>

                    {/* Row & Coloum */}

                    <Box className="row" marginTop={3}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Risk</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.redAccent[600]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Potantial Return</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.greenAccent[500]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Leverage</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Short Selling</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                    </Box>

                    {/* Another Row and Coloum */}

                    <Box className="row" marginTop={4}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Hedged</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            Yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-5 col-lg-5 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Note</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.blueAccent[500]}` }}
                          >
                            Buy Electric Vechicle ETF
                          </Typography>
                        </Box>
                      </Box>
                      <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"></Box>
                    </Box>

                    {/* Button */}
                    <Box marginTop={2}>
                      <FormControl>
                        <Button
                          className="CreateIdea_btn"
                          sx={{
                            color: `${colors.grey[800]}`,
                            backgroundColor: `${colors.greenAccent[500]}`,
                            marginTop: "23px",
                            "&.MuiButton-root:hover": {
                              WebkitTextDecorationStyle: "none",
                              backgroundColor: `${colors.greenAccent[600]} !important`,
                            },
                          }}
                          variant="contained"
                          color="success"
                        >
                          View Investment Channels
                        </Button>
                      </FormControl>
                    </Box>

                    {/* Warning Icon */}

                    <Box display="flex" justifyContent="space-between">
                      <Box></Box>
                      <span>
                        <ReportGmailerrorredOutlinedIcon
                          sx={{
                            fontSize: "45px",
                            color: `${colors.redAccent[600]}`,
                          }}
                        />
                      </span>
                    </Box>
                  </Box>
                </Card>
              </Box>
            </Box>

            <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <Box
                    display="flex"
                    flexDirection="column"
                    sx={{ padding: "20px 30px 20px 30px" }}
                  >
                    <Box alignSelf={"left"}>
                      {/* Buttons */}

                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bullish
                      </Button>
                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bearish
                      </Button>
                      <Button
                        className="tagBtn"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # options
                      </Button>
                    </Box>

                    {/* Heading */}

                    <Box marginTop={3} alignSelf={"left"}>
                      <FormControl>
                        <Typography className="headingTxt" variant="h1">
                          Alternative 3
                        </Typography>
                      </FormControl>
                    </Box>

                    {/* Row & Coloum */}

                    <Box className="row" marginTop={3}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Risk</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.redAccent[600]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Potantial Return</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.greenAccent[500]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Leverage</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Short Selling</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                    </Box>

                    {/* Another Row and Coloum */}

                    <Box className="row" marginTop={4}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Hedged</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            Yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-5 col-lg-5 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Note</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.blueAccent[500]}` }}
                          >
                            Buy 1/2 ETF and 1/2 TSLA
                          </Typography>
                        </Box>
                      </Box>
                      <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"></Box>
                    </Box>

                    {/* Button */}
                    <Box marginTop={2}>
                      <FormControl>
                        <Button
                          className="CreateIdea_btn"
                          sx={{
                            color: `${colors.grey[800]}`,
                            backgroundColor: `${colors.greenAccent[500]}`,
                            marginTop: "23px",
                            "&.MuiButton-root:hover": {
                              WebkitTextDecorationStyle: "none",
                              backgroundColor: `${colors.greenAccent[600]} !important`,
                            },
                          }}
                          variant="contained"
                          color="success"
                        >
                          View Investment Channels
                        </Button>
                      </FormControl>
                    </Box>

                    {/* Warning Icon */}

                    <Box display="flex" justifyContent="space-between">
                      <Box></Box>
                      <span>
                        <ReportGmailerrorredOutlinedIcon
                          sx={{
                            fontSize: "45px",
                            color: `${colors.redAccent[600]}`,
                          }}
                        />
                      </span>
                    </Box>
                  </Box>
                </Card>
              </Box>
            </Box>
          </Box>

          {/* Row */}

          <Box className="row" marginTop={2}>
            <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <Box
                    display="flex"
                    flexDirection="column"
                    sx={{ padding: "20px 30px 20px 30px" }}
                  >
                    <Box alignSelf={"left"}>
                      {/* Buttons */}

                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bullish
                      </Button>
                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bearish
                      </Button>
                      <Button
                        className="tagBtn"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # options
                      </Button>
                    </Box>

                    {/* Heading */}

                    <Box marginTop={3} alignSelf={"left"}>
                      <FormControl>
                        <Typography className="headingTxt" variant="h1">
                          Alternative 4
                        </Typography>
                      </FormControl>
                    </Box>

                    {/* Row & Coloum */}

                    <Box className="row" marginTop={3}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Risk</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.redAccent[600]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Potantial Return</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.greenAccent[500]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Leverage</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Short Selling</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                    </Box>

                    {/* Another Row and Coloum */}

                    <Box className="row" marginTop={4}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Hedged</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            Yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Note</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.blueAccent[500]}` }}
                          >
                            Buy TSLA and Short EKAR
                          </Typography>
                        </Box>
                      </Box>
                      <Box className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"></Box>
                    </Box>

                    {/* Button */}
                    <Box marginTop={2}>
                      <FormControl>
                        <Button
                          className="CreateIdea_btn"
                          sx={{
                            color: `${colors.grey[800]}`,
                            backgroundColor: `${colors.greenAccent[500]}`,
                            marginTop: "23px",
                            "&.MuiButton-root:hover": {
                              WebkitTextDecorationStyle: "none",
                              backgroundColor: `${colors.greenAccent[600]} !important`,
                            },
                          }}
                          variant="contained"
                          color="success"
                        >
                          View Investment Channels
                        </Button>
                      </FormControl>
                    </Box>

                    {/* Warning Icon */}

                    <Box display="flex" justifyContent="space-between">
                      <Box></Box>
                      <span>
                        <ReportGmailerrorredOutlinedIcon
                          sx={{
                            fontSize: "45px",
                            color: `${colors.redAccent[600]}`,
                          }}
                        />
                      </span>
                    </Box>
                  </Box>
                </Card>
              </Box>
            </Box>

            <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <Box
                    display="flex"
                    flexDirection="column"
                    sx={{ padding: "20px 30px 20px 30px" }}
                  >
                    <Box alignSelf={"left"}>
                      {/* Buttons */}

                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bullish
                      </Button>
                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bearish
                      </Button>
                      <Button
                        className="tagBtn"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # options
                      </Button>
                    </Box>

                    {/* Heading */}

                    <Box marginTop={3} alignSelf={"left"}>
                      <FormControl>
                        <Typography className="headingTxt" variant="h1">
                          Alternative 5
                        </Typography>
                      </FormControl>
                    </Box>

                    {/* Row & Coloum */}

                    <Box className="row" marginTop={3}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Risk</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.redAccent[600]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Potantial Return</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.greenAccent[500]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Leverage</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Short Selling</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                    </Box>

                    {/* Another Row and Coloum */}

                    <Box className="row" marginTop={4}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Hedged</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            Yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Note</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.blueAccent[500]}` }}
                          >
                            Short TSLA
                          </Typography>
                        </Box>
                      </Box>
                      <Box className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"></Box>
                    </Box>

                    {/* Button */}
                    <Box marginTop={2}>
                      <FormControl>
                        <Button
                          className="CreateIdea_btn"
                          sx={{
                            color: `${colors.grey[800]}`,
                            backgroundColor: `${colors.greenAccent[500]}`,
                            marginTop: "23px",
                            "&.MuiButton-root:hover": {
                              WebkitTextDecorationStyle: "none",
                              backgroundColor: `${colors.greenAccent[600]} !important`,
                            },
                          }}
                          variant="contained"
                          color="success"
                        >
                          View Investment Channels
                        </Button>
                      </FormControl>
                    </Box>

                    {/* Warning Icon */}

                    <Box display="flex" justifyContent="space-between">
                      <Box></Box>
                      <span>
                        <ReportGmailerrorredOutlinedIcon
                          sx={{
                            fontSize: "45px",
                            color: `${colors.redAccent[600]}`,
                          }}
                        />
                      </span>
                    </Box>
                  </Box>
                </Card>
              </Box>
            </Box>

            <Box className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                >
                  <Box
                    display="flex"
                    flexDirection="column"
                    sx={{ padding: "20px 30px 20px 30px" }}
                  >
                    <Box alignSelf={"left"}>
                      {/* Buttons */}

                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bullish
                      </Button>
                      <Button
                        className="tagBtn me-3"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # bearish
                      </Button>
                      <Button
                        className="tagBtn"
                        sx={{
                          color: `${colors.grey[900]}`,
                          "&.MuiButton-root:hover": {
                            WebkitTextDecorationStyle: "none",
                            backgroundColor: `${colors.greenAccent[600]} !important`,
                          },
                        }}
                      >
                        # options
                      </Button>
                    </Box>

                    {/* Heading */}

                    <Box marginTop={3} alignSelf={"left"}>
                      <FormControl>
                        <Typography className="headingTxt" variant="h1">
                          Alternative 6
                        </Typography>
                      </FormControl>
                    </Box>

                    {/* Row & Coloum */}

                    <Box className="row" marginTop={3}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Risk</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.redAccent[600]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Potantial Return</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.greenAccent[500]}` }}
                          >
                            High
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Leverage</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Short Selling</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            yes
                          </Typography>
                        </Box>
                      </Box>
                    </Box>

                    {/* Another Row and Coloum */}

                    <Box className="row" marginTop={4}>
                      <Box
                        className="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Hedged</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.grey[900]}` }}
                          >
                            Yes
                          </Typography>
                        </Box>
                      </Box>
                      <Box
                        className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12"
                        display={"flex"}
                        flexDirection={"column"}
                      >
                        <Box alignSelf={"left"}>
                          <Typography variant="h5">Note</Typography>
                        </Box>
                        <Box alignSelf={"left"}>
                          <Typography
                            variant="h5"
                            sx={{ color: `${colors.blueAccent[500]}` }}
                          >
                            Short Electric Vechicle
                          </Typography>
                        </Box>
                      </Box>
                      <Box className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12"></Box>
                    </Box>

                    {/* Button */}
                    <Box marginTop={2}>
                      <FormControl>
                        <Button
                          className="CreateIdea_btn"
                          sx={{
                            color: `${colors.grey[800]}`,
                            backgroundColor: `${colors.greenAccent[500]}`,
                            marginTop: "23px",
                            "&.MuiButton-root:hover": {
                              WebkitTextDecorationStyle: "none",
                              backgroundColor: `${colors.greenAccent[600]} !important`,
                            },
                          }}
                          variant="contained"
                          color="success"
                        >
                          View Investment Channels
                        </Button>
                      </FormControl>
                    </Box>

                    {/* Warning Icon */}

                    <Box display="flex" justifyContent="space-between">
                      <Box></Box>
                      <span>
                        <ReportGmailerrorredOutlinedIcon
                          sx={{
                            fontSize: "45px",
                            color: `${colors.redAccent[600]}`,
                          }}
                        />
                      </span>
                    </Box>
                  </Box>
                </Card>
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
}
