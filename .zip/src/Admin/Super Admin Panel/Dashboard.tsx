import { Typography, useTheme, TableContainer } from "@mui/material";
import React from "react";
import { tokens } from "../../theme";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import "./Dashboard.css";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";

const card = (
  <React.Fragment>
    <CardContent>
      <Typography
        sx={{ fontSize: 16, textAlign: "start" }}
        color="text.secondary"
        gutterBottom
      >
        Idea of the day
      </Typography>

      <Typography
        sx={{ fontSize: 14, textAlign: "start" }}
        color="text.secondary"
        gutterBottom
      >
        Review Request
      </Typography>

      <Typography
        variant="body2"
        sx={{
          margin: "auto",
          padding: "0px",
          textAlign: "center",
          marginTop: "100px",
        }}
      >
        <h5>
          The subpage will be created
          <br /> according to their work
        </h5>

        <h3>WIP</h3>
      </Typography>
    </CardContent>
  </React.Fragment>
);

function Dashboard() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Dashboard</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Typography
            variant="h4"
            marginLeft={4}
            marginTop={1.5}
            color={colors.greenAccent[500]}
            className='Typography'
          >
            Dashboard
          </Typography>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>

      </Box>

      {/* Dashboard */}

      <Box marginLeft={4} marginRight={2}>
      {/* <TableContainer className="tableContainer"> */}
        
          <Box>
            <div className="row">
              <div className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <Box sx={{}}>
                  <Card
                    className="colorCard"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                    variant="outlined"
                  >
                    {card}
                  </Card>
                </Box>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <Box sx={{}}>
                  <Card
                    className="colorCard"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                    variant="outlined"
                  >
                    {card}
                  </Card>
                </Box>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <Box sx={{}}>
                  <Card
                    className="colorCard"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                    variant="outlined"
                  >
                    {card}
                  </Card>
                </Box>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <Box sx={{}}>
                  <Card
                    className="colorCard"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                    variant="outlined"
                  >
                    {card}
                  </Card>
                </Box>
              </div>
            </div>

            {/* Row */}

            <div className="row mt-3">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <Box sx={{}}>
                  <Card
                    className="colorCard1"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                    variant="outlined"
                  >
                    {card}
                  </Card>
                </Box>
              </div>

              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <Box sx={{}}>
                  <Card
                    className="colorCard1"
                    sx={{ backgroundColor: `${colors.primary[400]}` }}
                    variant="outlined"
                  >
                    {card}
                  </Card>
                </Box>
              </div>
            </div>
          </Box>
        {/* </TableContainer> */}
      </Box>
    </>
  );
}

export default Dashboard;
