import * as React from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import Ideaoftheday from "../ApplicationManagement/Tabs/Ideaoftheday";
import Peergroup from "../ApplicationManagement/Tabs/Peergroup";
import Thematicbasket from "../ApplicationManagement/Tabs/Thematicbasket";
import Tradeexecutiondate from "../ApplicationManagement/Tabs/Tradeexecutiondate";
import {
  IconButton,
  TableContainer,
  Typography,
  useTheme,
} from "@mui/material";
import { tokens } from "../../theme";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import Dropdown from "./Dropdown";
import "./ApplicationTable.css";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import ApplicationTableWithBoder from "./ApplicationTablewithBoder";

export default function LabTabs() {
  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | ApplicationTable</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"} sx={{ m: "8px" }}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Box display={"flex"}>
            <Typography
              variant="h4"
              marginLeft={4}
              marginTop={1.5}
              color={colors.greenAccent[500]}
              className="Typography"
            >
              Application Mangement
            </Typography>

            <IconButton size="large" color="inherit">
              <KeyboardArrowLeftIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <KeyboardArrowRightIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <CloseIcon />
            </IconButton>
          </Box>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>
      </Box>

      {/* Tabs */}

      <Box marginLeft={4} marginRight={2}>
        <TabContext value={value}>
          <Box display="flex" justifyContent={"space-between"}>
            <TabList onChange={handleChange} className="tablist" sx={{}}>
              <Tab
                id="applicationTabletabs"
                sx={{
                  color: `${colors.grey[900]}`,
                  backgroundColor: `${colors.primary[400]}`,
                }}
                className="applicationtab me-3"
                label="Ideas of the day"
                value="1"
              />
              <Tab
                sx={{
                  color: `${colors.grey[900]}`,
                  backgroundColor: `${colors.primary[400]}`,
                }}
                className="applicationtab me-3"
                label="Thematic baskets"
                value="2"
              />
              <Tab
                sx={{
                  color: `${colors.grey[900]}`,
                  backgroundColor: `${colors.primary[400]}`,
                }}
                className="applicationtab me-3"
                label="Peer group"
                value="3"
              />
              <Tab
                sx={{
                  color: `${colors.grey[900]}`,
                  backgroundColor: `${colors.primary[400]}`,
                }}
                className="applicationtab me-3"
                label="Trade excution date"
                value="4"
              />
            </TabList>

            <Box>
              <Dropdown />
            </Box>
          </Box>

          <TableContainer
            className="tableContainer1"
          >
            <TabPanel value="1">
              <Ideaoftheday />
              {/* <ApplicationTableWithBoder /> */}
            </TabPanel>
            <TabPanel value="2">
              <Thematicbasket />
            </TabPanel>
            <TabPanel value="3">
              <Peergroup />
            </TabPanel>
            <TabPanel value="4">
              <Tradeexecutiondate />
            </TabPanel>
          </TableContainer>
        </TabContext>
      </Box>
    </>
  );
}
