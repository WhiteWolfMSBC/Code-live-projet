import React from "react";

function Thematicbasket() {
  return <div>hii</div>;
}

export default Thematicbasket;
