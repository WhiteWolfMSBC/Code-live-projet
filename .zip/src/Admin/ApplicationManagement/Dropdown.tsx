import * as React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import { Box, IconButton, InputAdornment, useTheme } from "@mui/material";
import { makeStyles } from "@material-ui/core/styles";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import { tokens } from "../../theme";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: "yellow",
  },
  clearIndicator: {
    backgroundColor: "gray",
    "& span": {
      "& svg": {
        backgroundColor: "red",
      },
    },
  },
  popupIndicator: {
    "& span": {
      "& svg": {
        "& path": {
          d: "path('M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z')",
        },
      },
    },
  },
}));

export default function ComboBox() {
  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      <Box
        display="flex"
        sx={{
          borderRadius: "10px",
          border: "1px solid gray",
          minheight: "556px",
          minwidth: "30px",
        }}
        // maxWidth={'556px'}
      >
        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={day}
            // sx={{ maxwidth: 100 }}

            renderInput={(params) => (
              <TextField
                sx={{
                  color: `${colors.grey[900]} !important`,
                  "& .MuiInputLabel-root": {
                    color: `${colors.primary[100]} !important`,
                  },
                  "& .MuiTextField-root": {
                    borderBottom: "none",
                    borderRadius: "24px",
                  },

                  "& .MuiFilledInput-root": {
                    backgroundColor: "transparent",
                    borderBottom: "none",
                    marginRight: "50px !important",
                    paddingRight: "0 !important",
                  },
                  "& .MuiFilledInput-root:before": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:after": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:hover": {
                    borderBottom: "none",
                  },
                }}
                variant="filled"
                {...params}
                label="Day"
              />
            )}
          />
        </Box>

        {/* 2 Autocomplete */}

        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={week}
            // sx={{ width: 130 }}
            renderInput={(params) => (
              <TextField
                sx={{
                  color: `${colors.grey[900]} !important`,
                  "& .MuiInputLabel-root": {
                    color: `${colors.primary[100]} !important`,
                  },
                  "& .MuiTextField-root": {
                    borderBottom: "none",
                    borderRadius: "24px",
                  },

                  "& .MuiFilledInput-root": {
                    backgroundColor: "transparent",
                    borderBottom: "none",
                    marginRight: "50px !important",
                    paddingRight: "0 !important",
                  },
                  "& .MuiFilledInput-root:before": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:after": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:hover": {
                    borderBottom: "none",
                  },
                }}
                variant="filled"
                {...params}
                label="Week"
              />
            )}
          />
        </Box>

        {/* 3 Autocomplete */}

        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={month}
            // sx={{ width: 150 }}
            renderInput={(params) => (
              <TextField
                sx={{
                  color: `${colors.grey[900]} !important`,
                  "& .MuiInputLabel-root": {
                    color: `${colors.primary[100]} !important`,
                  },
                  "& .MuiTextField-root": {
                    borderBottom: "none",
                    borderRadius: "24px",
                  },

                  "& .MuiFilledInput-root": {
                    backgroundColor: "transparent",
                    borderBottom: "none",
                    marginRight: "50px !important",
                    paddingRight: "0 !important",
                  },
                  "& .MuiFilledInput-root:before": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:after": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:hover": {
                    borderBottom: "none",
                  },
                }}
                variant="filled"
                {...params}
                label="Month"
              />
            )}
          />
        </Box>

        {/* 4 Autocomplete */}

        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={tag}
            // sx={{ width: 130 }}
            renderInput={(params) => (
              <TextField
                sx={{
                  color: `${colors.grey[900]} !important`,
                  "& .MuiInputLabel-root": {
                    color: `${colors.primary[100]} !important`,
                  },
                  "& .MuiTextField-root": {
                    borderBottom: "none",
                    borderRadius: "24px",
                  },

                  "& .MuiFilledInput-root": {
                    backgroundColor: "transparent",
                    borderBottom: "none",
                    marginRight: "50px !important",
                    paddingRight: "0 !important",
                  },
                  "& .MuiFilledInput-root:before": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:after": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:hover": {
                    borderBottom: "none",
                  },
                }}
                variant="filled"
                {...params}
                label="Tag"
              />
            )}
          />
        </Box>

        {/* 5 Autocomplete */}

        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={favorites}
            // sx={{ width: 130 }}
            renderInput={(params) => (
              <TextField
                sx={{
                  color: `${colors.grey[900]} !important`,
                  "& .MuiInputLabel-root": {
                    color: `${colors.primary[100]} !important`,
                    paddingRight: "5px",
                  },
                  "& .MuiTextField-root": {
                    borderBottom: "none",
                    borderRadius: "24px",
                  },

                  "& .MuiFilledInput-root": {
                    backgroundColor: "transparent",
                    borderBottom: "none",
                    marginRight: "50px !important",
                    paddingRight: "0 !important",
                  },
                  "& .MuiFilledInput-root:before": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:after": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:hover": {
                    borderBottom: "none",
                  },
                }}
                variant="filled"
                {...params}
                label="Favorite"
              />
            )}
          />
        </Box>

        {/* 6 Autocomplete */}

        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={subject}
            // sx={{ width: 130 }}
            renderInput={(params) => (
              <TextField
                variant="filled"
                sx={{
                  color: `${colors.grey[900]} !important`,
                  "& .MuiInputLabel-root": {
                    color: `${colors.primary[100]} !important`,
                  },
                  "& .MuiTextField-root": {
                    borderBottom: "none",
                    borderRadius: "24px",
                  },

                  "& .MuiFilledInput-root": {
                    backgroundColor: "transparent",
                    borderBottom: "none",
                    marginRight: "50px !important",
                    paddingRight: "0 !important",
                  },
                  "& .MuiFilledInput-root:before": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:after": {
                    borderBottom: "none",
                  },
                  "& .MuiFilledInput-root:hover": {
                    borderBottom: "none",
                  },
                }}
                {...params}
                label="Subject"
              />
            )}
          />
        </Box>

        {/* Filter Icon */}

        <Box>
          <IconButton size="large" color="inherit">
            <FilterAltIcon />
          </IconButton>
        </Box>
      </Box>
    </>
  );
}

const day = [
  { label: "01", year: "" },
  { label: "02", year: "" },
  { label: "03", year: "" },
  { label: "04", year: "" },
  { label: "05", year: "" },
  { label: "07", year: "" },
  { label: "08", year: "" },
  { label: "09", year: "" },
  { label: 10, year: "" },
  { label: 11, year: "" },
  { label: 12, year: "" },
  { label: 13, year: "" },
  { label: 14, year: "" },
  { label: 15, year: "" },
  { label: 16, year: "" },
  { label: 17, year: "" },
  { label: 18, year: "" },
  { label: 19, year: "" },
  { label: 20, year: "" },
  { label: 21, year: "" },
  { label: 22, year: "" },
  { label: 23, year: "" },
  { label: 24, year: "" },
  { label: 25, year: "" },
  { label: 26, year: "" },
  { label: 27, year: "" },
  { label: 28, year: "" },
  { label: 29, year: "" },
  { label: 30, year: "" },
  { label: 31, year: "" },
];

const week = [
  { label: "Monday", year: "" },
  { label: "Tuesday", year: "" },
  { label: "Wednesday", year: "" },
  { label: "Thrusday", year: "" },
  { label: "Friday", year: "" },
  { label: "Saturday", year: "" },
  { label: "Sunday", year: "" },
];

const month = [
  { label: "January", year: "" },
  { label: "February", year: "" },
  { label: "March", year: "" },
  { label: "April", year: "" },
  { label: "May", year: "" },
  { label: "June", year: "" },
  { label: "July", year: "" },
  { label: "Auguest", year: "" },
  { label: "September", year: "" },
  { label: "Octuber", year: "" },
  { label: "November", year: "" },
  { label: "December", year: "" },
];

const tag = [
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
];

const favorites = [
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
];

const subject = [
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
  { label: "", year: "" },
];
