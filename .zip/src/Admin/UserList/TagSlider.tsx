import React,{useState} from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import "./TagSlider.css";

export default function ScrollableTabsButtonAuto() {
  const [value, setValue] = useState(1);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    console.log(event);
    console.log(newValue);
  };

  return (
    <Box
      className="mt-3"
      sx={{
        maxWidth: { xs: 360, sm: 520 },
      }}
    >
      <Tabs
        value={value}
        onChange={handleChange}
        variant="scrollable"
        scrollButtons="auto"
        aria-label="scrollable auto tabs example"
      >
        <Tab className="tagSlider me-3" label="Real State" />
        <Tab className="tagSlider me-3" label="Venture capital" />
        <Tab className="tagSlider me-3" label="Securities" />
        <Tab className="tagSlider me-3" label="Bio Pharma" />
        <Tab className="tagSlider me-3" label="Energy" />
        <Tab className="tagSlider me-3" label=" IT" />
        <Tab className="tagSlider me-3" label="Securities" />
        <Tab className="tagSlider me-3" label="Nature" />
        <Tab className="tagSlider me-3" label="Venture capital" />
        <Tab className="tagSlider me-3" label="Technology" />
      </Tabs>
    </Box>
  );
}

{
  /* </>
          <div className="container-xl text-start mt-1">
<Slider {...settings}>

    <a type="button" className="button btn btn-outline-primary p-2">
      Real State
    </a>

    <a type="button" className="button btn btn-outline-primary p-2">
      Venture capital
    </a>

    <a type="button" className="button btn btn-outline-primary p-2">
      Securities
    </a>

    <a type="button" className="button btn btn-outline-primary p-2">
      Bio Pharma
    </a>

    <a type="button" className="button btn btn-outline-primary p-2">
      Securities
    </a>

    <a type="button" className="button btn btn-outline-primary px-4 p-2">
      IT
    </a>

    <a type="button" className="button btn btn-outline-primary p-2">
      Energy
    </a>

    <a type="button" className="button btn btn-outline-primary p-2">
      Technology
    </a>

</Slider>
</div></> */
}
