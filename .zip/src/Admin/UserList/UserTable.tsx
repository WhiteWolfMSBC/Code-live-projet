import React, { ReactNode, useEffect, useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import Button from "@mui/material/Button";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import {
  Avatar,
  Box,
  IconButton,
  TableSortLabel,
  Typography,
  useTheme,
} from "@mui/material";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import CloseSharpIcon from "@mui/icons-material/CloseSharp";
import TagSlider from "./TagSlider";
import "./UserTable.css";
import { tokens } from "../../theme";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import { styled } from "@mui/system";
import TablePaginationUnstyled, {
  tablePaginationUnstyledClasses as classes,
} from "@mui/base/TablePaginationUnstyled";
import axios from "axios";
import { makeStyles } from "@material-ui/core/styles";
const LOGIN_URL = "http://192.168.71.66:5000/user_list/";

type resultProps = {
  username: string;
  name: string;
  created_on: string;
  is_active: boolean;
  user_id: number;
};

const blue = {
  200: "#A5D8FF",
  400: "#3399FF",
};

const grey = {
  50: "#f6f8fa",
  100: "#eaeef2",
  200: "#d0d7de",
  300: "#afb8c1",
  400: "#8c959f",
  500: "#6e7781",
  600: "#57606a",
  700: "#424a53",
  800: "#32383f",
  900: "#24292f",
};

const CustomTablePagination = styled(TablePaginationUnstyled)(
  ({ theme }) => `
  & .${classes.spacer} {
    display: none;
  }

  & .${classes.toolbar}  {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;

    @media (min-width: 768px) {
      flex-direction: row;
      align-items: center;
    }
  }

  & .${classes.selectLabel} {
    margin: 0;
  }

  & .${classes.select}{
    padding: 2px;
    border: 1px solid ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
    border-radius: 50px;
    background-color: transparent;
    color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};

    &:hover {
      background-color: ${theme.palette.mode === "dark" ? grey[800] : grey[50]};
    }

    &:focus {
      outline: 1px solid ${
        theme.palette.mode === "dark" ? blue[400] : blue[200]
      };
    }
  }

  & .${classes.displayedRows} {
    margin: 0;

    @media (min-width: 768px) {
      margin-left: auto;
    }
  }

  & .${classes.actions} {
    padding: 2px;
    border: 1px solid ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
    border-radius: 50px;
    text-align: center;
  }

  & .${classes.actions} > button {
    margin: 0 8px;
    border: transparent;
    border-radius: 2px;
    background-color: transparent;
    color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};

    &:hover {
      background-color: ${theme.palette.mode === "dark" ? grey[800] : grey[50]};
    }

    &:focus {
      outline: 1px solid ${
        theme.palette.mode === "dark" ? blue[400] : blue[200]
      };
    }
  }
  `
);

const useStyles: any = makeStyles((theme: any) => ({
  root: {
    width: "100%",
  },
  paper: {
    width: "100%",
    marginBottom: theme.spacing(2),
  },
  table: {
    minWidth: 750,
  },
  visuallyHidden: {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: 1,
    margin: -1,
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    top: 20,
    width: 1,
  },
}));

function descendingComparator(
  a: { [x: string]: number },
  b: { [x: string]: number },
  orderBy: string | number
) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order: string, orderBy: string) {
  return order === "desc"
    ? (a: any, b: any) => descendingComparator(a, b, orderBy)
    : (a: any, b: any) => -descendingComparator(a, b, orderBy);
}

function stableSort(
  array: any[],
  comparator: { (a: any, b: any): number; (arg0: any, arg1: any): any }
) {
  const stabilizedThis = array.map((el: any, index: any) => [el, index]);
  stabilizedThis.sort((a: number[], b: number[]) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map((el: any[]) => el[0]);
}

//  Table heading

const headCells = [
  {
    id: "name",
    numeric: true,
    disablePadding: false,
    label: "Name",
  },
  { id: "username", numeric: true, disablePadding: false, label: "UserName" },
  { id: "user_id", numeric: true, disablePadding: false, label: "UserId" },
  {
    id: "created_on",
    numeric: true,
    disablePadding: false,
    label: "Account Creation Date",
  },
  {
    id: "is_active",
    numeric: true,
    disablePadding: false,
    label: "Status",
  },
  {
    id: "",
    numeric: true,
    disablePadding: false,
    label: "Assign",
  },
];

function EnhancedTableHead(props: {
  classes: any;
  order: any;
  orderBy: any;
  onRequestSort: any;
  rowCount: any;
}) {
  const { classes, order, orderBy, onRequestSort } = props;
  const createSortHandler = (property: string) => (event: any) => {
    onRequestSort(event, property);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            className="rowtableCell"
            align="left"
            key={headCell.id}
            sortDirection={orderBy === headCell.id ? order : false}
            sx={{ backgroundColor: `${colors.primary[200]}` }}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <span className={classes.visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </span>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

export default function UserTable() {
  const classes = useStyles();
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [open, setOpen] = React.useState(false);
  const [dialog, setdialog] = React.useState<any>({});
  const [pg, setpg] = React.useState(0);
  const [rpg, setrpg] = React.useState(20);
  const [btnopen, setBtnopen] = React.useState(false);

  // User Api data Call

  const [user, setUser] = useState<resultProps[]>([]);
  console.log(user);

  const fetchData = async () => {
    try {
      const item = await axios.get(LOGIN_URL);
      console.log(item);
      setUser(item.data.Data);
      console.log(item.data.Data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleChangePage = (
    event: any,
    newpage: React.SetStateAction<number>
  ) => {
    setpg(newpage);
  };

  const handleChangeRowsPerPage = (event: { target: { value: string } }) => {
    setrpg(parseInt(event.target.value, 10));
    setpg(0);
  };

  const handleClickOpen = (row: any) => {
    console.log(row, "User List");
    setdialog(row);
    setOpen(true);
  };

  const handelBtnSaveOpen = () => {
    setBtnopen(true);
    console.log("hii");
  };

  const handelBtnSaveClose = () => {
    setBtnopen(false);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleRequestSort = (
    event: any,
    property: React.SetStateAction<string>
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | User List</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"} sx={{ m: "8px" }}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Box display={"flex"}>
            <Typography
              variant="h4"
              marginLeft={4}
              marginTop={1.5}
              color={colors.greenAccent[500]}
              className="Typography"
            >
              User List
            </Typography>

            <IconButton size="large" color="inherit">
              <KeyboardArrowLeftIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <KeyboardArrowRightIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <CloseIcon />
            </IconButton>
          </Box>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>
      </Box>

      <Box
        marginLeft={4}
        marginRight={2}
        display={"flex"}
        flexDirection="column"
      >
        <TableContainer>
          <Table stickyHeader={true} aria-label="User List Table">
            <EnhancedTableHead
              classes={classes}
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
              rowCount={user.length}
            />
            <TableBody>
              {stableSort(
                user.slice(pg * rpg, pg * rpg + rpg),
                getComparator(order, orderBy)
              ).map(
                (row: {
                  username: ReactNode;
                  user_id: ReactNode;
                  created_on: ReactNode;
                  is_active: any;
                  name: ReactNode;
                }) => {
                  return (
                    <TableRow hover>
                      <TableCell className="usertableCell" align="left">
                        {row.name}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.username}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.user_id}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.created_on}
                      </TableCell>
                      <TableCell className="usertableCell" align="left">
                        {row.is_active ? "Active" : "Inactive"}
                      </TableCell>
                      <TableCell
                        className="usertableCell"
                        onClick={() => handleClickOpen(row)}
                        align="left"
                      >
                        <BorderColorIcon />
                      </TableCell>
                    </TableRow>
                  );
                }
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Box alignSelf={"end"}>
          <CustomTablePagination
            rowsPerPageOptions={[10, 20, 30, { label: "All", value: -1 }]}
            colSpan={3}
            count={user.length}
            rowsPerPage={rpg}
            page={pg}
            slotProps={{
              select: {
                "aria-label": "UserList Pagination",
              },
              actions: {
                showFirstButton: true,
                showLastButton: true,
              } as any,
            }}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Box>
      </Box>

      {/* Dialoge Box (Model Box) */}

      <div>
        <Dialog
          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle>
            <Box display="flex" justifyContent="space-between">
              <Box></Box>
              <span onClick={handleClose}>
                <CloseSharpIcon />
              </span>
            </Box>
          </DialogTitle>

          <DialogContent>
            <DialogContentText align="left" id="alert-dialog-description">
              <div className="row">
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-xs-12 text-start">
                  <IconButton sx={{ p: 0 }}>
                    <Avatar
                      alt="Remy Sharp"
                      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmgW2DLEFPd8ci8mvSHV9iU6i2DJhxob9Pvg&usqp=CAU"
                    />
                  </IconButton>
                </div>

                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 text-start">
                  <Typography className="mt-2">
                    <span className="textFiled">User Name :-</span>
                    <span className="textFiled1 ms-1">{dialog.username}</span>
                  </Typography>
                </div>

                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12 text-end">
                  <Typography className="mt-2">
                    <span className="textFiled">User ID :-</span>
                    <span className="textFiled1 ms-1">{dialog.user_id}</span>
                  </Typography>
                </div>
              </div>

              <Box
                display="flex"
                justifyContent="space-between"
                className="mt-4"
              >
                <Typography className="textFiled">
                  Specialization Assignment
                </Typography>
              </Box>

              {/* Tag Slider */}

              <TagSlider />

              <Box className="text-center mt-3">
                <Button
                  sx={{
                    color: `${colors.grey[900]}`,
                  }}
                  variant="outlined"
                  color="success"
                  className="outlinebtn"
                >
                  Assign as Analyst
                </Button>

                <Button
                  sx={{
                    color: `${colors.grey[900]}`,
                  }}
                  variant="contained"
                  color="success"
                  className="ms-5 FilledBtn"
                  onClick={handelBtnSaveOpen}
                >
                  Save Changes
                </Button>
              </Box>
            </DialogContentText>
          </DialogContent>
        </Dialog>

        {/* Savebtn Dialog Box */}

        <Dialog
          open={btnopen}
          onClose={handelBtnSaveClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle>
            <Box display="flex" justifyContent="space-between">
              <Box></Box>
              <span onClick={handelBtnSaveClose}>
                <CloseSharpIcon />
              </span>
            </Box>
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              Let Google help apps determine location. This means sending
              anonymous location data to Google, even when no apps are running.
            </DialogContentText>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
