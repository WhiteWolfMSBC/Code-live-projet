import * as React from "react";
import "../AdminSetting.css";
import Box from "@mui/material/Box";
import {
  Button,
  Card,
  IconButton,
  Typography,
  useTheme,
} from "@mui/material";
import { tokens } from "../../../theme";
import { Menu, MenuItem, ProSidebar } from "react-pro-sidebar";
import "react-pro-sidebar/dist/css/styles.css";
import SettingsIcon from "@mui/icons-material/Settings";
import PersonIcon from "@mui/icons-material/Person";
import LockIcon from "@mui/icons-material/Lock";
import NotificationsIcon from "@mui/icons-material/Notifications";
import PaymentIcon from "@mui/icons-material/Payment";
import { Link } from 'react-router-dom';
import { Helmet } from "react-helmet";
import TopBar from "../../../components/global/TopBar";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";

function Profile() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const styles = {
    sideBarHeight: {
      height: "800px",
      backgroundColor: `${colors.primary[400]}`,
    },
    menuIcon: {
      float: "right",
      margin: "10px",
    },
  };

  return (
    <>


           {/* Browser Title */}

           <Helmet>
        <title>IdeaVenu | Admin Settings | Profile</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"} sx={{ m: "8px" }}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Box display={"flex"}>
            <Typography
              variant="h4"
              marginLeft={4}
              marginTop={1.5}
              color={colors.greenAccent[500]}
              className="Typography"
            >
              Seetings
            </Typography>

            <IconButton size="large" color="inherit">
              <KeyboardArrowLeftIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <KeyboardArrowRightIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <CloseIcon />
            </IconButton>
          </Box>
        </Box>

        <Box display={"flex"} p={1.5}>
          <Button
            className="PlatformBtn"
            sx={{
              color: `${colors.grey[900]}`,
            }}
            variant="outlined"
            color="success"
          >
            Platform Roles
          </Button>

          <TopBar />
        </Box>
      </Box>


      {/* Body */}

           <Box marginLeft={6} marginTop={1.5} marginRight={2}>
        <Box>
          <div className="row">
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{ backgroundColor: `${colors.primary[400]}` }}
                  variant="outlined"
                >
                  <ProSidebar style={styles.sideBarHeight}>
                  <Menu>
                    <Link to='/generalsetting'>
                      <MenuItem className="Items1" icon={<SettingsIcon />}>
                        General Setting
                      </MenuItem></Link> 

                      <Link to='/profile'>
                      <MenuItem className="Items1" icon={<PersonIcon />}>
                        Profile 
                      </MenuItem></Link>

                      <Link to='/password'>
                      <MenuItem className="Items1" icon={<LockIcon />}>
                        Password
                      </MenuItem></Link> 

                      <Link to='/notification'>
                      <MenuItem className="Items1" icon={<NotificationsIcon />}>
                        Notification
                      </MenuItem></Link> 

                      <Link to='/billing'>
                      <MenuItem className="Items1" icon={<PaymentIcon />}>
                        Billing
                      </MenuItem></Link> 
                    </Menu>
                  </ProSidebar>
                </Card>
              </Box>
            </div>

            {/* 2nd Card */}

            <div className="col-xl-10 col-lg-10 col-md-10 col-sm-6 col-xs-12">
              <Box sx={{ height: "830px"}}>
                  I m from Profile Component
              </Box>
            </div>
          </div>
        </Box>
      </Box>
    </>
  )
}

export default Profile
