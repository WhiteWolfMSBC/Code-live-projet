import * as React from "react";
import "../AdminSetting.css";
import Box from "@mui/material/Box";
import { Button, Card, IconButton, Typography, useTheme } from "@mui/material";
import { tokens } from "../../../theme";
import { Menu, MenuItem, ProSidebar } from "react-pro-sidebar";
import "react-pro-sidebar/dist/css/styles.css";
import SettingsIcon from "@mui/icons-material/Settings";
import PersonIcon from "@mui/icons-material/Person";
import LockIcon from "@mui/icons-material/Lock";
import NotificationsIcon from "@mui/icons-material/Notifications";
import PaymentIcon from "@mui/icons-material/Payment";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import TopBar from "../../../components/global/TopBar";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";

function GeneralSetting() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const styles = {
    sideBarHeight: {
      height: "800px",
      backgroundColor: `${colors.primary[400]}`,
    },
    menuIcon: {
      float: "right",
      margin: "10px",
    },
  };

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Admin Settings | General Setting</title>
      </Helmet>

      {/* 2nd Card */}

      <div className="col-xl-10 col-lg-10 col-md-10 col-sm-6 col-xs-12">
        <Box sx={{ height: "830px" }}>I m from General Component Component</Box>
      </div>
    </>
  );
}

export default GeneralSetting;
