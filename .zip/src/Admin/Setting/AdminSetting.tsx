import * as React from "react";
import "./AdminSetting.css";
import Box from "@mui/material/Box";
import { Button, IconButton, Typography, useTheme } from "@mui/material";
import { tokens } from "../../theme";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import { Card, Stack } from "@mui/material";
import { Menu, MenuItem, ProSidebar } from "react-pro-sidebar";
import "react-pro-sidebar/dist/css/styles.css";
import SettingsIcon from "@mui/icons-material/Settings";
import PersonIcon from "@mui/icons-material/Person";
import LockIcon from "@mui/icons-material/Lock";
import NotificationsIcon from "@mui/icons-material/Notifications";
import PaymentIcon from "@mui/icons-material/Payment";
import { styled } from "@mui/material/styles";
import FormGroup from "@mui/material/FormGroup";
import Switch from "@mui/material/Switch";
import { Link } from "react-router-dom";
import { useState } from "react";
import GeneralSetting from "./Settingsidebar/GeneralSetting";
import Profile from "./Settingsidebar/Profile";
import Password from "./Settingsidebar/Password";
import Notification from "./Settingsidebar/Notification";
import Billing from "./Settingsidebar/Billing";

export default function AdminSetting() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [generalSetting, setgeneralSetting] = useState(false);
  const [profile, setprofile] = useState(false);
  const [password, setpassword] = useState(false);
  const [notification, setnotification] = useState(false);
  const [billing, setbilling] = useState(false);

  const styles = {
    sideBarHeight: {
      height: "800px",
      backgroundColor: `${colors.primary[400]}`,
    },
    menuIcon: {
      float: "right",
      margin: "10px",
    },
  };

  const Switchbutton = styled(Switch)(({}) => ({
    padding: 8,
    "& .MuiSwitch-track": {
      borderRadius: 22,
      opacity: "1 !important",
      backgroundcolor: `${colors.greenAccent[500]} !important`,
      "&:before, &:after": {
        position: "absolute",
        top: "50%",
        transform: "translateY(-50%)",
        width: 40,
        height: 21,
        backgroundColor: `${colors.grey[400]} !important`,
      },
    },
    "& .MuiSwitch-thumb": {
      boxShadow: "none",
      width: 16,
      height: 16,
      margin: 2,
      color: `${colors.grey[400]}`,
    },
  }));

  return (
    <>
      {/* Browser Title */}

      <Helmet>
        <title>IdeaVenu | Admin Settings</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"} sx={{ m: "8px" }}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Box display={"flex"}>
            <Typography
              variant="h4"
              marginLeft={4}
              marginTop={1.5}
              color={colors.greenAccent[500]}
              className="Typography"
            >
              Settings
            </Typography>

            <IconButton size="large" color="inherit">
              <KeyboardArrowLeftIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <KeyboardArrowRightIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <CloseIcon />
            </IconButton>
          </Box>
        </Box>

        <Box display={"flex"} p={1.5}>
          <Button
            className="PlatformBtn"
            sx={{
              color: `${colors.grey[900]}`,
            }}
            variant="outlined"
            color="success"
          >
            Platform Roles
          </Button>

          <TopBar />
        </Box>
      </Box>

      <Box marginLeft={6} marginTop={1.5} marginRight={2}>
        <Box>
          <div className="row">
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-xs-12">
              <Box sx={{}}>
                <Card
                  className="colorCard"
                  sx={{ backgroundColor: `${colors.primary[400]}` }}
                  variant="outlined"
                >
                  <ProSidebar style={styles.sideBarHeight}>
                    <Menu>
                      <MenuItem
                        className="Items1"
                        icon={<SettingsIcon />}
                        onClick={() => {
                          setgeneralSetting(true);
                        }}
                      >
                        General Setting
                      </MenuItem>

                      <Link to="/profile">
                        <MenuItem className="Items1" icon={<PersonIcon />}>
                          Profile
                        </MenuItem>
                      </Link>

                      <Link to="/password">
                        <MenuItem className="Items1" icon={<LockIcon />}>
                          Password
                        </MenuItem>
                      </Link>

                      <Link to="/notification">
                        <MenuItem
                          className="Items1"
                          icon={<NotificationsIcon />}
                        >
                          Notification
                        </MenuItem>
                      </Link>

                      <Link to="/billing">
                        <MenuItem className="Items1" icon={<PaymentIcon />}>
                          Billing
                        </MenuItem>
                      </Link>
                    </Menu>
                  </ProSidebar>
                </Card>
              </Box>
            </div>

            {/* 2nd Card */}
            <div className="col-xl-10 col-lg-10 col-md-10 col-sm-6 col-xs-12">
              <Box sx={{ height: "830px" }}>
                <Card
                  className="colorCard"
                  sx={{
                    backgroundColor: `${colors.primary[400]}`,
                  }}
                  variant="outlined"
                >
                  <Typography
                    variant="h4"
                    marginLeft={4}
                    marginTop={8}
                    color={colors.greenAccent[500]}
                    className="Typography"
                  >
                    Notifications
                  </Typography>

                  <Typography
                    variant="h4"
                    marginLeft={4}
                    marginTop={1.5}
                    color={colors.grey[900]}
                    className="txtTypography"
                  >
                    Select the kinds of notifications you get about your
                    activities and recommendations.
                  </Typography>

                  {/* Row */}

                  <Box marginLeft={4} marginTop={5}>
                    <div className="row">
                      <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <Box alignSelf={"start"}>
                          <Typography
                            variant="h4"
                            color={colors.grey[900]}
                            className="Typography"
                          >
                            Email notifications
                          </Typography>

                          <Typography
                            variant="h4"
                            marginTop={2}
                            color={colors.grey[900]}
                            className="txtTypography"
                          >
                            Get email to find out what's going on when you're
                            not online. You can turn these off.
                          </Typography>
                        </Box>

                        <Box
                          alignSelf={"start"}
                          marginTop={24}
                          marginBottom={39}
                        >
                          <Typography
                            variant="h4"
                            color={colors.grey[900]}
                            className="Typography"
                          >
                            Push notifications
                          </Typography>

                          <Typography
                            variant="h4"
                            marginTop={2}
                            color={colors.grey[900]}
                            className="txtTypography"
                          >
                            Get push notifications in-app to find out what's
                            going on when you're online.
                          </Typography>
                        </Box>
                      </div>

                      <div className="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-xs-12"></div>

                      <div className="col-xl-5 col-lg-5 col-md-5 col-sm-6 col-xs-12">
                        {/* 1 Switch button */}
                        <FormGroup>
                          <Stack direction="row" spacing={2}>
                            <Switchbutton color="secondary" defaultChecked />
                            <Box display="flex" flexDirection="column">
                              <Typography className="switchtxt">
                                News and updates
                              </Typography>
                              <Typography className="switchtxt1">
                                News about product and feature updates.
                              </Typography>
                            </Box>
                          </Stack>
                        </FormGroup>

                        {/* 2 Switch button */}
                        <FormGroup>
                          <Stack direction="row" marginTop={3} spacing={2}>
                            <Switchbutton color="secondary" defaultChecked />
                            <Box display="flex" flexDirection="column">
                              <Typography className="switchtxt">
                                Tips and tutorials
                              </Typography>
                              <Typography className="switchtxt1">
                                Tips on getting more out of untitled.
                              </Typography>
                            </Box>
                          </Stack>
                        </FormGroup>

                        {/* 3 Switch button */}
                        <FormGroup>
                          <Stack direction="row" marginTop={3} spacing={2}>
                            <Switchbutton color="secondary" defaultChecked />
                            <Box display="flex" flexDirection="column">
                              <Typography className="switchtxt">
                                User research
                              </Typography>
                              <Typography className="switchtxt1">
                                Get involved in our beta testing research.
                              </Typography>
                            </Box>
                          </Stack>
                        </FormGroup>

                        {/* 4 Switch button */}
                        <FormGroup>
                          <Stack direction="row" marginTop={3} spacing={2}>
                            <Switchbutton color="secondary" />
                            <Box display="flex" flexDirection="column">
                              <Typography className="switchtxt">
                                Reminders
                              </Typography>
                              <Typography className="switchtxt1">
                                These are notifications to remaind you of
                                updates you might have missed.
                              </Typography>
                            </Box>
                          </Stack>
                        </FormGroup>

                        {/* 5 Switch button */}
                        <FormGroup>
                          <Stack direction="row" marginTop={3} spacing={2}>
                            <Switchbutton color="secondary" />
                            <Box display="flex" flexDirection="column">
                              <Typography className="switchtxt">
                                One Idea per Day
                              </Typography>
                              <Typography className="switchtxt1">
                                Lorem ipsum dolor, sit amet.
                              </Typography>
                            </Box>
                          </Stack>
                        </FormGroup>

                        {/* 6 Switch button */}
                        <FormGroup>
                          <Stack direction="row" marginTop={3} spacing={2}>
                            <Switchbutton color="secondary" defaultChecked />
                            <Box display="flex" flexDirection="column">
                              <Typography className="switchtxt">
                                Thematic Baskets
                              </Typography>
                              <Typography className="switchtxt1">
                                Lorem ipsum dolor, sit amet.
                              </Typography>
                            </Box>
                          </Stack>
                        </FormGroup>

                        {/* 7 Switch button */}
                        <FormGroup>
                          <Stack direction="row" marginTop={3} spacing={2}>
                            <Switchbutton color="secondary" />
                            <Box display="flex" flexDirection="column">
                              <Typography className="switchtxt">
                                Watch List
                              </Typography>
                              <Typography className="switchtxt1">
                                Lorem ipsum dolor, sit amet.
                              </Typography>
                            </Box>
                          </Stack>
                        </FormGroup>
                      </div>

                      <div className="col-xl-1 col-lg-1 col-md-1 col-sm-6 col-xs-12"></div>
                    </div>
                  </Box>
                </Card>
              </Box>
            </div>
          </div>
        </Box>
      </Box>
    </>
  );
}
