import React, { ReactNode, useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import Button from "@mui/material/Button";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import {
  Avatar,
  Box,
  IconButton,
  TableSortLabel,
  Typography,
  useTheme,
} from "@mui/material";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import CloseSharpIcon from "@mui/icons-material/CloseSharp";
import TagSlider from "../UserList/TagSlider";
import "./AnalystTable.css";
import { tokens } from "../../theme";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";
import { makeStyles } from "@material-ui/core/styles";
import TopBar from "../../components/global/TopBar";
import { Helmet } from "react-helmet";
import { styled } from "@mui/system";
import TablePaginationUnstyled, {
  tablePaginationUnstyledClasses as classes,
} from "@mui/base/TablePaginationUnstyled";
import TaskAltIcon from "@mui/icons-material/TaskAlt";

function createData(
  name: string,
  billing: string,
  AnalystAssignment: string,
  Supervisary: string,
  Region: string,
  Sector: string,
  IdeaOfTheday: string,
  ExecutionIdea: string,
  ThematicBasket: string,
  PeerGroup: string,
  assign: any
) {
  return {
    name,
    billing,
    AnalystAssignment,
    Supervisary,
    Region,
    Sector,
    IdeaOfTheday,
    ExecutionIdea,
    ThematicBasket,
    PeerGroup,
    assign,
  };
}

const rows = [
  createData(
    "arozen yoghurt",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "bce cream sandwich",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "cclair",
    "Yes",
    "NO",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "dupcake",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "eingerbread",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "frozen yoghurt",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "gce cream sandwich",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "hclair",
    "Yes",
    "NO",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "iupcake",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "jingerbread",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "krozen yoghurt",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "lce cream sandwich",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "mclair",
    "Yes",
    "NO",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "nrozen yoghurt",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "orozen yoghurt",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "pce cream sandwich",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "qclair",
    "Yes",
    "NO",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "rupcake",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "singerbread",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "trozen yoghurt",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "uce cream sandwich",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "vclair",
    "Yes",
    "NO",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "wupcake",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "Ravi Sachin Saurabh ",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "yrozen yoghurtnioikgfvbo",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "zce cream sandwich",
    "NO",
    "Yes",
    "Yes",
    "Europe",
    "All",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "eclair",
    "Yes",
    "NO",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
  createData(
    "frozen yoghurt",
    "Yes",
    "Yes",
    "Yes",
    "All",
    "Technology",
    "Yes",
    "Yes",
    "Yes",
    "Yes",
    <BorderColorIcon />
  ),
];

const blue = {
  200: "#A5D8FF",
  400: "#3399FF",
};

const grey = {
  50: "#f6f8fa",
  100: "#eaeef2",
  200: "#d0d7de",
  300: "#afb8c1",
  400: "#8c959f",
  500: "#6e7781",
  600: "#57606a",
  700: "#424a53",
  800: "#32383f",
  900: "#24292f",
};

const CustomTablePagination = styled(TablePaginationUnstyled)(
  ({ theme }) => `
  & .${classes.spacer} {
    display: none;
  }

  & .${classes.toolbar}  {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;

    @media (min-width: 768px) {
      flex-direction: row;
      align-items: center;
    }
  }

  & .${classes.selectLabel} {
    margin: 0;
  }

  & .${classes.select}{
    padding: 2px;
    border: 1px solid ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
    border-radius: 50px;
    background-color: transparent;
    color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};

    &:hover {
      background-color: ${theme.palette.mode === "dark" ? grey[800] : grey[50]};
    }

    &:focus {
      outline: 1px solid ${
        theme.palette.mode === "dark" ? blue[400] : blue[200]
      };
    }
  }

  & .${classes.displayedRows} {
    margin: 0;

    @media (min-width: 768px) {
      margin-left: auto;
    }
  }

  & .${classes.actions} {
    padding: 2px;
    border: 1px solid ${theme.palette.mode === "dark" ? grey[800] : grey[200]};
    border-radius: 50px;
    text-align: center;
  }

  & .${classes.actions} > button {
    margin: 0 8px;
    border: transparent;
    border-radius: 2px;
    background-color: transparent;
    color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};

    &:hover {
      background-color: ${theme.palette.mode === "dark" ? grey[800] : grey[50]};
    }

    &:focus {
      outline: 1px solid ${
        theme.palette.mode === "dark" ? blue[400] : blue[200]
      };
    }
  }
  `
);

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  paper: {
    width: "100%",
    marginBottom: theme.spacing(2),
  },
  table: {
    minWidth: 750,
  },
  visuallyHidden: {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: 1,
    margin: -1,
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    top: 20,
    width: 1,
  },
}));

function descendingComparator(
  a: { [x: string]: number },
  b: { [x: string]: number },
  orderBy: string | number
) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order: string, orderBy: string) {
  return order === "desc"
    ? (a: any, b: any) => descendingComparator(a, b, orderBy)
    : (a: any, b: any) => -descendingComparator(a, b, orderBy);
}

function stableSort(
  array: any[],
  comparator: { (a: any, b: any): number; (arg0: any, arg1: any): any }
) {
  const stabilizedThis = array.map((el: any, index: any) => [el, index]);
  stabilizedThis.sort((a: number[], b: number[]) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map((el: any[]) => el[0]);
}

//  Table heading

const headCells = [
  {
    id: "name",
    numeric: false,
    disablePadding: true,
    label: "Analyst Name",
  },
  { id: "billing", numeric: true, disablePadding: false, label: "Billing" },
  {
    id: "AnalystAssignment",
    numeric: true,
    disablePadding: false,
    label: "Analyst Assignment",
  },
  {
    id: "Supervisary",
    numeric: true,
    disablePadding: false,
    label: "Supervisary",
  },
  { id: "Region", numeric: true, disablePadding: false, label: "Region" },
  { id: "Sector", numeric: true, disablePadding: false, label: "Sector" },
  {
    id: "IdeaOfTheDay",
    numeric: true,
    disablePadding: false,
    label: "Idea Of The Day",
  },
  {
    id: "Execution Idea",
    numeric: true,
    disablePadding: false,
    label: "Execution Idea",
  },
  {
    id: "Thematic Basket",
    numeric: true,
    disablePadding: false,
    label: "Thematic Basket",
  },
  {
    id: "proPeer Grouptein",
    numeric: true,
    disablePadding: false,
    label: "Peer Group",
  },
  {
    id: "proPeer Grouptein",
    numeric: true,
    disablePadding: false,
    label: "",
  },
];

function EnhancedTableHead(props: {
  classes: any;
  order: any;
  orderBy: any;
  onRequestSort: any;
  rowCount: any;
}) {
  const {
    classes,

    order,
    orderBy,

    onRequestSort,
  } = props;
  const createSortHandler = (property: string) => (event: any) => {
    onRequestSort(event, property);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            className="rowtableCell"
            align="left"
            key={headCell.id}
            sortDirection={orderBy === headCell.id ? order : false}
            sx={{ backgroundColor: `${colors.primary[200]}` }}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <span className={classes.visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </span>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

export default function UserTable() {
  const classes = useStyles();
  const [order, setOrder] = useState("asc");
  const [orderBy, setOrderBy] = useState("calories");
  const [open, setOpen] = useState(false);
  const [dialog, setdialog] = useState<any>({});
  const [pg, setpg] = useState(0);
  const [rpg, setrpg] = useState(18);
  const [btnopen, setBtnopen] = React.useState(false);

  const handelBtnSaveOpen = () => {
    setBtnopen(true);
    console.log("hii");
  };

  const handelBtnSaveClose = () => {
    setBtnopen(false);
  };

  const handleChangePage = (
    event: any,
    newpage: React.SetStateAction<number>
  ) => {
    setpg(newpage);
  };

  const handleChangeRowsPerPage = (event: { target: { value: string } }) => {
    setrpg(parseInt(event.target.value, 10));
    setpg(0);
  };

  const handleClickOpen = (row: any) => {
    console.log(row, "Sachin");
    setdialog(row);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleRequestSort = (
    event: any,
    property: React.SetStateAction<string>
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <>
      <Helmet>
        <title>IdeaVenu | Analyst List</title>
      </Helmet>

      <Box display="flex" justifyContent={"space-between"} sx={{ m: "8px" }}>
        <Box display="inline-block" padding={"20px 8px 20px 8px"}>
          <Box display={"flex"}>
            <Typography
              variant="h4"
              marginLeft={4}
              marginTop={1.5}
              color={colors.greenAccent[500]}
              className="Typography"
            >
              Analyst List
            </Typography>

            <IconButton size="large" color="inherit">
              <KeyboardArrowLeftIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <KeyboardArrowRightIcon />
            </IconButton>

            <IconButton size="large" color="inherit">
              <CloseIcon />
            </IconButton>
          </Box>
        </Box>

        <Box display={"flex"} p={1.5}>
          <TopBar />
        </Box>
      </Box>

      <Box
        marginLeft={4}
        marginRight={2}
        display={"flex"}
        flexDirection="column"
      >
        <TableContainer>
          <Table stickyHeader={true} aria-label="Analyst List Table">
            <EnhancedTableHead
              classes={classes}
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
              rowCount={rows.length}
            />
            <TableBody>
              {stableSort(
                rows.slice(pg * rpg, pg * rpg + rpg),
                getComparator(order, orderBy)
              ).map(
                (row: {
                  name: ReactNode;
                  IdeaOfTheday: ReactNode;
                  Sector: ReactNode;
                  Region: ReactNode;
                  Supervisary: ReactNode;
                  AnalystAssignment: ReactNode;
                  billing: ReactNode;
                  ExecutionIdea: ReactNode;
                  ThematicBasket: ReactNode;
                  PeerGroup: ReactNode;
                  assign: ReactNode;
                }) => {
                  return (
                    <TableRow hover>
                      <TableCell className="TableBody" align="left">
                        {row.name}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.billing}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.AnalystAssignment}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.Supervisary}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.Region}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.Sector}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.IdeaOfTheday}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.ExecutionIdea}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.ThematicBasket}
                      </TableCell>
                      <TableCell className="TableBody" align="left">
                        {row.PeerGroup}
                      </TableCell>
                      <TableCell
                        className="TableBody"
                        onClick={() => handleClickOpen(row)}
                        align="left"
                      >
                        {row.assign}
                      </TableCell>
                    </TableRow>
                  );
                }
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <Box alignSelf={"end"}>
          <CustomTablePagination
            rowsPerPageOptions={[20, 30, 40, { label: "All", value: -1 }]}
            colSpan={3}
            count={rows.length}
            rowsPerPage={rpg}
            page={pg}
            slotProps={{
              select: {
                "aria-label": "UserList Pagination",
              },
              actions: {
                showFirstButton: true,
                showLastButton: true,
              } as any,
            }}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Box>
      </Box>

      {/* Dialoge Box (Model Box) */}

      <div>
        <Dialog
          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle>
            <Box display="flex" justifyContent="space-between">
              <Box></Box>
              <span onClick={handleClose}>
                <CloseSharpIcon />
              </span>
            </Box>
          </DialogTitle>

          <DialogContent>
            <DialogContentText align="left" id="alert-dialog-description">
              <div className="row">
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-6 col-xs-12 text-start">
                  <IconButton sx={{ p: 0 }}>
                    <Avatar
                      alt="Remy Sharp"
                      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmgW2DLEFPd8ci8mvSHV9iU6i2DJhxob9Pvg&usqp=CAU"
                    />
                  </IconButton>
                </div>

                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 text-start">
                  <Typography className="mt-2">
                    <span className="textFiled">User Name :-</span>
                    <span className="textFiled1 ms-1">{dialog.name}</span>
                  </Typography>
                </div>

                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12 text-end">
                  <Typography className="mt-2">
                    <span className="textFiled">User ID :-</span>
                    <span className="textFiled1 ms-1">15839843</span>
                  </Typography>
                </div>
              </div>

              <Box
                display="flex"
                justifyContent="space-between"
                className="mt-4"
              >
                <Typography className="textFiled">
                  Specialization Assignment
                </Typography>
              </Box>

              {/* Tag Slider */}

              <TagSlider />

              <Box className="text-center mt-3">
                <div className="row">
                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography align="center" className="textFiled">
                      Ideas of The Day
                    </Typography>
                    <Typography align="center" className="Modeltext">
                      0
                    </Typography>
                  </div>

                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography align="center" className="textFiled">
                      ThematicBaskets
                    </Typography>
                    <Typography align="center" className="Modeltext">
                      0
                    </Typography>
                  </div>

                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography align="center" className="textFiled">
                      PeerGroup
                    </Typography>
                    <Typography align="center" className="Modeltext">
                      0
                    </Typography>
                  </div>

                  <div className="col-xl-3 col-lg-2 col-md-1 col-xs-10 col-sm-12">
                    <Typography align="center" className="textFiled">
                      TradeExecutionIdea
                    </Typography>
                    <Typography align="center" className="Modeltext">
                      0
                    </Typography>
                  </div>
                </div>
              </Box>

              <Box className="text-center mt-3">
                <Button
                  sx={{
                    color: `${colors.grey[900]}`,
                  }}
                  variant="outlined"
                  color="success"
                  className={"outlineBtn"}
                >
                  Assign as SuperAnalyst
                </Button>

                <Button
                  sx={{
                    color: `${colors.grey[900]}`,
                  }}
                  variant="contained"
                  color="success"
                  onClick={handelBtnSaveOpen}
                  className={"outlineBtn"}
                >
                  Save Changes
                </Button>
              </Box>
            </DialogContentText>
          </DialogContent>
        </Dialog>

        {/* Savebtn Dialog Box */}

        <Dialog
          open={btnopen}
          onClose={handelBtnSaveClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
          sx={{ background: "#1717171" }}
        >
          <DialogTitle>
            <Box display="flex" justifyContent="center">
              <TaskAltIcon
                fontSize="large"
                sx={{ color: `${colors.greenAccent[500]}`, fontSize: "60px" }}
              />
            </Box>
          </DialogTitle>
          <DialogContent>
            <DialogContentText
              display="flex"
              justifyContent="center"
              flexDirection="column"
              id="alert-dialog-description"
            >
              <Typography sx={{ color: `${colors.grey[900]}` }}>
                Successfully added User's Profession
              </Typography>

              <Button
                sx={{
                  color: `${colors.grey[900]}`,
                }}
                variant="contained"
                color="success"
                className="FilledBtn ms-3"
                onClick={handelBtnSaveClose}
              >
                Close
              </Button>
            </DialogContentText>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
