import { Box, FormControl, TextField, useTheme } from "@mui/material";
import React, { useState } from "react";
import { tokens } from "../theme";
import "./Video.css";
import ReactPlayer from "react-player";

function Video() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [urlData, seturlData] = useState("");

  const handleChange = (event: any) => {
    seturlData(event.target.value);
  };

  // video

  const [play, setPlay] = useState(false);
  const handleMouseEnter = () => {
    setPlay(true);
  };
  const handleMouseLeave = () => {
    setPlay(false);
  };
  return (
    <div>
      {/* Textfield */}

      <Box>
        <FormControl variant="filled" size="small" className="field-container">
          <TextField
            required
            value={urlData}
            onChange={handleChange}
            id="emailId"
            variant="filled"
            label="Add Video URL in editor, drop a previw image here"
            placeholder="&#x2709;"
            type="text"
            size="small"
            sx={{
              backgroundColor: `${colors.primary[400]}`,
              borderRadius: "10px",
              margin: "auto",

              "& .MuiInputBase-root": {
                fontSize: "18px",
                color: `${colors.grey[900]}`,
              },
              "& .MuiFilledInput-input": {
                color: `${colors.grey[400]} !important`,
              },
            }}
          />
        </FormControl>

        {/* Video */}

        <Box onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          <ReactPlayer
            width={"100%"}
            height={"600px"}
            playing={play}
            pip
            controls={true}
            config={{ file: { forceHLS: true } }}
            url={urlData}
          />
        </Box>
      </Box>
    </div>
  );
}

export default Video;
