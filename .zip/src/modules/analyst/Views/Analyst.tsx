import { Typography } from '@mui/material'
import React from 'react';
function Analyst() {
  return (
    <Typography variant='h3' align='center'>This is Analyst page</Typography>
  )
}

export default Analyst;