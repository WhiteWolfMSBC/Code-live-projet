import { Typography } from '@mui/material'
import React from 'react'

function Admin() {
  return (
    <Typography variant='h3' align='center'>This is Admin page</Typography>
  )
}

export default Admin;