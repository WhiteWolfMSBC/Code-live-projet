import { Typography, useTheme } from "@mui/material";
import React from "react";
import { tokens } from "../../../../theme";

const SentimentAnalysis = () =>{
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    return <Typography variant='h4' marginLeft={2} color={colors.greenAccent[500]}>SentimentAnalysis</Typography>
}
export default SentimentAnalysis;