import { CssBaseline, ThemeProvider, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { Route, Routes } from 'react-router-dom';
import Sidebar from '../../../components/global/SideBar';
import TopBar from '../../../components/global/TopBar';
import { ColorModeContext, useMode } from '../../../theme';
import Dashboard from './Dashboard/Dashboard';

function User() {
  const [theme,colorMode] = useMode();
  const [isCollapsed, setIsCollapsed] = useState(true);
  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline/>
        <div className="app">
          <Sidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed}/>
          <main className='content'>  
            <TopBar/>
            <Routes>
              <Route path='/user/dashboard' element={<Dashboard/>}></Route>
            </Routes>
          </main>
        </div>
      </ThemeProvider>
    </ColorModeContext.Provider>
  )
}

export default User;