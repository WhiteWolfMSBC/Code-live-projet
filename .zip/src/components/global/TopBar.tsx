import {Box, IconButton, Typography, useTheme} from '@mui/material';
import React, { useState } from 'react';
import { useContext } from 'react';
import { ColorModeContext, tokens } from '../../theme';
import InputBase from '@mui/material/InputBase';
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
// import { height, minHeight } from '@mui/system';
import Popover from '@mui/material/Popover';




const TopBar = ()=>{
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const [anchorNotify, setAnchorNotify] = React.useState<HTMLButtonElement | null>(null);
    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorNotify(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorNotify(null);
    };

  const open = Boolean(anchorNotify);
  const id_notify = open ? 'simple-popover' : undefined;
    return (    
        <Box display="flex" justifyContent={'space-between'} sx={{ m:'8px'}}>

            <Box display={'flex'}>
                <Box display='flex' p={1.5}>
                    <IconButton onClick={colorMode.toggleColorMode} sx={{borderRadius:'8px',border:'2px solid #555',margin:'4px'}}>
                        {theme.palette.mode === 'dark' ?(<DarkModeOutlinedIcon/>):(<LightModeOutlinedIcon/>)}
                    </IconButton>
                    <IconButton sx={{borderRadius:'8px',border:'2px solid #555',margin:'4px'}} >
                        <EmailOutlinedIcon></EmailOutlinedIcon>
                    </IconButton>
                    <Popover
                        id={id_notify}
                        open={open}
                        anchorEl={anchorNotify}
                        onClose={handleClose}
                        anchorOrigin={{
                          vertical: 'bottom',
                          horizontal: 'left',
                        }}
                    >
                        <Typography sx={{ p: 2 }}>This is popover for Mail</Typography>
                    </Popover>
                    <IconButton sx={{borderRadius:'8px',border:'2px solid #555',margin:'4px'}} aria-describedby={id_notify} onClick={handleClick}>
                            <NotificationsOutlinedIcon></NotificationsOutlinedIcon>
                    </IconButton>
                    <Popover
                        id={id_notify}
                        open={open}
                        anchorEl={anchorNotify}
                        onClose={handleClose}
                        anchorOrigin={{
                          vertical: 'bottom',
                          horizontal: 'left',
                        }}
                    >
                        <Typography sx={{ p: 2,cursor:'pointer' }}>This is popover for notification</Typography>
                    </Popover>
                </Box>
                <Box display='flex' textAlign="center" p={1}>
                    <Box >
                        <Typography
                        variant="h6"
                        color={colors.grey[100]}
                        fontWeight="bold"
                        sx={{ m: "4px 4px 0 0" }}
                        >
                            Robert Sally
                        </Typography>
                        <Typography variant="h6" color={colors.grey[500]} sx={{ m: "2px 4px 0 0" }}>
                            User ID: 15789216
                        </Typography>
                    </Box>
                    <Box display="flex" justifyContent="center" alignItems="center">
                        <img
                        alt="user"
                        width="40px"
                        height="40px"
                        src={`https://th.bing.com/th/id/OIP.puMo9ITfruXP8iQx9cYcqwHaGJ?pid=ImgDet&rs=1`}
                        style={{ cursor: "pointer", borderRadius: "50%" }}
                        />
                    </Box>
                </Box>
            </Box>
        </Box>
    )
}

export default TopBar;