import React,{ useRef, useState } from "react";
import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
import { Box, IconButton, Typography, useTheme } from "@mui/material";
import { Link } from "react-router-dom";
import "react-pro-sidebar/dist/css/styles.css";
import { tokens } from "../../theme";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";
import BarChartOutlinedIcon from "@mui/icons-material/BarChartOutlined";
import PieChartOutlineOutlinedIcon from "@mui/icons-material/PieChartOutlineOutlined";
import TimelineOutlinedIcon from "@mui/icons-material/TimelineOutlined";
import MapOutlinedIcon from "@mui/icons-material/MapOutlined";
import ArrowCircleRightRoundedIcon from '@mui/icons-material/ArrowCircleRightRounded';
import ArrowCircleLeftRoundedIcon from '@mui/icons-material/ArrowCircleLeftRounded';
import LanguageRoundedIcon from '@mui/icons-material/LanguageRounded';
import AutoAwesomeMosaicIcon from '@mui/icons-material/AutoAwesomeMosaic';
import DataThresholdingIcon from '@mui/icons-material/DataThresholding';
import SearchIcon from "@mui/icons-material/Search";
import InputBase from '@mui/material/InputBase';
import FavoriteBorderOutlinedIcon from '@mui/icons-material/FavoriteBorderOutlined';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';
import useClickOutside from "../../hooks/useClickOutside";
import "./Sidebar.css";

const Item = ({ title, to, icon, selected, setSelected }:any):any => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <MenuItem
      active={selected === title}
      style={{
        color: colors.grey[100],
      }}
      onClick={() => setSelected(title)}
      icon={icon}
    >
      <Typography>{title}</Typography>
      <Link to={to} />
    </MenuItem>
  );
};

const Sidebar = (props:any) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [selected, setSelected] = useState("dashboard");
  const searchRef:any = useRef(null);
  const inline = {
      display:"flex" ,
      justifyContent:"center" ,
      backgroundColor:colors.primary[500],
      borderRadius:"8px",
      marginLeft:'10px',
      marginRight:'10px',
  }

  const handleClick = ()=>{
    props.setIsCollapsed(!props.isCollapsed);
  }
  const proRef = useClickOutside<HTMLDivElement>(() => {
    props.setIsCollapsed(true);
  });
  return (
    <Box
      sx={{
        "& .pro-sidebar-inner": {
          background: `${colors.primary[400]} !important`,
        },
        "& .pro-icon-wrapper": {
          backgroundColor: "transparent !important",
        },
        "& .pro-inner-item": {
          padding: "4px 30px 4px 24px !important",
        },
        "& .pro-inner-item:hover": {
          color: `${colors.greenAccent[500]} !important`,
        },
        "& .pro-menu-item.active": {
          color: `${colors.greenAccent[500]} !important`,
        },
      }}
    >
      <ProSidebar collapsed={props.isCollapsed}>
        <Menu iconShape="square">
          <MenuItem
            onClick={() => props.setIsCollapsed(!props.isCollapsed)}
            style={{
              color: colors.grey[100],
              marginTop:'20px'
            }}
            icon={props.isCollapsed ? <ArrowCircleRightRoundedIcon /> : undefined}
          >
            {!props.isCollapsed && (
              <Box display='flex' justifyContent='space-between'>
                <Typography variant="h3" align='center' color={colors.greenAccent[500]} fontSize='700'>
                  {props.isCollapsed ? <img src='\ideavenu_icon.png' alt="logo"></img>:'IdeaVenu'}
                </Typography>
                <IconButton onClick={() => props.setIsCollapsed(!props.isCollapsed)}>
                  {props.isCollapsed ? <ArrowCircleLeftRoundedIcon /> : <ArrowCircleLeftRoundedIcon/>}
                </IconButton>
              </Box>
            )}
          </MenuItem>
          {!props.isCollapsed && !props.isCollapsed ? (
            <Box 
              mb="25px" 
              mt="25px" 
            >
              <Box 
                sx={{
                  display:"flex" ,
                  backgroundColor:'colors.primary[500]',
                  borderRadius:"8px",
                  marginLeft:'10px',
                  marginRight:'10px',
                }}
              >
                <InputBase sx={{ ml: 2, flex: 1}} placeholder="Search" />
                <IconButton type="button" sx={{ p: 1 }}>
                    <SearchIcon />
                </IconButton>
              </Box>
            </Box>
          ):(
            <Box 
              display='flex' 
              justifyContent='center' 
              mb="25px" 
              mt="25px" 
              style={{
                color: colors.primary[500],
              }}
            >
              <IconButton type="button" sx={{ p: 1 }} onClick={handleClick}>
                <SearchIcon/>
              </IconButton>
            </Box>
          )}
          <Box>
            <Box>
              <Item
                title="Dashboard"
                to="/"
                active={window.location.pathname == "/"}
                icon={<HomeOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="Application Management"
                to="/applicationmanagement"
                icon={<LanguageRoundedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="User List"
                to="/usertable"
                icon={<AutoAwesomeMosaicIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="Analyst List"
                to="/analysttable"
                icon={<DataThresholdingIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="Forgot Password"
                to="/forgotPd"
                icon={<PersonOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              {/* <Item
                title="Seasonality"
                to="/seasonality"
                icon={<CalendarTodayOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="Stock View"
                to="/stockview"
                icon={<HelpOutlineOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="ETF View"
                to="/etfview"
                icon={<BarChartOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="Borrow Data View"
                to="/borrowdataview"
                icon={<PieChartOutlineOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="13F Views"
                to="/13fviews"
                icon={<TimelineOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              />
              <Item
                title="Sentiment Analysis"
                to="/sentimentanalysis"
                icon={<MapOutlinedIcon />}
                selected={selected}
                setSelected={setSelected}
              /> */}
            </Box>
            <Box mt='40px'>
              <Item
                  title="Favorites"
                  to="/favorites"
                  icon={<FavoriteBorderOutlinedIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
                <Item
                  title="Settings"
                  to="/settings"
                  icon={<SettingsOutlinedIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
                <Item
                  title="Support"
                  to="/support"
                  icon={<PeopleAltOutlinedIcon />}
                  selected={selected}
                  setSelected={setSelected}
                />
            </Box>
          </Box>
        </Menu>
      </ProSidebar>
    </Box>
  );
};

export default Sidebar;
