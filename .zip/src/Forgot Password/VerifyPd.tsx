import OTPInput from "react-otp-input";
import React, { useState } from "react";
import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";
import { Button, FormControl, Typography } from "@mui/material";
import { tokens } from "../theme";
import "./VerifyPd.css";

function VerifyPd() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [OTP, setOTP] = useState("");
  function handleChange(OTP: React.SetStateAction<string>) {
    setOTP(OTP);
  }

  const handelEmailCodeVerify = () => {
    console.log(OTP);
    console.log("Verify Otp Sucessfully");
  };

  return (
    <>
      <Box
        display={"flex"}
        flexDirection="column"
        alignSelf="center"
        width="500px"
      >
        <Box
          display="flex"
          flexDirection="row"
          alignSelf="center"
          margin="40px"
        >
          <Typography
            variant="h2"
            align="justify"
            alignSelf="center"
            fontWeight="700"
            // color={colors.greenAccent[500]}
            // color='#109d4b'
            sx={{background: 'linear-gradient(to bottom left, #144c69, #109d4b,#0a7453)',
            WebkitTextFillColor: 'transparent',
            WebkitBackgroundClip: 'text'}}
          >
            Authentication Required
          </Typography>
        </Box>

        <Box display="flex" flexDirection="row" alignSelf="center" margin="20px">
          <Typography
            variant="h6"
            align="justify"
            alignSelf="center"
            fontWeight="400"
            color={colors.grey[400]}
          >
            For your security, we need to authenticate your request. We've sent
            a One Time password(OTP) to the email ***@***. Please enter it
            below.
          </Typography>
        </Box>

        <Box display={"flex"} alignSelf="center" marginLeft={3}>
          <FormControl
            variant="filled"
            size="small"
            className="field-container"
          >
            <OTPInput
              onChange={handleChange}
              value={OTP}
              inputStyle="inputStyle"
              numInputs={6}
              // separator={<div></div>}
            />
          </FormControl>
        </Box>

        <FormControl>
          <Button
            sx={{
              background: `${colors.greenAccent[500]}`,
              margin: "12px 2px 12px 5px",
              height: "50px",
              borderRadius: "24px !important",
              fontWeight: "700",
              backgroundImage: 'linear-gradient(to bottom left, #144c69, #109d4b,#0a7453)',
              "&.MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",

                backgroundColor: "grey !important",
              },
            }}
            onClick={() => handelEmailCodeVerify()}
          >
            <Typography variant="h5" color="white">
              Verify Otp
            </Typography>
          </Button>
        </FormControl>

        <Box display="flex" flexDirection="row" alignSelf="center">
          <Typography
            variant="h6"
            align="justify"
            alignSelf="center"
            fontWeight="400"
            color={colors.blueAccent[500]}
          >
            Resend OTP
          </Typography>
        </Box>
      </Box>
    </>
  );
}

export default VerifyPd;
