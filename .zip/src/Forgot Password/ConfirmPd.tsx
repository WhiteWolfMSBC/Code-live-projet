import * as React from "react";
import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";
import {
  Button,
  FilledInput,
  FormControl,
  IconButton,
  InputAdornment,
  InputLabel,
  Typography,
} from "@mui/material";
import { tokens } from "../theme";
import "./ForgotPd.css";
import VisibilityRoundedIcon from "@mui/icons-material/VisibilityRounded";
import VisibilityOffRoundedIcon from "@mui/icons-material/VisibilityOffRounded";
import VerifyPd from "./VerifyPd";

interface State {
  password: string;
  showPassword: boolean;
}

interface State1 {
  newpassword: string;
  shownewpassword: boolean;
}

function ConfirmPd() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [values, setValues] = React.useState<State>({
    password: "",
    showPassword: false,
  });

  const handleChange =
    (prop: keyof State) => (event: React.ChangeEvent<HTMLInputElement>) => {
      setValues({ ...values, [prop]: event.target.value });
    };

  const handleClickShowPassword = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword,
    });
  };

  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  // 2nd state

  const [values1, setValues1] = React.useState<State1>({
    newpassword: "",
    shownewpassword: false,
  });

  const handlenewChange =
    (prop: keyof State1) => (event: React.ChangeEvent<HTMLInputElement>) => {
      setValues1({ ...values1, [prop]: event.target.value });
    };

  const handleClickShowNewpassword = () => {
    setValues1({
      ...values1,
      shownewpassword: !values1.shownewpassword,
    });
  };

  const handleMouseDownNewpassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  
  const handelPasswordConfirm = () => {
    console.log(values);
    console.log(values1);
    console.log("Verify Password Sucessfully");
  };

  return (
    <Box display={"flex"} flexDirection="column">
      <Box
        display={"flex"}
        marginTop={5}
        flexDirection="column"
        alignSelf="center"
        width="500px"
      >
        {/* Email Verify */}

        <VerifyPd />

        {/* Password */}

        <Typography
          variant="h2"
          align="justify"
          alignSelf="center"
          fontWeight="400"
          marginTop={4}
          color={colors.greenAccent[500]}
        >
          Create new password
        </Typography>

        <Typography
          variant="h6"
          align="justify"
          alignSelf="center"
          fontWeight="400"
          marginTop={1}
          marginBottom={3}
          color={colors.grey[400]}
        >
          We'll ask for this password whenever you sign in.
        </Typography>

        {/* Password filed */}

        <FormControl
          variant="filled"
          size="small"
          sx={{ margin: "6px 0 12px 0" }}
        >
          <InputLabel
            htmlFor="password"
            sx={{ color: "grey", marginTop: "2px" }}
            required
          >
            New password
          </InputLabel>
          <FilledInput
            id="password"
            type={values.showPassword ? "text" : "password"}
            value={values.password}
            placeholder="&#128065;"
            onChange={handleChange("password")}
            sx={{
                backgroundColor: "white",
                borderRadius: "24px",

                "& .MuiInputBase-root": {
                  fontSize: "18px",
                },
            }}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  sx={{ color: "black", marginLeft: "4px" }}
                  edge="end"
                >
                  {values.showPassword ? (
                    <VisibilityOffRoundedIcon />
                  ) : (
                    <VisibilityRoundedIcon />
                  )}
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>

        {/* Enter New Password Again */}

        <FormControl
          variant="filled"
          size="small"
          sx={{ margin: "6px 0 12px 0" }}
        >
          <InputLabel
            htmlFor="confirmPassword"
            sx={{ color: "grey", marginTop: "2px" }}
            required
          >
            Password again
          </InputLabel>
          <FilledInput
            id="confirmPassword"
            type={values1.shownewpassword ? "text" : "password"}
            value={values1.newpassword}
            placeholder="&#128065;"
            onChange={handlenewChange("newpassword")}
            sx={{
              backgroundColor: "white",
              borderRadius: "24px",

              "& .MuiInputBase-root": {
                fontSize: "18px",
              },
            }}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowNewpassword}
                  onMouseDown={handleMouseDownNewpassword}
                  sx={{ color: "black", marginLeft: "4px" }}
                  edge="end"
                >
                  {values1.shownewpassword ? (
                    <VisibilityOffRoundedIcon />
                  ) : (
                    <VisibilityRoundedIcon />
                  )}
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>

        <FormControl>
          <Button
            sx={{
              background: `${colors.greenAccent[500]}`,
              margin: "12px 2px 12px 5px",
              height: "50px",
              borderRadius: "24px !important",
              fontWeight: "700",
              backgroundImage: 'linear-gradient(45deg, #144c69, #109d4b,#0a7453)',
              "&.MuiButton-root:hover": {
                WebkitTextDecorationStyle: "none",

                backgroundColor: "grey !important",
              },
            }}
            onClick={() => handelPasswordConfirm()}
          >
            <Typography variant="h5" color="white">
              Change Password
            </Typography>
          </Button>
        </FormControl>
      </Box>

      {/* text */}

      <Box display="flex" flexDirection="row" alignSelf="center" margin="40px">
        <Typography
          variant="h6"
          align="justify"
          alignSelf="center"
          fontWeight="400"
          color={colors.grey[400]}
        >
          <h5>Secure Password tips:</h5>
          <li className="">
            Use at least 8 cahracters, a combination of numbers and letters{" "}
            <br />
            <span className="ms-4">is best.</span>
          </li>
          <li>
            Do not use the same password you have used with us previously.
          </li>
          <li>
            Do not use dictionary words, your name, e-mail address, mobile <br/>
            <span className="ms-4">
              phone number or other personal information that can be easily <br/>
              <span className="ms-4">obtained.</span>
            </span>
          </li>
          <li>Do not use the same password for multiple online.</li>
        </Typography>
      </Box>
    </Box>
  );
}

export default ConfirmPd;
