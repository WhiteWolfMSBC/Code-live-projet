import React, {useState} from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { useTheme } from "@mui/material/styles";
import {
  Button,
  FormControl,
  IconButton,
  TableContainer,
  Typography,
} from "@mui/material";
import { tokens } from "../theme";
import Icon from "../assets/Icon3.png";
import "./ForgotPd.css";
import ConfirmPd from "./ConfirmPd";
import TopBar from "../components/global/TopBar";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import CloseIcon from "@mui/icons-material/Close";

export default function ForgotPd() {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [emailId, setEmailId] = useState<string>("");

  const handleEmailChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setEmailId(e.target.value);
  };

  const handelverifyEmail=()=>{
    console.log(emailId);
    console.log("Verify Email Sucessfully");
      
  }


  return (
    <>
      <TableContainer>
        <Box display="flex" justifyContent={"space-between"} sx={{ m: "8px" }}>
          <Box display="inline-block" padding={"20px 8px 20px 8px"}>
            <Box display={"flex"}>
              <Typography
                variant="h4"
                marginLeft={4}
                marginTop={1.5}
                color={colors.greenAccent[500]}
              >
                Forgot Password
              </Typography>

              <IconButton size="large" color="inherit">
                <KeyboardArrowLeftIcon />
              </IconButton>

              <IconButton size="large" color="inherit">
                <KeyboardArrowRightIcon />
              </IconButton>

              <IconButton size="large" color="inherit">
                <CloseIcon />
              </IconButton>
            </Box>
          </Box>

          <Box display={"flex"} p={1.5}>
            <TopBar />
          </Box>
        </Box>

        <Box display={"flex"} flexDirection="column">
          <Box display="flex" flexDirection="column" alignSelf="center">
            <Box display={"flex"} alignSelf="center">
              <img src={Icon} />
            </Box>

            <Typography
              variant="h1"
              align="justify"
              alignSelf="center"
              fontFamily={"Futura Md BT, sans-serif"}
              fontWeight="400"
              marginLeft={2}
              color={colors.grey[900]}
              sx={{ letterSpacing: "5px" }}
            >
              CLOVERR
            </Typography>
          </Box>

          {/* Forgot Password */}

          {/* Otp Email */}

          <Box
            display={"flex"}
            flexDirection="column"
            alignSelf="center"
            width="500px"
            margin="40px"
          >
            <FormControl
              variant="filled"
              size="small"
              className="field-container"
            >
              <TextField
                required
                id="emailId"
                variant="filled"
                label="Email Id"
                placeholder="&#x2709;"
                type="text"
                size="small"
                value={emailId}
                onChange={(e) => handleEmailChange(e)}
                sx={{
                  backgroundColor: "white",
                  borderRadius: "24px",

                  "& .MuiInputBase-root": {
                    fontSize: "18px",
                  },
                }}
              />
            </FormControl>

            <FormControl>
              <Button
                sx={{
                  background: `${colors.greenAccent[500]}`,
                  margin: "12px 2px 12px 5px",
                  height: "50px",
                  borderRadius: "24px !important",
                  fontWeight: "700",
                  backgroundImage: 'linear-gradient(to bottom, #144c69, #109d4b,#0a7453)',
                  "&.MuiButton-root:hover": {
                    WebkitTextDecorationStyle: "none",

                    backgroundColor: "grey !important",
                  },
                }}
                onClick={()=>handelverifyEmail()}
              >
                <Typography variant="h5" color="white">
                  Verify Email
                </Typography>
              </Button>
            </FormControl>

            {/* Confirm Password */}

            <ConfirmPd />
          </Box>
        </Box>
      </TableContainer>
    </>
  );
}
